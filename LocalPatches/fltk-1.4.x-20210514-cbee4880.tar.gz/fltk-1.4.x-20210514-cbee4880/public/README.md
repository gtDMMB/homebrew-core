# Public Documentation Directory

File: public/README.md

You should never see this file unless explicitly requested by URL.

This is a placeholder for GitLab Pages.
