#ifndef RNAPUZZLER_AABB_STRUCT_H
#define RNAPUZZLER_AABB_STRUCT_H

typedef struct {
  double  min[2];
  double  max[2];
} AABB;

#endif
