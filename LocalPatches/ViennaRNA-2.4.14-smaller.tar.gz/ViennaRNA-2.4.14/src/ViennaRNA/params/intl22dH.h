PUBLIC int int22_dH[NBPAIRS+1][NBPAIRS+1][5][5][5][5] =
{{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{    80,  -120,    30,    80,    80}
    ,{    30,  -310,  -170,    30,  -110}
    ,{    80,  -230,  -110,    80,   -60}
    ,{    80,  -120,    30,    30,    80}
    ,{   -30,  -340,  -220,   -30,  -170}
    }
   ,{{  -120,  -460,  -290,  -120,  -230}
    ,{  -120,  -460,  -310,  -120,  -260}
    ,{  -430,  -770,  -620,  -430,  -570}
    ,{  -230,  -670,  -290,  -980,  -230}
    ,{  -430,  -770,  -620,  -430,  -570}
    }
   ,{{    30,  -290,  -170,    30,  -110}
    ,{    30,  -310,  -170,    30,  -110}
    ,{    20,  -290,  -170,    20,  -120}
    ,{    30,  -310,  -170,    30,  -110}
    ,{   -30,  -340,  -220,   -30,  -170}
    }
   ,{{    80,  -120,    30,  -430,    80}
    ,{  -520,  -960,  -580, -1270,  -520}
    ,{  -430,  -770,  -620,  -430,  -570}
    ,{    80,  -120,    30,  -430,    80}
    ,{  -430,  -770,  -620,  -430,  -570}
    }
   ,{{    80,  -230,  -110,    80,   -60}
    ,{    30,  -310,  -170,    30,  -110}
    ,{    80,  -230,  -110,    80,   -60}
    ,{    30,  -310,  -170,    30,  -110}
    ,{  -860,  -860,  -960, -1410,  -900}
    }
   }
  ,{{{    30,  -120,    30,  -520,    30}
    ,{  -170,  -310,  -170,  -810,  -170}
    ,{  -110,  -260,  -110,  -520,  -110}
    ,{    30,  -120,    30,  -810,    30}
    ,{  -220,  -370,  -220,  -630,  -220}
    }
   ,{{  -310,  -460,  -310,  -960,  -310}
    ,{  -310,  -460,  -310,  -960,  -310}
    ,{  -620,  -770,  -620, -1270,  -620}
    ,{  -530,  -670,  -530, -1170,  -530}
    ,{  -620,  -770,  -620, -1270,  -620}
    }
   ,{{  -170,  -310,  -170,  -580,  -170}
    ,{  -170,  -310,  -170,  -810,  -170}
    ,{  -170,  -320,  -170,  -580,  -170}
    ,{  -170,  -310,  -170,  -810,  -170}
    ,{  -220,  -370,  -220,  -630,  -220}
    }
   ,{{    30,  -120,    30, -1270,    30}
    ,{  -810,  -960,  -810, -1460,  -810}
    ,{  -620,  -770,  -620, -1270,  -620}
    ,{    30,  -120,    30, -1870,    30}
    ,{  -620,  -770,  -620, -1270,  -620}
    }
   ,{{  -110,  -260,  -110,  -520,  -110}
    ,{  -170,  -310,  -170,  -810,  -170}
    ,{  -110,  -260,  -110,  -520,  -110}
    ,{  -170,  -310,  -170,  -810,  -170}
    ,{  -860,  -860,  -960, -1600,  -960}
    }
   }
  ,{{{    80,  -430,    20,  -430,    80}
    ,{  -110,  -620,  -170,  -620,  -110}
    ,{   -60,  -570,  -120,  -570,   -60}
    ,{    80,  -430,    20,  -430,    80}
    ,{  -170,  -680,  -230,  -680,  -170}
    }
   ,{{  -230,  -770,  -290,  -770,  -230}
    ,{  -260,  -770,  -320,  -770,  -260}
    ,{  -570, -1080,  -630, -1080,  -570}
    ,{  -230,  -980,  -290,  -980,  -230}
    ,{  -570, -1080,  -630, -1080,  -570}
    }
   ,{{  -110,  -620,  -170,  -620,  -110}
    ,{  -110,  -620,  -170,  -620,  -110}
    ,{  -120,  -630,  -180,  -630,  -120}
    ,{  -110,  -620,  -170,  -620,  -110}
    ,{  -170,  -680,  -230,  -680,  -170}
    }
   ,{{    80,  -430,    20,  -430,    80}
    ,{  -520, -1270,  -580, -1270,  -520}
    ,{  -570, -1080,  -630, -1080,  -570}
    ,{    80,  -430,    20,  -430,    80}
    ,{  -570, -1080,  -630, -1080,  -570}
    }
   ,{{   -60,  -570,  -120,  -570,   -60}
    ,{  -110,  -620,  -170,  -620,  -110}
    ,{   -60,  -570,  -120,  -570,   -60}
    ,{  -110,  -620,  -170,  -620,  -110}
    ,{  -900, -1410,  -960, -1410,  -900}
    }
   }
  ,{{{    80,  -230,    30,    80,    30}
    ,{    30,  -530,  -170,    30,  -170}
    ,{    80,  -230,  -110,    80,  -110}
    ,{    30,  -530,    30,    30,    30}
    ,{   -30,  -340,  -220,   -30,  -220}
    }
   ,{{  -120,  -670,  -310,  -120,  -310}
    ,{  -120,  -670,  -310,  -120,  -310}
    ,{  -430,  -980,  -620,  -430,  -620}
    ,{  -530,  -890,  -530, -1580,  -530}
    ,{  -430,  -980,  -620,  -430,  -620}
    }
   ,{{    30,  -290,  -170,    30,  -170}
    ,{    30,  -530,  -170,    30,  -170}
    ,{    20,  -290,  -170,    20,  -170}
    ,{    30,  -530,  -170,    30,  -170}
    ,{   -30,  -340,  -220,   -30,  -220}
    }
   ,{{    30,  -980,    30,  -430,    30}
    ,{  -810, -1170,  -810, -1870,  -810}
    ,{  -430,  -980,  -620,  -430,  -620}
    ,{    30, -1580,    30, -2280,    30}
    ,{  -430,  -980,  -620,  -430,  -620}
    }
   ,{{    80,  -230,  -110,    80,  -110}
    ,{    30,  -530,  -170,    30,  -170}
    ,{    80,  -230,  -110,    80,  -110}
    ,{    30,  -530,  -170,    30,  -170}
    ,{  -960, -1320,  -960, -2010,  -960}
    }
   }
  ,{{{   -30,  -430,   -30,  -430,  -860}
    ,{  -220,  -620,  -220,  -620,  -860}
    ,{  -170,  -570,  -170,  -570,  -900}
    ,{   -30,  -430,   -30,  -430,  -960}
    ,{  -280,  -680,  -280,  -680, -1010}
    }
   ,{{  -340,  -770,  -340,  -770,  -860}
    ,{  -370,  -770,  -370,  -770,  -860}
    ,{  -680, -1080,  -680, -1080, -1410}
    ,{  -340,  -980,  -340,  -980, -1320}
    ,{  -680, -1080,  -680, -1080, -1410}
    }
   ,{{  -220,  -620,  -220,  -620,  -960}
    ,{  -220,  -620,  -220,  -620,  -960}
    ,{  -230,  -630,  -230,  -630,  -960}
    ,{  -220,  -620,  -220,  -620,  -960}
    ,{  -280,  -680,  -280,  -680, -1010}
    }
   ,{{   -30,  -430,   -30,  -430, -1410}
    ,{  -630, -1270,  -630, -1270, -1600}
    ,{  -680, -1080,  -680, -1080, -1410}
    ,{   -30,  -430,   -30,  -430, -2010}
    ,{  -680, -1080,  -680, -1080, -1410}
    }
   ,{{  -170,  -570,  -170,  -570,  -900}
    ,{  -220,  -620,  -220,  -620,  -960}
    ,{  -170,  -570,  -170,  -570,  -900}
    ,{  -220,  -620,  -220,  -620,  -960}
    ,{ -1010, -1410, -1010, -1410, -1750}
    }
   }
  }
 ,{{{{   540,   180,    30,   540,   180}
    ,{    10,  -580,  -150,    10,   -90}
    ,{   540,  -350,  -600,   540,  -540}
    ,{   180,   180,    30,  -320,   180}
    ,{   -90,  -740,   -90,  -260,  -540}
    }
   ,{{   -90,  -350,  -150,  -100,   -90}
    ,{   -90,  -580,  -150,  -200,   -90}
    ,{  -100,  -350,  -600,  -100,  -540}
    ,{  -630, -1790,  -630, -1790, -1040}
    ,{  -400,  -740,  -600,  -400,  -540}
    }
   ,{{   540,  -660,  -510,   540,  -400}
    ,{    10,  -660,  -510,    10,  -400}
    ,{   540,  -940,  -820,   540,  -760}
    ,{  -320,  -660,  -510,  -320,  -460}
    ,{  -260,  -940,  -820,  -260,  -550}
    }
   ,{{   180,   180,    30,  -400,   180}
    ,{  -500, -1070,  -500, -1080,  -570}
    ,{  -400,  -740,  -600,  -400,  -540}
    ,{   180,   180,    30,  -430,   180}
    ,{  -400,  -740,  -600,  -400,  -540}
    }
   ,{{   -90,  -660,   -90,  -210,  -460}
    ,{  -320,  -660,  -510,  -320,  -460}
    ,{  -210, -1250, -1130,  -210, -1070}
    ,{  -320,  -660,  -510,  -320,  -460}
    ,{   -90,  -830,   -90,  -810,  -800}
    }
   }
  ,{{{   540,   180,   -90,   540,    30}
    ,{    10,  -580,  -220,    10,  -150}
    ,{   540,  -740,  -600,   540,  -600}
    ,{   180,   180,  -390, -1160,    30}
    ,{   -90,  -740,   -90,  -810,  -600}
    }
   ,{{  -100,  -580,  -220,  -100,  -150}
    ,{  -150,  -580,  -220,  -970,  -150}
    ,{  -100,  -740,  -600,  -100,  -600}
    ,{ -1340, -2010, -1650, -1980, -1340}
    ,{  -600,  -740,  -600, -1240,  -600}
    }
   ,{{   540,  -660,  -510,   540,  -510}
    ,{    10,  -660, -1150,    10,  -510}
    ,{   540,  -960,  -820,   540,  -820}
    ,{  -510,  -660,  -510, -1160,  -510}
    ,{  -820,  -960,  -820, -1220,  -820}
    }
   ,{{   180,   180,  -390, -1240,    30}
    ,{  -860, -1340,  -860, -2450,  -860}
    ,{  -600,  -740,  -600, -1240,  -600}
    ,{   180,   180,  -390, -1870,    30}
    ,{  -600,  -740,  -600, -1240,  -600}
    }
   ,{{   -90,  -660,   -90,  -810,  -510}
    ,{  -510,  -660,  -510, -1160,  -510}
    ,{ -1130, -1270, -1130, -1530, -1130}
    ,{  -510,  -660,  -510, -1160,  -510}
    ,{   -90, -1240,   -90,  -810,  -800}
    }
   }
  ,{{{   180,  -430,    20,  -430,   180}
    ,{   -90,  -600,  -500,  -600,   -90}
    ,{  -540, -1050,  -600, -1050,  -540}
    ,{   180,  -430,    20,  -430,   180}
    ,{  -540,  -830,  -600, -1050,  -540}
    }
   ,{{   -90,  -600,  -600,  -600,   -90}
    ,{   -90,  -600, -1070,  -600,   -90}
    ,{  -540, -1050,  -600, -1050,  -540}
    ,{  -630, -1790,  -630, -1790, -1040}
    ,{  -540, -1050,  -600, -1050,  -540}
    }
   ,{{  -460,  -970,  -520,  -970,  -460}
    ,{  -460,  -970,  -750,  -970,  -460}
    ,{  -760, -1270,  -820, -1270,  -760}
    ,{  -460,  -970,  -520,  -970,  -460}
    ,{  -550, -1270,  -820, -1270,  -550}
    }
   ,{{   180,  -430,    20,  -430,   180}
    ,{  -500, -1070,  -500, -1320,  -570}
    ,{  -540, -1050,  -600, -1050,  -540}
    ,{   180,  -430,    20,  -430,   180}
    ,{  -540, -1050,  -600, -1050,  -540}
    }
   ,{{  -460,  -830,  -520,  -970,  -460}
    ,{  -460,  -970,  -520,  -970,  -460}
    ,{ -1070, -1580, -1130, -1580, -1070}
    ,{  -460,  -970,  -520,  -970,  -460}
    ,{  -830,  -830, -1710, -1260, -1460}
    }
   }
  ,{{{    30,  -350,    30,  -200,    30}
    ,{  -150,  -870,  -150,  -200,  -150}
    ,{  -210,  -350,  -600,  -210,  -600}
    ,{    30,  -870,    30,  -320,    30}
    ,{  -260,  -940,  -600,  -260,  -600}
    }
   ,{{  -150,  -350,  -150,  -200,  -150}
    ,{  -150, -1600,  -150,  -200,  -150}
    ,{  -350,  -350,  -600,  -440,  -600}
    ,{ -1340, -3070, -1340, -2390, -1340}
    ,{  -400,  -960,  -600,  -400,  -600}
    }
   ,{{  -260,  -870,  -510,  -260,  -510}
    ,{  -320, -1110,  -510,  -320,  -510}
    ,{  -620,  -940,  -820,  -620,  -820}
    ,{  -320,  -870,  -510,  -320,  -510}
    ,{  -260,  -940,  -820,  -260,  -820}
    }
   ,{{    30,  -960,    30,  -400,    30}
    ,{  -860, -1880,  -860, -1080,  -860}
    ,{  -400,  -960,  -600,  -400,  -600}
    ,{    30, -1370,    30, -2280,    30}
    ,{  -400,  -960,  -600,  -400,  -600}
    }
   ,{{  -210,  -870,  -510,  -210,  -510}
    ,{  -320,  -870,  -510,  -320,  -510}
    ,{  -210, -1250, -1130,  -210, -1130}
    ,{  -320,  -870,  -510,  -320,  -510}
    ,{  -800, -1360,  -800, -1550,  -800}
    }
   }
  ,{{{  -200,  -430,  -200,  -430,  -230}
    ,{  -200,  -600,  -200,  -600,  -400}
    ,{  -650, -1050,  -650, -1050, -1390}
    ,{  -230,  -430,  -570,  -430,  -230}
    ,{  -650, -1050,  -650, -1050, -1390}
    }
   ,{{  -200,  -600,  -200,  -600, -1390}
    ,{  -200,  -600,  -200,  -600, -1490}
    ,{  -650, -1050,  -650, -1050, -1390}
    ,{ -1150, -1790, -1150, -1790, -1520}
    ,{  -650, -1050,  -650, -1050, -1390}
    }
   ,{{  -400,  -970,  -570,  -970,  -400}
    ,{  -400,  -970,  -570,  -970,  -400}
    ,{  -870, -1270,  -870, -1270, -1610}
    ,{  -570,  -970,  -570,  -970, -1300}
    ,{  -870, -1270,  -870, -1270, -1610}
    }
   ,{{  -230,  -430,  -650,  -430,  -230}
    ,{ -1300, -1320, -1750, -1320, -1300}
    ,{  -650, -1050,  -650, -1050, -1390}
    ,{  -230,  -430,  -880,  -430,  -230}
    ,{  -650, -1050,  -650, -1050, -1390}
    }
   ,{{  -570,  -970,  -570,  -970, -1300}
    ,{  -570,  -970,  -570,  -970, -1300}
    ,{ -1180, -1580, -1180, -1580, -1920}
    ,{  -570,  -970,  -570,  -970, -1300}
    ,{  -860, -1260,  -860, -1260, -2350}
    }
   }
  }
 ,{{{{   240,    40,   190,  -270,   240}
    ,{  -590, -1030,  -650,  -870,  -590}
    ,{  -870, -1180, -1060,  -870, -1010}
    ,{   240,    40,   190,  -270,   240}
    ,{  -870,  -970, -1060,  -870, -1010}
    }
   ,{{  -780, -1210,  -840,  -870,  -780}
    ,{ -1050, -1370, -1240, -1050, -1190}
    ,{  -870, -1210, -1060,  -870, -1010}
    ,{  -780, -1220,  -840, -1530,  -780}
    ,{  -870, -1210, -1060,  -870, -1010}
    }
   ,{{  -870, -1180, -1060,  -870, -1010}
    ,{  -870, -1210, -1060,  -870, -1010}
    ,{  -870, -1180, -1060,  -870, -1010}
    ,{  -870, -1210, -1060,  -870, -1010}
    ,{  -870, -1180, -1060,  -870, -1010}
    }
   ,{{   240,    40,   190,  -270,   240}
    ,{  -590, -1030,  -650, -1340,  -590}
    ,{  -870, -1210, -1060,  -870, -1010}
    ,{   240,    40,   190,  -270,   240}
    ,{  -870, -1210, -1060,  -870, -1010}
    }
   ,{{  -870,  -970, -1060,  -870, -1010}
    ,{  -870, -1210, -1060,  -870, -1010}
    ,{  -870, -1180, -1060,  -870, -1010}
    ,{  -870, -1210, -1060,  -870, -1010}
    ,{  -970,  -970, -1060, -1520, -1010}
    }
   }
  ,{{{   190,    40,   190, -1470,   190}
    ,{  -890, -1030,  -890, -1530,  -890}
    ,{ -1060, -1210, -1060, -1470, -1060}
    ,{   190,    40,   190, -1710,   190}
    ,{  -970,  -970, -1060, -1470, -1060}
    }
   ,{{ -1060, -1210, -1060, -1710, -1060}
    ,{ -1240, -1370, -1240, -1890, -1240}
    ,{ -1060, -1210, -1060, -1710, -1060}
    ,{ -1080, -1220, -1080, -1720, -1080}
    ,{ -1060, -1210, -1060, -1710, -1060}
    }
   ,{{ -1060, -1210, -1060, -1470, -1060}
    ,{ -1060, -1210, -1060, -1710, -1060}
    ,{ -1060, -1210, -1060, -1470, -1060}
    ,{ -1060, -1210, -1060, -1710, -1060}
    ,{ -1060, -1210, -1060, -1470, -1060}
    }
   ,{{   190,    40,   190, -1530,   190}
    ,{  -890, -1030,  -890, -1530,  -890}
    ,{ -1060, -1210, -1060, -1710, -1060}
    ,{   190,    40,   190, -1710,   190}
    ,{ -1060, -1210, -1060, -1710, -1060}
    }
   ,{{  -970,  -970, -1060, -1470, -1060}
    ,{ -1060, -1210, -1060, -1710, -1060}
    ,{ -1060, -1210, -1060, -1470, -1060}
    ,{ -1060, -1210, -1060, -1710, -1060}
    ,{  -970,  -970, -1060, -1710, -1060}
    }
   }
  ,{{{   240,  -270,   180,  -270,   240}
    ,{  -590, -1340,  -650, -1340,  -590}
    ,{ -1010, -1520, -1070, -1520, -1010}
    ,{   240,  -270,   180,  -270,   240}
    ,{ -1010, -1520, -1070, -1520, -1010}
    }
   ,{{  -780, -1520,  -840, -1520,  -780}
    ,{ -1190, -1700, -1250, -1700, -1190}
    ,{ -1010, -1520, -1070, -1520, -1010}
    ,{  -780, -1530,  -840, -1530,  -780}
    ,{ -1010, -1520, -1070, -1520, -1010}
    }
   ,{{ -1010, -1520, -1070, -1520, -1010}
    ,{ -1010, -1520, -1070, -1520, -1010}
    ,{ -1010, -1520, -1070, -1520, -1010}
    ,{ -1010, -1520, -1070, -1520, -1010}
    ,{ -1010, -1520, -1070, -1520, -1010}
    }
   ,{{   240,  -270,   180,  -270,   240}
    ,{  -590, -1340,  -650, -1340,  -590}
    ,{ -1010, -1520, -1070, -1520, -1010}
    ,{   240,  -270,   180,  -270,   240}
    ,{ -1010, -1520, -1070, -1520, -1010}
    }
   ,{{ -1010, -1520, -1070, -1520, -1010}
    ,{ -1010, -1520, -1070, -1520, -1010}
    ,{ -1010, -1520, -1070, -1520, -1010}
    ,{ -1010, -1520, -1070, -1520, -1010}
    ,{ -1010, -1520, -1070, -1520, -1010}
    }
   }
  ,{{{   190, -1180,   190,  -870,   190}
    ,{  -870, -1250,  -890,  -870,  -890}
    ,{  -870, -1180, -1060,  -870, -1060}
    ,{   190, -1420,   190,  -870,   190}
    ,{  -870, -1180, -1060,  -870, -1060}
    }
   ,{{  -870, -1420, -1060,  -870, -1060}
    ,{ -1050, -1600, -1240, -1050, -1240}
    ,{  -870, -1420, -1060,  -870, -1060}
    ,{ -1080, -1440, -1080, -2130, -1080}
    ,{  -870, -1420, -1060,  -870, -1060}
    }
   ,{{  -870, -1180, -1060,  -870, -1060}
    ,{  -870, -1420, -1060,  -870, -1060}
    ,{  -870, -1180, -1060,  -870, -1060}
    ,{  -870, -1420, -1060,  -870, -1060}
    ,{  -870, -1180, -1060,  -870, -1060}
    }
   ,{{   190, -1250,   190,  -870,   190}
    ,{  -890, -1250,  -890, -1940,  -890}
    ,{  -870, -1420, -1060,  -870, -1060}
    ,{   190, -1420,   190, -2120,   190}
    ,{  -870, -1420, -1060,  -870, -1060}
    }
   ,{{  -870, -1180, -1060,  -870, -1060}
    ,{  -870, -1420, -1060,  -870, -1060}
    ,{  -870, -1180, -1060,  -870, -1060}
    ,{  -870, -1420, -1060,  -870, -1060}
    ,{ -1060, -1420, -1060, -2120, -1060}
    }
   }
  ,{{{   130,  -270,   130,  -270, -1680}
    ,{  -700, -1340,  -700, -1340, -1680}
    ,{ -1120, -1520, -1120, -1520, -1850}
    ,{   130,  -270,   130,  -270, -1850}
    ,{ -1120, -1520, -1120, -1520, -1850}
    }
   ,{{  -890, -1520,  -890, -1520, -1790}
    ,{ -1300, -1700, -1300, -1700, -1790}
    ,{ -1120, -1520, -1120, -1520, -1850}
    ,{  -890, -1530,  -890, -1530, -1870}
    ,{ -1120, -1520, -1120, -1520, -1850}
    }
   ,{{ -1120, -1520, -1120, -1520, -1850}
    ,{ -1120, -1520, -1120, -1520, -1850}
    ,{ -1120, -1520, -1120, -1520, -1850}
    ,{ -1120, -1520, -1120, -1520, -1850}
    ,{ -1120, -1520, -1120, -1520, -1850}
    }
   ,{{   130,  -270,   130,  -270, -1680}
    ,{  -700, -1340,  -700, -1340, -1680}
    ,{ -1120, -1520, -1120, -1520, -1850}
    ,{   130,  -270,   130,  -270, -1850}
    ,{ -1120, -1520, -1120, -1520, -1850}
    }
   ,{{ -1120, -1520, -1120, -1520, -1850}
    ,{ -1120, -1520, -1120, -1520, -1850}
    ,{ -1120, -1520, -1120, -1520, -1850}
    ,{ -1120, -1520, -1120, -1520, -1850}
    ,{ -1120, -1520, -1120, -1520, -1850}
    }
   }
  }
 ,{{{{   800,   600,   740,   290,   800}
    ,{   200,  -140,     0,   200,    50}
    ,{  -310,  -630,  -510,  -310,  -450}
    ,{   800,   600,   740,   290,   800}
    ,{  -310,  -410,  -510,  -310,  -450}
    }
   ,{{   200,  -140,     0,   200,    50}
    ,{   200,  -140,     0,   200,    50}
    ,{  -310,  -650,  -510,  -310,  -450}
    ,{  -550,  -990,  -610, -1300,  -550}
    ,{  -310,  -650,  -510,  -310,  -450}
    }
   ,{{  -310,  -630,  -510,  -310,  -450}
    ,{  -310,  -650,  -510,  -310,  -450}
    ,{  -310,  -630,  -510,  -310,  -450}
    ,{  -310,  -650,  -510,  -310,  -450}
    ,{  -310,  -630,  -510,  -310,  -450}
    }
   ,{{   800,   600,   740,   290,   800}
    ,{  -720, -1160,  -780, -1470,  -720}
    ,{  -310,  -650,  -510,  -310,  -450}
    ,{   800,   600,   740,   290,   800}
    ,{  -310,  -650,  -510,  -310,  -450}
    }
   ,{{  -310,  -410,  -510,  -310,  -450}
    ,{  -310,  -650,  -510,  -310,  -450}
    ,{  -310,  -630,  -510,  -310,  -450}
    ,{  -310,  -650,  -510,  -310,  -450}
    ,{  -410,  -410,  -510,  -960,  -450}
    }
   }
  ,{{{   740,   600,   740,  -640,   740}
    ,{     0,  -140,     0,  -640,     0}
    ,{  -510,  -650,  -510,  -910,  -510}
    ,{   740,   600,   740, -1150,   740}
    ,{  -410,  -410,  -510,  -910,  -510}
    }
   ,{{     0,  -140,     0,  -640,     0}
    ,{     0,  -140,     0,  -640,     0}
    ,{  -510,  -650,  -510, -1150,  -510}
    ,{  -850,  -990,  -850, -1490,  -850}
    ,{  -510,  -650,  -510, -1150,  -510}
    }
   ,{{  -510,  -650,  -510,  -910,  -510}
    ,{  -510,  -650,  -510, -1150,  -510}
    ,{  -510,  -650,  -510,  -910,  -510}
    ,{  -510,  -650,  -510, -1150,  -510}
    ,{  -510,  -650,  -510,  -910,  -510}
    }
   ,{{   740,   600,   740, -1150,   740}
    ,{ -1020, -1160, -1020, -1660, -1020}
    ,{  -510,  -650,  -510, -1150,  -510}
    ,{   740,   600,   740, -1150,   740}
    ,{  -510,  -650,  -510, -1150,  -510}
    }
   ,{{  -410,  -410,  -510,  -910,  -510}
    ,{  -510,  -650,  -510, -1150,  -510}
    ,{  -510,  -650,  -510,  -910,  -510}
    ,{  -510,  -650,  -510, -1150,  -510}
    ,{  -410,  -410,  -510, -1150,  -510}
    }
   }
  ,{{{   800,   290,   740,   290,   800}
    ,{    50,  -450,     0,  -450,    50}
    ,{  -450,  -960,  -510,  -960,  -450}
    ,{   800,   290,   740,   290,   800}
    ,{  -450,  -960,  -510,  -960,  -450}
    }
   ,{{    50,  -450,     0,  -450,    50}
    ,{    50,  -450,     0,  -450,    50}
    ,{  -450,  -960,  -510,  -960,  -450}
    ,{  -550, -1300,  -610, -1300,  -550}
    ,{  -450,  -960,  -510,  -960,  -450}
    }
   ,{{  -450,  -960,  -510,  -960,  -450}
    ,{  -450,  -960,  -510,  -960,  -450}
    ,{  -450,  -960,  -510,  -960,  -450}
    ,{  -450,  -960,  -510,  -960,  -450}
    ,{  -450,  -960,  -510,  -960,  -450}
    }
   ,{{   800,   290,   740,   290,   800}
    ,{  -720, -1470,  -780, -1470,  -720}
    ,{  -450,  -960,  -510,  -960,  -450}
    ,{   800,   290,   740,   290,   800}
    ,{  -450,  -960,  -510,  -960,  -450}
    }
   ,{{  -450,  -960,  -510,  -960,  -450}
    ,{  -450,  -960,  -510,  -960,  -450}
    ,{  -450,  -960,  -510,  -960,  -450}
    ,{  -450,  -960,  -510,  -960,  -450}
    ,{  -450,  -960,  -510,  -960,  -450}
    }
   }
  ,{{{   740,  -360,   740,   200,   740}
    ,{   200,  -360,     0,   200,     0}
    ,{  -310,  -630,  -510,  -310,  -510}
    ,{   740,  -870,   740,  -310,   740}
    ,{  -310,  -630,  -510,  -310,  -510}
    }
   ,{{   200,  -360,     0,   200,     0}
    ,{   200,  -360,     0,   200,     0}
    ,{  -310,  -870,  -510,  -310,  -510}
    ,{  -850, -1210,  -850, -1900,  -850}
    ,{  -310,  -870,  -510,  -310,  -510}
    }
   ,{{  -310,  -630,  -510,  -310,  -510}
    ,{  -310,  -870,  -510,  -310,  -510}
    ,{  -310,  -630,  -510,  -310,  -510}
    ,{  -310,  -870,  -510,  -310,  -510}
    ,{  -310,  -630,  -510,  -310,  -510}
    }
   ,{{   740,  -870,   740,  -310,   740}
    ,{ -1020, -1380, -1020, -2070, -1020}
    ,{  -310,  -870,  -510,  -310,  -510}
    ,{   740,  -870,   740, -1560,   740}
    ,{  -310,  -870,  -510,  -310,  -510}
    }
   ,{{  -310,  -630,  -510,  -310,  -510}
    ,{  -310,  -870,  -510,  -310,  -510}
    ,{  -310,  -630,  -510,  -310,  -510}
    ,{  -310,  -870,  -510,  -310,  -510}
    ,{  -510,  -870,  -510, -1560,  -510}
    }
   }
  ,{{{   690,   290,   690,   290,  -550}
    ,{   -50,  -450,   -50,  -450,  -550}
    ,{  -560,  -960,  -560,  -960, -1300}
    ,{   690,   290,   690,   290, -1300}
    ,{  -560,  -960,  -560,  -960, -1300}
    }
   ,{{   -50,  -450,   -50,  -450,  -550}
    ,{   -50,  -450,   -50,  -450,  -550}
    ,{  -560,  -960,  -560,  -960, -1300}
    ,{  -660, -1300,  -660, -1300, -1640}
    ,{  -560,  -960,  -560,  -960, -1300}
    }
   ,{{  -560,  -960,  -560,  -960, -1300}
    ,{  -560,  -960,  -560,  -960, -1300}
    ,{  -560,  -960,  -560,  -960, -1300}
    ,{  -560,  -960,  -560,  -960, -1300}
    ,{  -560,  -960,  -560,  -960, -1300}
    }
   ,{{   690,   290,   690,   290, -1300}
    ,{  -830, -1470,  -830, -1470, -1810}
    ,{  -560,  -960,  -560,  -960, -1300}
    ,{   690,   290,   690,   290, -1300}
    ,{  -560,  -960,  -560,  -960, -1300}
    }
   ,{{  -560,  -960,  -560,  -960, -1300}
    ,{  -560,  -960,  -560,  -960, -1300}
    ,{  -560,  -960,  -560,  -960, -1300}
    ,{  -560,  -960,  -560,  -960, -1300}
    ,{  -560,  -960,  -560,  -960, -1300}
    }
   }
  }
 ,{{{{  1170,   970,  1120,   780,  1170}
    ,{   780,   440,   580,   780,   640}
    ,{   480,   170,   280,   480,   340}
    ,{  1170,   970,  1120,   660,  1170}
    ,{   480,   170,   280,   480,   340}
    }
   ,{{   780,   440,   580,   780,   640}
    ,{   780,   440,   580,   780,   640}
    ,{   470,   130,   270,   470,   330}
    ,{  -510,  -950,  -570, -1260,  -510}
    ,{   470,   130,   270,   470,   330}
    }
   ,{{   490,   170,   290,   490,   340}
    ,{   490,   140,   290,   490,   340}
    ,{   480,   170,   280,   480,   340}
    ,{   490,   140,   290,   490,   340}
    ,{   480,   170,   280,   480,   340}
    }
   ,{{  1170,   970,  1120,   660,  1170}
    ,{  -330,  -770,  -390, -1080,  -330}
    ,{   470,   130,   270,   470,   330}
    ,{  1170,   970,  1120,   660,  1170}
    ,{   470,   130,   270,   470,   330}
    }
   ,{{   490,   170,   290,   490,   340}
    ,{   490,   140,   290,   490,   340}
    ,{   480,   170,   280,   480,   340}
    ,{   490,   140,   290,   490,   340}
    ,{  -600,  -600,  -690, -1150,  -640}
    }
   }
  ,{{{  1120,   970,  1120,   -60,  1120}
    ,{   580,   440,   580,   -60,   580}
    ,{   280,   140,   280,  -120,   280}
    ,{  1120,   970,  1120,  -350,  1120}
    ,{   280,   140,   280,  -120,   280}
    }
   ,{{   580,   440,   580,   -60,   580}
    ,{   580,   440,   580,   -60,   580}
    ,{   270,   130,   270,  -370,   270}
    ,{  -800,  -950,  -800, -1450,  -800}
    ,{   270,   130,   270,  -370,   270}
    }
   ,{{   290,   140,   290,  -120,   290}
    ,{   290,   140,   290,  -350,   290}
    ,{   280,   140,   280,  -120,   280}
    ,{   290,   140,   290,  -350,   290}
    ,{   280,   140,   280,  -120,   280}
    }
   ,{{  1120,   970,  1120,  -370,  1120}
    ,{  -620,  -770,  -620, -1270,  -620}
    ,{   270,   130,   270,  -370,   270}
    ,{  1120,   970,  1120,  -780,  1120}
    ,{   270,   130,   270,  -370,   270}
    }
   ,{{   290,   140,   290,  -120,   290}
    ,{   290,   140,   290,  -350,   290}
    ,{   280,   140,   280,  -120,   280}
    ,{   290,   140,   290,  -350,   290}
    ,{  -600,  -600,  -690, -1340,  -690}
    }
   }
  ,{{{  1170,   660,  1110,   660,  1170}
    ,{   640,   130,   580,   130,   640}
    ,{   340,  -170,   280,  -170,   340}
    ,{  1170,   660,  1110,   660,  1170}
    ,{   340,  -170,   280,  -170,   340}
    }
   ,{{   640,   130,   580,   130,   640}
    ,{   640,   130,   580,   130,   640}
    ,{   330,  -180,   270,  -180,   330}
    ,{  -510, -1260,  -570, -1260,  -510}
    ,{   330,  -180,   270,  -180,   330}
    }
   ,{{   340,  -160,   280,  -160,   340}
    ,{   340,  -160,   280,  -160,   340}
    ,{   340,  -170,   280,  -170,   340}
    ,{   340,  -160,   280,  -160,   340}
    ,{   340,  -170,   280,  -170,   340}
    }
   ,{{  1170,   660,  1110,   660,  1170}
    ,{  -330, -1080,  -390, -1080,  -330}
    ,{   330,  -180,   270,  -180,   330}
    ,{  1170,   660,  1110,   660,  1170}
    ,{   330,  -180,   270,  -180,   330}
    }
   ,{{   340,  -160,   280,  -160,   340}
    ,{   340,  -160,   280,  -160,   340}
    ,{   340,  -170,   280,  -170,   340}
    ,{   340,  -160,   280,  -160,   340}
    ,{  -640, -1150,  -700, -1150,  -640}
    }
   }
  ,{{{  1120,   220,  1120,   780,  1120}
    ,{   780,   220,   580,   780,   580}
    ,{   480,   170,   280,   480,   280}
    ,{  1120,   -70,  1120,   490,  1120}
    ,{   480,   170,   280,   480,   280}
    }
   ,{{   780,   220,   580,   780,   580}
    ,{   780,   220,   580,   780,   580}
    ,{   470,   -80,   270,   470,   270}
    ,{  -800, -1160,  -800, -1860,  -800}
    ,{   470,   -80,   270,   470,   270}
    }
   ,{{   490,   170,   290,   490,   290}
    ,{   490,   -70,   290,   490,   290}
    ,{   480,   170,   280,   480,   280}
    ,{   490,   -70,   290,   490,   290}
    ,{   480,   170,   280,   480,   280}
    }
   ,{{  1120,   -80,  1120,   470,  1120}
    ,{  -620,  -980,  -620, -1680,  -620}
    ,{   470,   -80,   270,   470,   270}
    ,{  1120,  -490,  1120, -1190,  1120}
    ,{   470,   -80,   270,   470,   270}
    }
   ,{{   490,   170,   290,   490,   290}
    ,{   490,   -70,   290,   490,   290}
    ,{   480,   170,   280,   480,   280}
    ,{   490,   -70,   290,   490,   290}
    ,{  -690, -1050,  -690, -1750,  -690}
    }
   }
  ,{{{  1060,   660,  1060,   660,    40}
    ,{   530,   130,   530,   130,    40}
    ,{   230,  -170,   230,  -170,  -500}
    ,{  1060,   660,  1060,   660,  -500}
    ,{   230,  -170,   230,  -170,  -500}
    }
   ,{{   530,   130,   530,   130,    40}
    ,{   530,   130,   530,   130,    40}
    ,{   220,  -180,   220,  -180,  -510}
    ,{  -620, -1260,  -620, -1260, -1590}
    ,{   220,  -180,   220,  -180,  -510}
    }
   ,{{   230,  -160,   230,  -160,  -500}
    ,{   230,  -160,   230,  -160,  -500}
    ,{   230,  -170,   230,  -170,  -500}
    ,{   230,  -160,   230,  -160,  -500}
    ,{   230,  -170,   230,  -170,  -500}
    }
   ,{{  1060,   660,  1060,   660,  -510}
    ,{  -440, -1080,  -440, -1080, -1410}
    ,{   220,  -180,   220,  -180,  -510}
    ,{  1060,   660,  1060,   660,  -920}
    ,{   220,  -180,   220,  -180,  -510}
    }
   ,{{   230,  -160,   230,  -160,  -500}
    ,{   230,  -160,   230,  -160,  -500}
    ,{   230,  -170,   230,  -170,  -500}
    ,{   230,  -160,   230,  -160,  -500}
    ,{  -750, -1150,  -750, -1150, -1480}
    }
   }
  }
 ,{{{{  1350,  1160,  1300,   850,  1350}
    ,{   850,   500,   650,   850,   700}
    ,{   720,   400,   520,   720,   570}
    ,{  1350,  1160,  1300,   850,  1350}
    ,{   590,   270,   390,   590,   440}
    }
   ,{{   850,   500,   650,   850,   700}
    ,{   850,   500,   650,   850,   700}
    ,{   570,   220,   370,   570,   420}
    ,{  -460,  -900,  -520, -1210,  -460}
    ,{   570,   220,   370,   570,   420}
    }
   ,{{   720,   400,   520,   720,   570}
    ,{   720,   370,   520,   720,   570}
    ,{   720,   400,   520,   720,   570}
    ,{   720,   370,   520,   720,   570}
    ,{   590,   270,   390,   590,   440}
    }
   ,{{  1350,  1160,  1300,   850,  1350}
    ,{  -760, -1200,  -820, -1510,  -760}
    ,{   570,   220,   370,   570,   420}
    ,{  1350,  1160,  1300,   850,  1350}
    ,{   570,   220,   370,   570,   420}
    }
   ,{{   720,   370,   520,   720,   570}
    ,{   720,   370,   520,   720,   570}
    ,{   280,   -40,    80,   280,   130}
    ,{   720,   370,   520,   720,   570}
    ,{  -320,  -320,  -420,  -870,  -360}
    }
   }
  ,{{{  1300,  1160,  1300,   120,  1300}
    ,{   650,   500,   650,     0,   650}
    ,{   520,   370,   520,   120,   520}
    ,{  1300,  1160,  1300,  -120,  1300}
    ,{   390,   240,   390,   -10,   390}
    }
   ,{{   650,   500,   650,     0,   650}
    ,{   650,   500,   650,     0,   650}
    ,{   370,   220,   370,  -270,   370}
    ,{  -750,  -900,  -750, -1400,  -750}
    ,{   370,   220,   370,  -270,   370}
    }
   ,{{   520,   370,   520,   120,   520}
    ,{   520,   370,   520,  -120,   520}
    ,{   520,   370,   520,   120,   520}
    ,{   520,   370,   520,  -120,   520}
    ,{   390,   240,   390,   -10,   390}
    }
   ,{{  1300,  1160,  1300,  -270,  1300}
    ,{ -1050, -1200, -1050, -1700, -1050}
    ,{   370,   220,   370,  -270,   370}
    ,{  1300,  1160,  1300,  -590,  1300}
    ,{   370,   220,   370,  -270,   370}
    }
   ,{{   520,   370,   520,  -120,   520}
    ,{   520,   370,   520,  -120,   520}
    ,{    80,   -60,    80,  -320,    80}
    ,{   520,   370,   520,  -120,   520}
    ,{  -320,  -320,  -420, -1060,  -420}
    }
   }
  ,{{{  1350,   850,  1290,   850,  1350}
    ,{   700,   190,   640,   190,   700}
    ,{   570,    60,   510,    60,   570}
    ,{  1350,   850,  1290,   850,  1350}
    ,{   440,   -60,   380,   -60,   440}
    }
   ,{{   700,   190,   640,   190,   700}
    ,{   700,   190,   640,   190,   700}
    ,{   420,   -80,   360,   -80,   420}
    ,{  -460, -1210,  -520, -1210,  -460}
    ,{   420,   -80,   360,   -80,   420}
    }
   ,{{   570,    60,   510,    60,   570}
    ,{   570,    60,   510,    60,   570}
    ,{   570,    60,   510,    60,   570}
    ,{   570,    60,   510,    60,   570}
    ,{   440,   -60,   380,   -60,   440}
    }
   ,{{  1350,   850,  1290,   850,  1350}
    ,{  -760, -1510,  -820, -1510,  -760}
    ,{   420,   -80,   360,   -80,   420}
    ,{  1350,   850,  1290,   850,  1350}
    ,{   420,   -80,   360,   -80,   420}
    }
   ,{{   570,    60,   510,    60,   570}
    ,{   570,    60,   510,    60,   570}
    ,{   130,  -370,    70,  -370,   130}
    ,{   570,    60,   510,    60,   570}
    ,{  -360,  -870,  -420,  -870,  -360}
    }
   }
  ,{{{  1300,   400,  1300,   850,  1300}
    ,{   850,   290,   650,   850,   650}
    ,{   720,   400,   520,   720,   520}
    ,{  1300,   160,  1300,   720,  1300}
    ,{   590,   270,   390,   590,   390}
    }
   ,{{   850,   290,   650,   850,   650}
    ,{   850,   290,   650,   850,   650}
    ,{   570,    10,   370,   570,   370}
    ,{  -750, -1110,  -750, -1810,  -750}
    ,{   570,    10,   370,   570,   370}
    }
   ,{{   720,   400,   520,   720,   520}
    ,{   720,   160,   520,   720,   520}
    ,{   720,   400,   520,   720,   520}
    ,{   720,   160,   520,   720,   520}
    ,{   590,   270,   390,   590,   390}
    }
   ,{{  1300,    10,  1300,   570,  1300}
    ,{ -1050, -1410, -1050, -2110, -1050}
    ,{   570,    10,   370,   570,   370}
    ,{  1300,  -310,  1300, -1000,  1300}
    ,{   570,    10,   370,   570,   370}
    }
   ,{{   720,   160,   520,   720,   520}
    ,{   720,   160,   520,   720,   520}
    ,{   280,   -40,    80,   280,    80}
    ,{   720,   160,   520,   720,   520}
    ,{  -420,  -780,  -420, -1470,  -420}
    }
   }
  ,{{{  1250,   850,  1250,   850,   100}
    ,{   590,   190,   590,   190,   100}
    ,{   460,    60,   460,    60,  -270}
    ,{  1250,   850,  1250,   850,  -270}
    ,{   330,   -60,   330,   -60,  -400}
    }
   ,{{   590,   190,   590,   190,   100}
    ,{   590,   190,   590,   190,   100}
    ,{   310,   -80,   310,   -80,  -420}
    ,{  -570, -1210,  -570, -1210, -1540}
    ,{   310,   -80,   310,   -80,  -420}
    }
   ,{{   460,    60,   460,    60,  -270}
    ,{   460,    60,   460,    60,  -270}
    ,{   460,    60,   460,    60,  -270}
    ,{   460,    60,   460,    60,  -270}
    ,{   330,   -60,   330,   -60,  -400}
    }
   ,{{  1250,   850,  1250,   850,  -420}
    ,{  -870, -1510,  -870, -1510, -1840}
    ,{   310,   -80,   310,   -80,  -420}
    ,{  1250,   850,  1250,   850,  -740}
    ,{   310,   -80,   310,   -80,  -420}
    }
   ,{{   460,    60,   460,    60,  -270}
    ,{   460,    60,   460,    60,  -270}
    ,{    20,  -370,    20,  -370,  -710}
    ,{   460,    60,   460,    60,  -270}
    ,{  -470,  -870,  -470,  -870, -1210}
    }
   }
  }
 ,{{{{  1350,  1160,  1300,   850,  1350}
    ,{   850,   500,   650,   850,   700}
    ,{   720,   400,   520,   720,   570}
    ,{  1350,  1160,  1300,   850,  1350}
    ,{   590,   270,   390,   590,   440}
    }
   ,{{   850,   500,   650,   850,   700}
    ,{   850,   500,   650,   850,   700}
    ,{   570,   220,   370,   570,   420}
    ,{  -230,  -670,  -290,  -980,  -230}
    ,{   570,   220,   370,   570,   420}
    }
   ,{{   720,   400,   520,   720,   570}
    ,{   720,   370,   520,   720,   570}
    ,{   720,   400,   520,   720,   570}
    ,{   720,   370,   520,   720,   570}
    ,{   590,   270,   390,   590,   440}
    }
   ,{{  1350,  1160,  1300,   850,  1350}
    ,{  -330,  -770,  -390, -1080,  -330}
    ,{   570,   220,   370,   570,   420}
    ,{  1350,  1160,  1300,   850,  1350}
    ,{   570,   220,   370,   570,   420}
    }
   ,{{   720,   370,   520,   720,   570}
    ,{   720,   370,   520,   720,   570}
    ,{   480,   170,   280,   480,   340}
    ,{   720,   370,   520,   720,   570}
    ,{   -90,  -320,   -90,  -810,  -360}
    }
   }
  ,{{{  1300,  1160,  1300,   540,  1300}
    ,{   650,   500,   650,    10,   650}
    ,{   540,   370,   520,   540,   520}
    ,{  1300,  1160,  1300,  -120,  1300}
    ,{   390,   240,   390,   -10,   390}
    }
   ,{{   650,   500,   650,     0,   650}
    ,{   650,   500,   650,     0,   650}
    ,{   370,   220,   370,  -100,   370}
    ,{  -530,  -670,  -530, -1170,  -530}
    ,{   370,   220,   370,  -270,   370}
    }
   ,{{   540,   370,   520,   540,   520}
    ,{   520,   370,   520,    10,   520}
    ,{   540,   370,   520,   540,   520}
    ,{   520,   370,   520,  -120,   520}
    ,{   390,   240,   390,   -10,   390}
    }
   ,{{  1300,  1160,  1300,  -270,  1300}
    ,{  -620,  -770,  -620, -1270,  -620}
    ,{   370,   220,   370,  -270,   370}
    ,{  1300,  1160,  1300,  -590,  1300}
    ,{   370,   220,   370,  -270,   370}
    }
   ,{{   520,   370,   520,  -120,   520}
    ,{   520,   370,   520,  -120,   520}
    ,{   280,   140,   280,  -120,   280}
    ,{   520,   370,   520,  -120,   520}
    ,{   -90,  -320,   -90,  -810,  -420}
    }
   }
  ,{{{  1350,   850,  1290,   850,  1350}
    ,{   700,   190,   640,   190,   700}
    ,{   570,    60,   510,    60,   570}
    ,{  1350,   850,  1290,   850,  1350}
    ,{   440,   -60,   380,   -60,   440}
    }
   ,{{   700,   190,   640,   190,   700}
    ,{   700,   190,   640,   190,   700}
    ,{   420,   -80,   360,   -80,   420}
    ,{  -230,  -980,  -290,  -980,  -230}
    ,{   420,   -80,   360,   -80,   420}
    }
   ,{{   570,    60,   510,    60,   570}
    ,{   570,    60,   510,    60,   570}
    ,{   570,    60,   510,    60,   570}
    ,{   570,    60,   510,    60,   570}
    ,{   440,   -60,   380,   -60,   440}
    }
   ,{{  1350,   850,  1290,   850,  1350}
    ,{  -330, -1070,  -390, -1080,  -330}
    ,{   420,   -80,   360,   -80,   420}
    ,{  1350,   850,  1290,   850,  1350}
    ,{   420,   -80,   360,   -80,   420}
    }
   ,{{   570,    60,   510,    60,   570}
    ,{   570,    60,   510,    60,   570}
    ,{   340,  -170,   280,  -170,   340}
    ,{   570,    60,   510,    60,   570}
    ,{  -360,  -830,  -420,  -870,  -360}
    }
   }
  ,{{{  1300,   400,  1300,   850,  1300}
    ,{   850,   290,   650,   850,   650}
    ,{   720,   400,   520,   720,   520}
    ,{  1300,   160,  1300,   720,  1300}
    ,{   590,   270,   390,   590,   390}
    }
   ,{{   850,   290,   650,   850,   650}
    ,{   850,   290,   650,   850,   650}
    ,{   570,    10,   370,   570,   370}
    ,{  -530,  -890,  -530, -1580,  -530}
    ,{   570,    10,   370,   570,   370}
    }
   ,{{   720,   400,   520,   720,   520}
    ,{   720,   160,   520,   720,   520}
    ,{   720,   400,   520,   720,   520}
    ,{   720,   160,   520,   720,   520}
    ,{   590,   270,   390,   590,   390}
    }
   ,{{  1300,    10,  1300,   570,  1300}
    ,{  -620,  -980,  -620, -1080,  -620}
    ,{   570,    10,   370,   570,   370}
    ,{  1300,  -310,  1300, -1000,  1300}
    ,{   570,    10,   370,   570,   370}
    }
   ,{{   720,   170,   520,   720,   520}
    ,{   720,   160,   520,   720,   520}
    ,{   480,   170,   280,   480,   280}
    ,{   720,   160,   520,   720,   520}
    ,{  -420,  -780,  -420, -1470,  -420}
    }
   }
  ,{{{  1250,   850,  1250,   850,   100}
    ,{   590,   190,   590,   190,   100}
    ,{   460,    60,   460,    60,  -270}
    ,{  1250,   850,  1250,   850,  -230}
    ,{   330,   -60,   330,   -60,  -400}
    }
   ,{{   590,   190,   590,   190,   100}
    ,{   590,   190,   590,   190,   100}
    ,{   310,   -80,   310,   -80,  -420}
    ,{  -340,  -980,  -340,  -980, -1320}
    ,{   310,   -80,   310,   -80,  -420}
    }
   ,{{   460,    60,   460,    60,  -270}
    ,{   460,    60,   460,    60,  -270}
    ,{   460,    60,   460,    60,  -270}
    ,{   460,    60,   460,    60,  -270}
    ,{   330,   -60,   330,   -60,  -400}
    }
   ,{{  1250,   850,  1250,   850,  -230}
    ,{  -440, -1080,  -440, -1080, -1300}
    ,{   310,   -80,   310,   -80,  -420}
    ,{  1250,   850,  1250,   850,  -230}
    ,{   310,   -80,   310,   -80,  -420}
    }
   ,{{   460,    60,   460,    60,  -270}
    ,{   460,    60,   460,    60,  -270}
    ,{   230,  -170,   230,  -170,  -500}
    ,{   460,    60,   460,    60,  -270}
    ,{  -470,  -870,  -470,  -870, -1210}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   540,   -90,   540,   180,   -90}
    ,{   540,  -100,   540,   180,   -90}
    ,{   180,   -90,  -460,   180,  -460}
    ,{    30,  -150,  -260,    30,  -210}
    ,{  -200,  -200,  -400,  -230,  -570}
    }
   ,{{   180,  -350,  -660,   180,  -660}
    ,{   180,  -580,  -660,   180,  -660}
    ,{  -430,  -600,  -970,  -430,  -830}
    ,{  -350,  -350,  -870,  -960,  -870}
    ,{  -430,  -600,  -970,  -430,  -970}
    }
   ,{{    30,  -150,  -510,    30,   -90}
    ,{   -90,  -220,  -510,  -390,   -90}
    ,{    20,  -600,  -520,    20,  -520}
    ,{    30,  -150,  -510,    30,  -510}
    ,{  -200,  -200,  -570,  -650,  -570}
    }
   ,{{   540,  -100,   540,  -400,  -210}
    ,{   540,  -100,   540, -1240,  -810}
    ,{  -430,  -600,  -970,  -430,  -970}
    ,{  -200,  -200,  -260,  -400,  -210}
    ,{  -430,  -600,  -970,  -430,  -970}
    }
   ,{{   180,   -90,  -400,   180,  -460}
    ,{    30,  -150,  -510,    30,  -510}
    ,{   180,   -90,  -460,   180,  -460}
    ,{    30,  -150,  -510,    30,  -510}
    ,{  -230, -1390,  -400,  -230, -1300}
    }
   }
  ,{{{    10,   -90,    10,  -500,  -320}
    ,{    10,  -150,    10,  -860,  -510}
    ,{   -90,   -90,  -460,  -500,  -460}
    ,{  -150,  -150,  -320,  -860,  -320}
    ,{  -200,  -200,  -400, -1300,  -570}
    }
   ,{{  -580,  -580,  -660, -1070,  -660}
    ,{  -580,  -580,  -660, -1340,  -660}
    ,{  -600,  -600,  -970, -1070,  -970}
    ,{  -870, -1600, -1110, -1880,  -870}
    ,{  -600,  -600,  -970, -1320,  -970}
    }
   ,{{  -150,  -150,  -510,  -500,  -510}
    ,{  -220,  -220, -1150,  -860,  -510}
    ,{  -500, -1070,  -750,  -500,  -520}
    ,{  -150,  -150,  -510,  -860,  -510}
    ,{  -200,  -200,  -570, -1750,  -570}
    }
   ,{{    10,  -200,    10, -1080,  -320}
    ,{    10,  -970,    10, -2450, -1160}
    ,{  -600,  -600,  -970, -1320,  -970}
    ,{  -200,  -200,  -320, -1080,  -320}
    ,{  -600,  -600,  -970, -1320,  -970}
    }
   ,{{   -90,   -90,  -400,  -570,  -460}
    ,{  -150,  -150,  -510,  -860,  -510}
    ,{   -90,   -90,  -460,  -570,  -460}
    ,{  -150,  -150,  -510,  -860,  -510}
    ,{  -400, -1490,  -400, -1300, -1300}
    }
   }
  ,{{{   540,  -100,   540,  -400,  -210}
    ,{   540,  -100,   540,  -600, -1130}
    ,{  -540,  -540,  -760,  -540, -1070}
    ,{  -210,  -350,  -620,  -400,  -210}
    ,{  -650,  -650,  -870,  -650, -1180}
    }
   ,{{  -350,  -350,  -940,  -740, -1250}
    ,{  -740,  -740,  -960,  -740, -1270}
    ,{ -1050, -1050, -1270, -1050, -1580}
    ,{  -350,  -350,  -940,  -960, -1250}
    ,{ -1050, -1050, -1270, -1050, -1580}
    }
   ,{{  -600,  -600,  -820,  -600, -1130}
    ,{  -600,  -600,  -820,  -600, -1130}
    ,{  -600,  -600,  -820,  -600, -1130}
    ,{  -600,  -600,  -820,  -600, -1130}
    ,{  -650,  -650,  -870,  -650, -1180}
    }
   ,{{   540,  -100,   540,  -400,  -210}
    ,{   540,  -100,   540, -1240, -1530}
    ,{ -1050, -1050, -1270, -1050, -1580}
    ,{  -210,  -440,  -620,  -400,  -210}
    ,{ -1050, -1050, -1270, -1050, -1580}
    }
   ,{{  -540,  -540,  -760,  -540, -1070}
    ,{  -600,  -600,  -820,  -600, -1130}
    ,{  -540,  -540,  -760,  -540, -1070}
    ,{  -600,  -600,  -820,  -600, -1130}
    ,{ -1390, -1390, -1610, -1390, -1920}
    }
   }
  ,{{{   180,  -630,  -320,   180,  -320}
    ,{   180, -1340,  -510,   180,  -510}
    ,{   180,  -630,  -460,   180,  -460}
    ,{    30, -1340,  -320,    30,  -320}
    ,{  -230, -1150,  -570,  -230,  -570}
    }
   ,{{   180, -1790,  -660,   180,  -660}
    ,{   180, -2010,  -660,   180,  -660}
    ,{  -430, -1790,  -970,  -430,  -970}
    ,{  -870, -3070,  -870, -1370,  -870}
    ,{  -430, -1790,  -970,  -430,  -970}
    }
   ,{{    30,  -630,  -510,    30,  -510}
    ,{  -390, -1650,  -510,  -390,  -510}
    ,{    20,  -630,  -520,    20,  -520}
    ,{    30, -1340,  -510,    30,  -510}
    ,{  -570, -1150,  -570,  -880,  -570}
    }
   ,{{  -320, -1790,  -320,  -430,  -320}
    ,{ -1160, -1980, -1160, -1870, -1160}
    ,{  -430, -1790,  -970,  -430,  -970}
    ,{  -320, -2390,  -320, -2280,  -320}
    ,{  -430, -1790,  -970,  -430,  -970}
    }
   ,{{   180, -1040,  -460,   180,  -460}
    ,{    30, -1340,  -510,    30,  -510}
    ,{   180, -1040,  -460,   180,  -460}
    ,{    30, -1340,  -510,    30,  -510}
    ,{  -230, -1520, -1300,  -230, -1300}
    }
   }
  ,{{{   -90,  -400,  -260,  -400,   -90}
    ,{   -90,  -600,  -820,  -600,   -90}
    ,{  -540,  -540,  -550,  -540,  -830}
    ,{  -260,  -400,  -260,  -400,  -800}
    ,{  -650,  -650,  -870,  -650,  -860}
    }
   ,{{  -740,  -740,  -940,  -740,  -830}
    ,{  -740,  -740,  -960,  -740, -1240}
    ,{  -830, -1050, -1270, -1050,  -830}
    ,{  -940,  -960,  -940,  -960, -1360}
    ,{ -1050, -1050, -1270, -1050, -1260}
    }
   ,{{   -90,  -600,  -820,  -600,   -90}
    ,{   -90,  -600,  -820,  -600,   -90}
    ,{  -600,  -600,  -820,  -600, -1710}
    ,{  -600,  -600,  -820,  -600,  -800}
    ,{  -650,  -650,  -870,  -650,  -860}
    }
   ,{{  -260,  -400,  -260,  -400,  -810}
    ,{  -810, -1240, -1220, -1240,  -810}
    ,{ -1050, -1050, -1270, -1050, -1260}
    ,{  -260,  -400,  -260,  -400, -1550}
    ,{ -1050, -1050, -1270, -1050, -1260}
    }
   ,{{  -540,  -540,  -550,  -540,  -800}
    ,{  -600,  -600,  -820,  -600,  -800}
    ,{  -540,  -540,  -550,  -540, -1460}
    ,{  -600,  -600,  -820,  -600,  -800}
    ,{ -1390, -1390, -1610, -1390, -2350}
    }
   }
  }
 ,{{{{    50,    50,  -320,    50,  -320}
    ,{    50,  -130,  -490,    50,  -490}
    ,{  -400,  -580,  -940,  -400,  -940}
    ,{    50,    50,  -320,  -320,  -320}
    ,{  -400,  -540,  -940,  -400,  -940}
    }
   ,{{    50,  -130,  -490,    50,  -490}
    ,{    50,  -130,  -490,    50,  -490}
    ,{  -400,  -580,  -940,  -400,  -940}
    ,{ -1320, -1320, -1680, -1770, -1680}
    ,{  -400,  -580,  -940,  -400,  -940}
    }
   ,{{  -320,  -490,  -860,  -320,  -860}
    ,{  -320,  -490,  -860,  -320,  -860}
    ,{  -620,  -800, -1160,  -620, -1160}
    ,{  -320,  -490,  -860,  -320,  -860}
    ,{  -620,  -800, -1160,  -620, -1160}
    }
   ,{{    50,    50,  -320,  -400,  -320}
    ,{  -840,  -840, -1210, -1290, -1210}
    ,{  -400,  -580,  -940,  -400,  -940}
    ,{    50,    50,  -320,  -400,  -320}
    ,{  -400,  -580,  -940,  -400,  -940}
    }
   ,{{  -320,  -490,  -860,  -320,  -860}
    ,{  -320,  -490,  -860,  -320,  -860}
    ,{  -930, -1110, -1470,  -930, -1470}
    ,{  -320,  -490,  -860,  -320,  -860}
    ,{  -540,  -540, -1150, -1230, -1150}
    }
   }
  ,{{{    50,    50,  -320,  -840,  -320}
    ,{  -130,  -130,  -490,  -840,  -490}
    ,{  -580,  -580,  -940, -1270,  -940}
    ,{    50,    50,  -320, -1210,  -320}
    ,{  -540,  -540,  -940, -1270,  -940}
    }
   ,{{  -130,  -130,  -490,  -840,  -490}
    ,{  -130,  -130,  -490,  -840,  -490}
    ,{  -580,  -580,  -940, -1290,  -940}
    ,{ -1320, -1320, -1680, -2030, -1680}
    ,{  -580,  -580,  -940, -1290,  -940}
    }
   ,{{  -490,  -490,  -860, -1210,  -860}
    ,{  -490,  -490,  -860, -1210,  -860}
    ,{  -800,  -800, -1160, -1270, -1160}
    ,{  -490,  -490,  -860, -1210,  -860}
    ,{  -800,  -800, -1160, -1270, -1160}
    }
   ,{{    50,    50,  -320, -1290,  -320}
    ,{  -840,  -840, -1210, -1560, -1210}
    ,{  -580,  -580,  -940, -1290,  -940}
    ,{    50,    50,  -320, -1920,  -320}
    ,{  -580,  -580,  -940, -1290,  -940}
    }
   ,{{  -490,  -490,  -860, -1210,  -860}
    ,{  -490,  -490,  -860, -1210,  -860}
    ,{ -1110, -1110, -1470, -1580, -1470}
    ,{  -490,  -490,  -860, -1210,  -860}
    ,{  -540,  -540, -1150, -1500, -1150}
    }
   }
  ,{{{  -400,  -400,  -620,  -400,  -930}
    ,{  -580,  -580,  -800,  -580, -1110}
    ,{ -1030, -1030, -1250, -1030, -1560}
    ,{  -400,  -400,  -620,  -400,  -930}
    ,{ -1030, -1030, -1250, -1030, -1560}
    }
   ,{{  -580,  -580,  -800,  -580, -1110}
    ,{  -580,  -580,  -800,  -580, -1110}
    ,{ -1030, -1030, -1250, -1030, -1560}
    ,{ -1750, -1770, -1750, -1770, -2060}
    ,{ -1030, -1030, -1250, -1030, -1560}
    }
   ,{{  -940,  -940, -1160,  -940, -1470}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{ -1250, -1250, -1470, -1250, -1780}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{ -1250, -1250, -1470, -1250, -1780}
    }
   ,{{  -400,  -400,  -620,  -400,  -930}
    ,{ -1270, -1290, -1270, -1290, -1580}
    ,{ -1030, -1030, -1250, -1030, -1560}
    ,{  -400,  -400,  -620,  -400,  -930}
    ,{ -1030, -1030, -1250, -1030, -1560}
    }
   ,{{  -940,  -940, -1160,  -940, -1470}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{ -1560, -1560, -1780, -1560, -2090}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{ -1230, -1230, -1450, -1230, -1760}
    }
   }
  ,{{{    50, -1320,  -320,    50,  -320}
    ,{    50, -1320,  -490,    50,  -490}
    ,{  -400, -1750,  -940,  -400,  -940}
    ,{  -320, -1680,  -320,  -320,  -320}
    ,{  -400, -1750,  -940,  -400,  -940}
    }
   ,{{    50, -1320,  -490,    50,  -490}
    ,{    50, -1320,  -490,    50,  -490}
    ,{  -400, -1770,  -940,  -400,  -940}
    ,{ -1680, -2510, -1680, -2390, -1680}
    ,{  -400, -1770,  -940,  -400,  -940}
    }
   ,{{  -320, -1680,  -860,  -320,  -860}
    ,{  -320, -1680,  -860,  -320,  -860}
    ,{  -620, -1750, -1160,  -620, -1160}
    ,{  -320, -1680,  -860,  -320,  -860}
    ,{  -620, -1750, -1160,  -620, -1160}
    }
   ,{{  -320, -1770,  -320,  -400,  -320}
    ,{ -1210, -2030, -1210, -1920, -1210}
    ,{  -400, -1770,  -940,  -400,  -940}
    ,{  -320, -2390,  -320, -2280,  -320}
    ,{  -400, -1770,  -940,  -400,  -940}
    }
   ,{{  -320, -1680,  -860,  -320,  -860}
    ,{  -320, -1680,  -860,  -320,  -860}
    ,{  -930, -2060, -1470,  -930, -1470}
    ,{  -320, -1680,  -860,  -320,  -860}
    ,{ -1150, -1970, -1150, -1860, -1150}
    }
   }
  ,{{{  -400,  -400,  -620,  -400,  -540}
    ,{  -540,  -580,  -800,  -580,  -540}
    ,{ -1030, -1030, -1250, -1030, -1230}
    ,{  -400,  -400,  -620,  -400, -1150}
    ,{ -1030, -1030, -1250, -1030, -1230}
    }
   ,{{  -540,  -580,  -800,  -580,  -540}
    ,{  -540,  -580,  -800,  -580,  -540}
    ,{ -1030, -1030, -1250, -1030, -1230}
    ,{ -1750, -1770, -1750, -1770, -1970}
    ,{ -1030, -1030, -1250, -1030, -1230}
    }
   ,{{  -940,  -940, -1160,  -940, -1150}
    ,{  -940,  -940, -1160,  -940, -1150}
    ,{ -1250, -1250, -1470, -1250, -1450}
    ,{  -940,  -940, -1160,  -940, -1150}
    ,{ -1250, -1250, -1470, -1250, -1450}
    }
   ,{{  -400,  -400,  -620,  -400, -1230}
    ,{ -1270, -1290, -1270, -1290, -1500}
    ,{ -1030, -1030, -1250, -1030, -1230}
    ,{  -400,  -400,  -620,  -400, -1860}
    ,{ -1030, -1030, -1250, -1030, -1230}
    }
   ,{{  -940,  -940, -1160,  -940, -1150}
    ,{  -940,  -940, -1160,  -940, -1150}
    ,{ -1560, -1560, -1780, -1560, -1760}
    ,{  -940,  -940, -1160,  -940, -1150}
    ,{ -1230, -1230, -1450, -1230, -1440}
    }
   }
  }
 ,{{{{   210,   210,  -160,  -240,  -160}
    ,{  -870,  -870, -1230,  -870, -1230}
    ,{  -870, -1040, -1410,  -870, -1410}
    ,{   210,   210,  -160,  -240,  -160}
    ,{  -800,  -800, -1410,  -870, -1410}
    }
   ,{{  -870, -1040, -1410,  -870, -1410}
    ,{ -1050, -1220, -1590, -1050, -1590}
    ,{  -870, -1040, -1410,  -870, -1410}
    ,{ -1060, -1060, -1420, -1510, -1420}
    ,{  -870, -1040, -1410,  -870, -1410}
    }
   ,{{  -870, -1040, -1410,  -870, -1410}
    ,{  -870, -1040, -1410,  -870, -1410}
    ,{  -870, -1040, -1410,  -870, -1410}
    ,{  -870, -1040, -1410,  -870, -1410}
    ,{  -870, -1040, -1410,  -870, -1410}
    }
   ,{{   210,   210,  -160,  -240,  -160}
    ,{  -870,  -870, -1230, -1320, -1230}
    ,{  -870, -1040, -1410,  -870, -1410}
    ,{   210,   210,  -160,  -240,  -160}
    ,{  -870, -1040, -1410,  -870, -1410}
    }
   ,{{  -800,  -800, -1410,  -870, -1410}
    ,{  -870, -1040, -1410,  -870, -1410}
    ,{  -870, -1040, -1410,  -870, -1410}
    ,{  -870, -1040, -1410,  -870, -1410}
    ,{  -800,  -800, -1410, -1490, -1410}
    }
   }
  ,{{{   210,   210,  -160, -1520,  -160}
    ,{  -870,  -870, -1230, -1580, -1230}
    ,{ -1040, -1040, -1410, -1520, -1410}
    ,{   210,   210,  -160, -1760,  -160}
    ,{  -800,  -800, -1410, -1520, -1410}
    }
   ,{{ -1040, -1040, -1410, -1760, -1410}
    ,{ -1220, -1220, -1590, -1940, -1590}
    ,{ -1040, -1040, -1410, -1760, -1410}
    ,{ -1060, -1060, -1420, -1770, -1420}
    ,{ -1040, -1040, -1410, -1760, -1410}
    }
   ,{{ -1040, -1040, -1410, -1520, -1410}
    ,{ -1040, -1040, -1410, -1760, -1410}
    ,{ -1040, -1040, -1410, -1520, -1410}
    ,{ -1040, -1040, -1410, -1760, -1410}
    ,{ -1040, -1040, -1410, -1520, -1410}
    }
   ,{{   210,   210,  -160, -1580,  -160}
    ,{  -870,  -870, -1230, -1580, -1230}
    ,{ -1040, -1040, -1410, -1760, -1410}
    ,{   210,   210,  -160, -1760,  -160}
    ,{ -1040, -1040, -1410, -1760, -1410}
    }
   ,{{  -800,  -800, -1410, -1520, -1410}
    ,{ -1040, -1040, -1410, -1760, -1410}
    ,{ -1040, -1040, -1410, -1520, -1410}
    ,{ -1040, -1040, -1410, -1760, -1410}
    ,{  -800,  -800, -1410, -1760, -1410}
    }
   }
  ,{{{  -240,  -240,  -460,  -240,  -770}
    ,{ -1300, -1320, -1300, -1320, -1610}
    ,{ -1490, -1490, -1710, -1490, -2020}
    ,{  -240,  -240,  -460,  -240,  -770}
    ,{ -1490, -1490, -1710, -1490, -2020}
    }
   ,{{ -1490, -1490, -1490, -1490, -1800}
    ,{ -1670, -1670, -1890, -1670, -2200}
    ,{ -1490, -1490, -1710, -1490, -2020}
    ,{ -1490, -1510, -1490, -1510, -1800}
    ,{ -1490, -1490, -1710, -1490, -2020}
    }
   ,{{ -1490, -1490, -1710, -1490, -2020}
    ,{ -1490, -1490, -1710, -1490, -2020}
    ,{ -1490, -1490, -1710, -1490, -2020}
    ,{ -1490, -1490, -1710, -1490, -2020}
    ,{ -1490, -1490, -1710, -1490, -2020}
    }
   ,{{  -240,  -240,  -460,  -240,  -770}
    ,{ -1300, -1320, -1300, -1320, -1610}
    ,{ -1490, -1490, -1710, -1490, -2020}
    ,{  -240,  -240,  -460,  -240,  -770}
    ,{ -1490, -1490, -1710, -1490, -2020}
    }
   ,{{ -1490, -1490, -1710, -1490, -2020}
    ,{ -1490, -1490, -1710, -1490, -2020}
    ,{ -1490, -1490, -1710, -1490, -2020}
    ,{ -1490, -1490, -1710, -1490, -2020}
    ,{ -1490, -1490, -1710, -1490, -2020}
    }
   }
  ,{{{  -160, -1990,  -160,  -870,  -160}
    ,{  -870, -2060, -1230,  -870, -1230}
    ,{  -870, -1990, -1410,  -870, -1410}
    ,{  -160, -2230,  -160,  -870,  -160}
    ,{  -870, -1990, -1410,  -870, -1410}
    }
   ,{{  -870, -2230, -1410,  -870, -1410}
    ,{ -1050, -2410, -1590, -1050, -1590}
    ,{  -870, -2230, -1410,  -870, -1410}
    ,{ -1420, -2250, -1420, -2130, -1420}
    ,{  -870, -2230, -1410,  -870, -1410}
    }
   ,{{  -870, -1990, -1410,  -870, -1410}
    ,{  -870, -2230, -1410,  -870, -1410}
    ,{  -870, -1990, -1410,  -870, -1410}
    ,{  -870, -2230, -1410,  -870, -1410}
    ,{  -870, -1990, -1410,  -870, -1410}
    }
   ,{{  -160, -2060,  -160,  -870,  -160}
    ,{ -1230, -2060, -1230, -1940, -1230}
    ,{  -870, -2230, -1410,  -870, -1410}
    ,{  -160, -2230,  -160, -2120,  -160}
    ,{  -870, -2230, -1410,  -870, -1410}
    }
   ,{{  -870, -1990, -1410,  -870, -1410}
    ,{  -870, -2230, -1410,  -870, -1410}
    ,{  -870, -1990, -1410,  -870, -1410}
    ,{  -870, -2230, -1410,  -870, -1410}
    ,{ -1410, -2230, -1410, -2120, -1410}
    }
   }
  ,{{{  -240,  -240,  -460,  -240, -1520}
    ,{ -1300, -1320, -1300, -1320, -1520}
    ,{ -1490, -1490, -1710, -1490, -1700}
    ,{  -240,  -240,  -460,  -240, -1700}
    ,{ -1490, -1490, -1710, -1490, -1700}
    }
   ,{{ -1490, -1490, -1490, -1490, -1640}
    ,{ -1640, -1670, -1890, -1670, -1640}
    ,{ -1490, -1490, -1710, -1490, -1700}
    ,{ -1490, -1510, -1490, -1510, -1710}
    ,{ -1490, -1490, -1710, -1490, -1700}
    }
   ,{{ -1490, -1490, -1710, -1490, -1700}
    ,{ -1490, -1490, -1710, -1490, -1700}
    ,{ -1490, -1490, -1710, -1490, -1700}
    ,{ -1490, -1490, -1710, -1490, -1700}
    ,{ -1490, -1490, -1710, -1490, -1700}
    }
   ,{{  -240,  -240,  -460,  -240, -1520}
    ,{ -1300, -1320, -1300, -1320, -1520}
    ,{ -1490, -1490, -1710, -1490, -1700}
    ,{  -240,  -240,  -460,  -240, -1700}
    ,{ -1490, -1490, -1710, -1490, -1700}
    }
   ,{{ -1490, -1490, -1710, -1490, -1700}
    ,{ -1490, -1490, -1710, -1490, -1700}
    ,{ -1490, -1490, -1710, -1490, -1700}
    ,{ -1490, -1490, -1710, -1490, -1700}
    ,{ -1490, -1490, -1710, -1490, -1700}
    }
   }
  }
 ,{{{{   760,   760,   400,   310,   400}
    ,{   200,  -430,  -340,   200,  -340}
    ,{  -310,  -490,  -850,  -310,  -850}
    ,{   760,   760,   400,   310,   400}
    ,{  -250,  -250,  -850,  -310,  -850}
    }
   ,{{   200,  -430,  -340,   200,  -340}
    ,{   200,  -430,  -340,   200,  -340}
    ,{  -310,  -490,  -850,  -310,  -850}
    ,{  -830,  -830, -1190, -1280, -1190}
    ,{  -310,  -490,  -850,  -310,  -850}
    }
   ,{{  -310,  -490,  -850,  -310,  -850}
    ,{  -310,  -490,  -850,  -310,  -850}
    ,{  -310,  -490,  -850,  -310,  -850}
    ,{  -310,  -490,  -850,  -310,  -850}
    ,{  -310,  -490,  -850,  -310,  -850}
    }
   ,{{   760,   760,   400,   310,   400}
    ,{ -1000, -1000, -1360, -1450, -1360}
    ,{  -310,  -490,  -850,  -310,  -850}
    ,{   760,   760,   400,   310,   400}
    ,{  -310,  -490,  -850,  -310,  -850}
    }
   ,{{  -250,  -250,  -850,  -310,  -850}
    ,{  -310,  -490,  -850,  -310,  -850}
    ,{  -310,  -490,  -850,  -310,  -850}
    ,{  -310,  -490,  -850,  -310,  -850}
    ,{  -250,  -250,  -850,  -940,  -850}
    }
   }
  ,{{{   760,   760,   400,  -690,   400}
    ,{  -340,  -490,  -340,  -690,  -340}
    ,{  -490,  -490,  -850,  -960,  -850}
    ,{   760,   760,   400, -1200,   400}
    ,{  -250,  -250,  -850,  -960,  -850}
    }
   ,{{  -340,  -490,  -340,  -690,  -340}
    ,{  -340, -2040,  -340,  -690,  -340}
    ,{  -490,  -490,  -850, -1200,  -850}
    ,{  -830,  -830, -1190, -1540, -1190}
    ,{  -490,  -490,  -850, -1200,  -850}
    }
   ,{{  -490,  -490,  -850,  -960,  -850}
    ,{  -490,  -490,  -850, -1200,  -850}
    ,{  -490,  -490,  -850,  -960,  -850}
    ,{  -490,  -490,  -850, -1200,  -850}
    ,{  -490,  -490,  -850,  -960,  -850}
    }
   ,{{   760,   760,   400, -1200,   400}
    ,{ -1000, -1000, -1360, -1710, -1360}
    ,{  -490,  -490,  -850, -1200,  -850}
    ,{   760,   760,   400, -1200,   400}
    ,{  -490,  -490,  -850, -1200,  -850}
    }
   ,{{  -250,  -250,  -850,  -960,  -850}
    ,{  -490,  -490,  -850, -1200,  -850}
    ,{  -490,  -490,  -850,  -960,  -850}
    ,{  -490,  -490,  -850, -1200,  -850}
    ,{  -250,  -250,  -850, -1200,  -850}
    }
   }
  ,{{{   310,   310,    90,   310,  -220}
    ,{  -430,  -430,  -650,  -430,  -960}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{   310,   310,    90,   310,  -220}
    ,{  -940,  -940, -1160,  -940, -1470}
    }
   ,{{  -430,  -430,  -650,  -430,  -960}
    ,{  -430,  -430,  -650,  -430,  -960}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{ -1260, -1280, -1260, -1280, -1570}
    ,{  -940,  -940, -1160,  -940, -1470}
    }
   ,{{  -940,  -940, -1160,  -940, -1470}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{  -940,  -940, -1160,  -940, -1470}
    }
   ,{{   310,   310,    90,   310,  -220}
    ,{ -1430, -1450, -1430, -1450, -1740}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{   310,   310,    90,   310,  -220}
    ,{  -940,  -940, -1160,  -940, -1470}
    }
   ,{{  -940,  -940, -1160,  -940, -1470}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{  -940,  -940, -1160,  -940, -1470}
    ,{  -940,  -940, -1160,  -940, -1470}
    }
   }
  ,{{{   400, -1170,   400,   200,   400}
    ,{   200, -1170,  -340,   200,  -340}
    ,{  -310, -1440,  -850,  -310,  -850}
    ,{   400, -1680,   400,  -310,   400}
    ,{  -310, -1440,  -850,  -310,  -850}
    }
   ,{{   200, -1170,  -340,   200,  -340}
    ,{   200, -1170,  -340,   200,  -340}
    ,{  -310, -1680,  -850,  -310,  -850}
    ,{ -1190, -2020, -1190, -1900, -1190}
    ,{  -310, -1680,  -850,  -310,  -850}
    }
   ,{{  -310, -1440,  -850,  -310,  -850}
    ,{  -310, -1680,  -850,  -310,  -850}
    ,{  -310, -1440,  -850,  -310,  -850}
    ,{  -310, -1680,  -850,  -310,  -850}
    ,{  -310, -1440,  -850,  -310,  -850}
    }
   ,{{   400, -1680,   400,  -310,   400}
    ,{ -1360, -2190, -1360, -2070, -1360}
    ,{  -310, -1680,  -850,  -310,  -850}
    ,{   400, -1680,   400, -1560,   400}
    ,{  -310, -1680,  -850,  -310,  -850}
    }
   ,{{  -310, -1440,  -850,  -310,  -850}
    ,{  -310, -1680,  -850,  -310,  -850}
    ,{  -310, -1440,  -850,  -310,  -850}
    ,{  -310, -1680,  -850,  -310,  -850}
    ,{  -850, -1680,  -850, -1560,  -850}
    }
   }
  ,{{{   310,   310,    90,   310,  -390}
    ,{  -390,  -430,  -650,  -430,  -390}
    ,{  -940,  -940, -1160,  -940, -1140}
    ,{   310,   310,    90,   310, -1140}
    ,{  -940,  -940, -1160,  -940, -1140}
    }
   ,{{  -390,  -430,  -650,  -430,  -390}
    ,{  -390,  -430,  -650,  -430,  -390}
    ,{  -940,  -940, -1160,  -940, -1140}
    ,{ -1260, -1280, -1260, -1280, -1480}
    ,{  -940,  -940, -1160,  -940, -1140}
    }
   ,{{  -940,  -940, -1160,  -940, -1140}
    ,{  -940,  -940, -1160,  -940, -1140}
    ,{  -940,  -940, -1160,  -940, -1140}
    ,{  -940,  -940, -1160,  -940, -1140}
    ,{  -940,  -940, -1160,  -940, -1140}
    }
   ,{{   310,   310,    90,   310, -1140}
    ,{ -1430, -1450, -1430, -1450, -1650}
    ,{  -940,  -940, -1160,  -940, -1140}
    ,{   310,   310,    90,   310, -1140}
    ,{  -940,  -940, -1160,  -940, -1140}
    }
   ,{{  -940,  -940, -1160,  -940, -1140}
    ,{  -940,  -940, -1160,  -940, -1140}
    ,{  -940,  -940, -1160,  -940, -1140}
    ,{  -940,  -940, -1160,  -940, -1140}
    ,{  -940,  -940, -1160,  -940, -1140}
    }
   }
  }
 ,{{{{  1140,  1140,   770,   780,   770}
    ,{   780,   600,   240,   780,   240}
    ,{   480,   300,   -60,   480,   -60}
    ,{  1140,  1140,   770,   690,   770}
    ,{   480,   300,   -60,   480,   -60}
    }
   ,{{   780,   600,   240,   780,   240}
    ,{   780,   600,   240,   780,   240}
    ,{   470,   290,   -70,   470,   -70}
    ,{  -780,  -780, -1150, -1230, -1150}
    ,{   470,   290,   -70,   470,   -70}
    }
   ,{{   490,   310,   -50,   490,   -50}
    ,{   490,   310,   -50,   490,   -50}
    ,{   480,   300,   -60,   480,   -60}
    ,{   490,   310,   -50,   490,   -50}
    ,{   480,   300,   -60,   480,   -60}
    }
   ,{{  1140,  1140,   770,   690,   770}
    ,{  -600,  -600,  -970, -1050,  -970}
    ,{   470,   290,   -70,   470,   -70}
    ,{  1140,  1140,   770,   690,   770}
    ,{   470,   290,   -70,   470,   -70}
    }
   ,{{   490,   310,   -50,   490,   -50}
    ,{   490,   310,   -50,   490,   -50}
    ,{   480,   300,   -60,   480,   -60}
    ,{   490,   310,   -50,   490,   -50}
    ,{  -430,  -430, -1040, -1120, -1040}
    }
   }
  ,{{{  1140,  1140,   770,  -110,   770}
    ,{   600,   600,   240,  -110,   240}
    ,{   300,   300,   -60,  -170,   -60}
    ,{  1140,  1140,   770,  -400,   770}
    ,{   300,   300,   -60,  -170,   -60}
    }
   ,{{   600,   600,   240,  -110,   240}
    ,{   600,   600,   240,  -110,   240}
    ,{   290,   290,   -70,  -420,   -70}
    ,{  -780,  -780, -1150, -1500, -1150}
    ,{   290,   290,   -70,  -420,   -70}
    }
   ,{{   310,   310,   -50,  -170,   -50}
    ,{   310,   310,   -50,  -400,   -50}
    ,{   300,   300,   -60,  -170,   -60}
    ,{   310,   310,   -50,  -400,   -50}
    ,{   300,   300,   -60,  -170,   -60}
    }
   ,{{  1140,  1140,   770,  -420,   770}
    ,{  -600,  -600,  -970, -1320,  -970}
    ,{   290,   290,   -70,  -420,   -70}
    ,{  1140,  1140,   770,  -830,   770}
    ,{   290,   290,   -70,  -420,   -70}
    }
   ,{{   310,   310,   -50,  -170,   -50}
    ,{   310,   310,   -50,  -400,   -50}
    ,{   300,   300,   -60,  -170,   -60}
    ,{   310,   310,   -50,  -400,   -50}
    ,{  -430,  -430, -1040, -1390, -1040}
    }
   }
  ,{{{   690,   690,   470,   690,   160}
    ,{   150,   150,   -60,   150,  -370}
    ,{  -140,  -140,  -360,  -140,  -670}
    ,{   690,   690,   470,   690,   160}
    ,{  -140,  -140,  -360,  -140,  -670}
    }
   ,{{   150,   150,   -60,   150,  -370}
    ,{   150,   150,   -60,   150,  -370}
    ,{  -150,  -150,  -370,  -150,  -680}
    ,{ -1210, -1230, -1210, -1230, -1520}
    ,{  -150,  -150,  -370,  -150,  -680}
    }
   ,{{  -140,  -140,  -360,  -140,  -670}
    ,{  -140,  -140,  -360,  -140,  -670}
    ,{  -140,  -140,  -360,  -140,  -670}
    ,{  -140,  -140,  -360,  -140,  -670}
    ,{  -140,  -140,  -360,  -140,  -670}
    }
   ,{{   690,   690,   470,   690,   160}
    ,{ -1030, -1050, -1030, -1050, -1340}
    ,{  -150,  -150,  -370,  -150,  -680}
    ,{   690,   690,   470,   690,   160}
    ,{  -150,  -150,  -370,  -150,  -680}
    }
   ,{{  -140,  -140,  -360,  -140,  -670}
    ,{  -140,  -140,  -360,  -140,  -670}
    ,{  -140,  -140,  -360,  -140,  -670}
    ,{  -140,  -140,  -360,  -140,  -670}
    ,{ -1120, -1120, -1340, -1120, -1650}
    }
   }
  ,{{{   780,  -580,   770,   780,   770}
    ,{   780,  -580,   240,   780,   240}
    ,{   480,  -640,   -60,   480,   -60}
    ,{   770,  -880,   770,   490,   770}
    ,{   480,  -640,   -60,   480,   -60}
    }
   ,{{   780,  -580,   240,   780,   240}
    ,{   780,  -580,   240,   780,   240}
    ,{   470,  -890,   -70,   470,   -70}
    ,{ -1150, -1970, -1150, -1860, -1150}
    ,{   470,  -890,   -70,   470,   -70}
    }
   ,{{   490,  -640,   -50,   490,   -50}
    ,{   490,  -880,   -50,   490,   -50}
    ,{   480,  -640,   -60,   480,   -60}
    ,{   490,  -880,   -50,   490,   -50}
    ,{   480,  -640,   -60,   480,   -60}
    }
   ,{{   770,  -890,   770,   470,   770}
    ,{  -970, -1790,  -970, -1680,  -970}
    ,{   470,  -890,   -70,   470,   -70}
    ,{   770, -1300,   770, -1190,   770}
    ,{   470,  -890,   -70,   470,   -70}
    }
   ,{{   490,  -640,   -50,   490,   -50}
    ,{   490,  -880,   -50,   490,   -50}
    ,{   480,  -640,   -60,   480,   -60}
    ,{   490,  -880,   -50,   490,   -50}
    ,{ -1040, -1860, -1040, -1750, -1040}
    }
   }
  ,{{{   690,   690,   470,   690,   190}
    ,{   190,   150,   -60,   150,   190}
    ,{  -140,  -140,  -360,  -140,  -350}
    ,{   690,   690,   470,   690,  -340}
    ,{  -140,  -140,  -360,  -140,  -350}
    }
   ,{{   190,   150,   -60,   150,   190}
    ,{   190,   150,   -60,   150,   190}
    ,{  -150,  -150,  -370,  -150,  -360}
    ,{ -1210, -1230, -1210, -1230, -1440}
    ,{  -150,  -150,  -370,  -150,  -360}
    }
   ,{{  -140,  -140,  -360,  -140,  -340}
    ,{  -140,  -140,  -360,  -140,  -340}
    ,{  -140,  -140,  -360,  -140,  -350}
    ,{  -140,  -140,  -360,  -140,  -340}
    ,{  -140,  -140,  -360,  -140,  -350}
    }
   ,{{   690,   690,   470,   690,  -360}
    ,{ -1030, -1050, -1030, -1050, -1260}
    ,{  -150,  -150,  -370,  -150,  -360}
    ,{   690,   690,   470,   690,  -770}
    ,{  -150,  -150,  -370,  -150,  -360}
    }
   ,{{  -140,  -140,  -360,  -140,  -340}
    ,{  -140,  -140,  -360,  -140,  -340}
    ,{  -140,  -140,  -360,  -140,  -350}
    ,{  -140,  -140,  -360,  -140,  -340}
    ,{ -1120, -1120, -1340, -1120, -1330}
    }
   }
  }
 ,{{{{  1320,  1320,   960,   870,   960}
    ,{   850,   670,   300,   850,   300}
    ,{   720,   540,   170,   720,   170}
    ,{  1320,  1320,   960,   870,   960}
    ,{   590,   410,    40,   590,    40}
    }
   ,{{   850,   670,   300,   850,   300}
    ,{   850,   670,   300,   850,   300}
    ,{   570,   390,    20,   570,    20}
    ,{  -730,  -730, -1100, -1180, -1100}
    ,{   570,   390,    20,   570,    20}
    }
   ,{{   720,   540,   170,   720,   170}
    ,{   720,   540,   170,   720,   170}
    ,{   720,   540,   170,   720,   170}
    ,{   720,   540,   170,   720,   170}
    ,{   590,   410,    40,   590,    40}
    }
   ,{{  1320,  1320,   960,   870,   960}
    ,{ -1030, -1030, -1400, -1480, -1400}
    ,{   570,   390,    20,   570,    20}
    ,{  1320,  1320,   960,   870,   960}
    ,{   570,   390,    20,   570,    20}
    }
   ,{{   720,   540,   170,   720,   170}
    ,{   720,   540,   170,   720,   170}
    ,{   280,   100,  -260,   280,  -260}
    ,{   720,   540,   170,   720,   170}
    ,{  -160,  -160,  -760,  -850,  -760}
    }
   }
  ,{{{  1320,  1320,   960,    70,   960}
    ,{   670,   670,   300,   -40,   300}
    ,{   540,   540,   170,    70,   170}
    ,{  1320,  1320,   960,  -170,   960}
    ,{   410,   410,    40,   -60,    40}
    }
   ,{{   670,   670,   300,   -40,   300}
    ,{   670,   670,   300,   -40,   300}
    ,{   390,   390,    20,  -320,    20}
    ,{  -730,  -730, -1100, -1450, -1100}
    ,{   390,   390,    20,  -320,    20}
    }
   ,{{   540,   540,   170,    70,   170}
    ,{   540,   540,   170,  -170,   170}
    ,{   540,   540,   170,    70,   170}
    ,{   540,   540,   170,  -170,   170}
    ,{   410,   410,    40,   -60,    40}
    }
   ,{{  1320,  1320,   960,  -320,   960}
    ,{ -1030, -1030, -1400, -1750, -1400}
    ,{   390,   390,    20,  -320,    20}
    ,{  1320,  1320,   960,  -640,   960}
    ,{   390,   390,    20,  -320,    20}
    }
   ,{{   540,   540,   170,  -170,   170}
    ,{   540,   540,   170,  -170,   170}
    ,{   100,   100,  -260,  -370,  -260}
    ,{   540,   540,   170,  -170,   170}
    ,{  -160,  -160,  -760, -1110,  -760}
    }
   }
  ,{{{   870,   870,   650,   870,   340}
    ,{   220,   220,     0,   220,  -310}
    ,{    90,    90,  -130,    90,  -440}
    ,{   870,   870,   650,   870,   340}
    ,{   -40,   -40,  -260,   -40,  -570}
    }
   ,{{   220,   220,     0,   220,  -310}
    ,{   220,   220,     0,   220,  -310}
    ,{   -60,   -60,  -280,   -60,  -590}
    ,{ -1160, -1180, -1160, -1180, -1470}
    ,{   -60,   -60,  -280,   -60,  -590}
    }
   ,{{    90,    90,  -130,    90,  -440}
    ,{    90,    90,  -130,    90,  -440}
    ,{    90,    90,  -130,    90,  -440}
    ,{    90,    90,  -130,    90,  -440}
    ,{   -40,   -40,  -260,   -40,  -570}
    }
   ,{{   870,   870,   650,   870,   340}
    ,{ -1460, -1480, -1460, -1480, -1770}
    ,{   -60,   -60,  -280,   -60,  -590}
    ,{   870,   870,   650,   870,   340}
    ,{   -60,   -60,  -280,   -60,  -590}
    }
   ,{{    90,    90,  -130,    90,  -440}
    ,{    90,    90,  -130,    90,  -440}
    ,{  -350,  -350,  -570,  -350,  -880}
    ,{    90,    90,  -130,    90,  -440}
    ,{  -850,  -850, -1070,  -850, -1380}
    }
   }
  ,{{{   960,  -410,   960,   850,   960}
    ,{   850,  -520,   300,   850,   300}
    ,{   720,  -410,   170,   720,   170}
    ,{   960,  -650,   960,   720,   960}
    ,{   590,  -540,    40,   590,    40}
    }
   ,{{   850,  -520,   300,   850,   300}
    ,{   850,  -520,   300,   850,   300}
    ,{   570,  -800,    20,   570,    20}
    ,{ -1100, -1920, -1100, -1810, -1100}
    ,{   570,  -800,    20,   570,    20}
    }
   ,{{   720,  -410,   170,   720,   170}
    ,{   720,  -650,   170,   720,   170}
    ,{   720,  -410,   170,   720,   170}
    ,{   720,  -650,   170,   720,   170}
    ,{   590,  -540,    40,   590,    40}
    }
   ,{{   960,  -800,   960,   570,   960}
    ,{ -1400, -2220, -1400, -2110, -1400}
    ,{   570,  -800,    20,   570,    20}
    ,{   960, -1120,   960, -1000,   960}
    ,{   570,  -800,    20,   570,    20}
    }
   ,{{   720,  -650,   170,   720,   170}
    ,{   720,  -650,   170,   720,   170}
    ,{   280,  -850,  -260,   280,  -260}
    ,{   720,  -650,   170,   720,   170}
    ,{  -760, -1590,  -760, -1470,  -760}
    }
   }
  ,{{{   870,   870,   650,   870,   250}
    ,{   250,   220,     0,   220,   250}
    ,{    90,    90,  -130,    90,  -110}
    ,{   870,   870,   650,   870,  -110}
    ,{   -40,   -40,  -260,   -40,  -240}
    }
   ,{{   250,   220,     0,   220,   250}
    ,{   250,   220,     0,   220,   250}
    ,{   -60,   -60,  -280,   -60,  -260}
    ,{ -1160, -1180, -1160, -1180, -1390}
    ,{   -60,   -60,  -280,   -60,  -260}
    }
   ,{{    90,    90,  -130,    90,  -110}
    ,{    90,    90,  -130,    90,  -110}
    ,{    90,    90,  -130,    90,  -110}
    ,{    90,    90,  -130,    90,  -110}
    ,{   -40,   -40,  -260,   -40,  -240}
    }
   ,{{   870,   870,   650,   870,  -260}
    ,{ -1460, -1480, -1460, -1480, -1690}
    ,{   -60,   -60,  -280,   -60,  -260}
    ,{   870,   870,   650,   870,  -580}
    ,{   -60,   -60,  -280,   -60,  -260}
    }
   ,{{    90,    90,  -130,    90,  -110}
    ,{    90,    90,  -130,    90,  -110}
    ,{  -350,  -350,  -570,  -350,  -550}
    ,{    90,    90,  -130,    90,  -110}
    ,{  -850,  -850, -1070,  -850, -1050}
    }
   }
  }
 ,{{{{  1320,  1320,   960,   870,   960}
    ,{   850,   670,   540,   850,   300}
    ,{   720,   540,   170,   720,   170}
    ,{  1320,  1320,   960,   870,   960}
    ,{   590,   410,    40,   590,    40}
    }
   ,{{   850,   670,   300,   850,   300}
    ,{   850,   670,   300,   850,   300}
    ,{   570,   390,    20,   570,    20}
    ,{  -350,  -350,  -870,  -960,  -870}
    ,{   570,   390,    20,   570,    20}
    }
   ,{{   720,   540,   170,   720,   170}
    ,{   720,   540,   170,   720,   170}
    ,{   720,   540,   170,   720,   170}
    ,{   720,   540,   170,   720,   170}
    ,{   590,   410,    40,   590,    40}
    }
   ,{{  1320,  1320,   960,   870,   960}
    ,{   540,  -100,   540, -1050,  -810}
    ,{   570,   390,    20,   570,    20}
    ,{  1320,  1320,   960,   870,   960}
    ,{   570,   390,    20,   570,    20}
    }
   ,{{   720,   540,   170,   720,   170}
    ,{   720,   540,   170,   720,   170}
    ,{   480,   300,   -60,   480,   -60}
    ,{   720,   540,   170,   720,   170}
    ,{  -160,  -160,  -400,  -230,  -760}
    }
   }
  ,{{{  1320,  1320,   960,    70,   960}
    ,{   670,   670,   300,   -40,   300}
    ,{   540,   540,   170,    70,   170}
    ,{  1320,  1320,   960,  -170,   960}
    ,{   410,   410,    40,   -60,    40}
    }
   ,{{   670,   670,   300,   -40,   300}
    ,{   670,   670,   300,   -40,   300}
    ,{   390,   390,    20,  -320,    20}
    ,{  -730,  -730, -1100, -1450,  -870}
    ,{   390,   390,    20,  -320,    20}
    }
   ,{{   540,   540,   170,    70,   170}
    ,{   540,   540,   170,  -170,   170}
    ,{   540,   540,   170,    70,   170}
    ,{   540,   540,   170,  -170,   170}
    ,{   410,   410,    40,   -60,    40}
    }
   ,{{  1320,  1320,   960,  -320,   960}
    ,{    10,  -600,    10, -1320,  -970}
    ,{   390,   390,    20,  -320,    20}
    ,{  1320,  1320,   960,  -640,   960}
    ,{   390,   390,    20,  -320,    20}
    }
   ,{{   540,   540,   170,  -170,   170}
    ,{   540,   540,   170,  -170,   170}
    ,{   300,   300,   -60,  -170,   -60}
    ,{   540,   540,   170,  -170,   170}
    ,{  -160,  -160,  -400, -1110,  -760}
    }
   }
  ,{{{   870,   870,   650,   870,   340}
    ,{   540,   220,   540,   220,  -310}
    ,{    90,    90,  -130,    90,  -440}
    ,{   870,   870,   650,   870,   340}
    ,{   -40,   -40,  -260,   -40,  -570}
    }
   ,{{   220,   220,     0,   220,  -310}
    ,{   220,   220,     0,   220,  -310}
    ,{   -60,   -60,  -280,   -60,  -590}
    ,{  -350,  -350,  -940,  -960, -1250}
    ,{   -60,   -60,  -280,   -60,  -590}
    }
   ,{{    90,    90,  -130,    90,  -440}
    ,{    90,    90,  -130,    90,  -440}
    ,{    90,    90,  -130,    90,  -440}
    ,{    90,    90,  -130,    90,  -440}
    ,{   -40,   -40,  -260,   -40,  -570}
    }
   ,{{   870,   870,   650,   870,   340}
    ,{   540,  -100,   540, -1050, -1340}
    ,{   -60,   -60,  -280,   -60,  -590}
    ,{   870,   870,   650,   870,   340}
    ,{   -60,   -60,  -280,   -60,  -590}
    }
   ,{{    90,    90,  -130,    90,  -440}
    ,{    90,    90,  -130,    90,  -440}
    ,{  -140,  -140,  -360,  -140,  -670}
    ,{    90,    90,  -130,    90,  -440}
    ,{  -850,  -850, -1070,  -850, -1380}
    }
   }
  ,{{{   960,  -410,   960,   850,   960}
    ,{   850,  -520,   300,   850,   300}
    ,{   720,  -410,   170,   720,   170}
    ,{   960,  -650,   960,   720,   960}
    ,{   590,  -540,    40,   590,    40}
    }
   ,{{   850,  -520,   300,   850,   300}
    ,{   850,  -520,   300,   850,   300}
    ,{   570,  -800,    20,   570,    20}
    ,{  -870, -1920,  -870, -1370,  -870}
    ,{   570,  -800,    20,   570,    20}
    }
   ,{{   720,  -410,   170,   720,   170}
    ,{   720,  -650,   170,   720,   170}
    ,{   720,  -410,   170,   720,   170}
    ,{   720,  -650,   170,   720,   170}
    ,{   590,  -540,    40,   590,    40}
    }
   ,{{   960,  -800,   960,   570,   960}
    ,{  -970, -1790,  -970, -1680,  -970}
    ,{   570,  -800,    20,   570,    20}
    ,{   960, -1120,   960, -1000,   960}
    ,{   570,  -800,    20,   570,    20}
    }
   ,{{   720,  -640,   170,   720,   170}
    ,{   720,  -650,   170,   720,   170}
    ,{   480,  -640,   -60,   480,   -60}
    ,{   720,  -650,   170,   720,   170}
    ,{  -230, -1520,  -760,  -230,  -760}
    }
   }
  ,{{{   870,   870,   650,   870,   250}
    ,{   250,   220,     0,   220,   250}
    ,{    90,    90,  -130,    90,  -110}
    ,{   870,   870,   650,   870,  -110}
    ,{   -40,   -40,  -260,   -40,  -240}
    }
   ,{{   250,   220,     0,   220,   250}
    ,{   250,   220,     0,   220,   250}
    ,{   -60,   -60,  -280,   -60,  -260}
    ,{  -940,  -960,  -940,  -960, -1360}
    ,{   -60,   -60,  -280,   -60,  -260}
    }
   ,{{    90,    90,  -130,    90,   -90}
    ,{    90,    90,  -130,    90,   -90}
    ,{    90,    90,  -130,    90,  -110}
    ,{    90,    90,  -130,    90,  -110}
    ,{   -40,   -40,  -260,   -40,  -240}
    }
   ,{{   870,   870,   650,   870,  -260}
    ,{  -810, -1050, -1030, -1050,  -810}
    ,{   -60,   -60,  -280,   -60,  -260}
    ,{   870,   870,   650,   870,  -580}
    ,{   -60,   -60,  -280,   -60,  -260}
    }
   ,{{    90,    90,  -130,    90,  -110}
    ,{    90,    90,  -130,    90,  -110}
    ,{  -140,  -140,  -360,  -140,  -350}
    ,{    90,    90,  -130,    90,  -110}
    ,{  -850,  -850, -1070,  -850, -1050}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   240,  -780,  -870,   240,  -870}
    ,{   190, -1060, -1060,   190,  -970}
    ,{   240,  -780, -1010,   240, -1010}
    ,{   190,  -870,  -870,   190,  -870}
    ,{   130,  -890, -1120,   130, -1120}
    }
   ,{{    40, -1210, -1180,    40,  -970}
    ,{    40, -1210, -1210,    40,  -970}
    ,{  -270, -1520, -1520,  -270, -1520}
    ,{ -1180, -1420, -1180, -1250, -1180}
    ,{  -270, -1520, -1520,  -270, -1520}
    }
   ,{{   190,  -840, -1060,   190, -1060}
    ,{   190, -1060, -1060,   190, -1060}
    ,{   180,  -840, -1070,   180, -1070}
    ,{   190, -1060, -1060,   190, -1060}
    ,{   130,  -890, -1120,   130, -1120}
    }
   ,{{  -270,  -870,  -870,  -270,  -870}
    ,{ -1470, -1710, -1470, -1530, -1470}
    ,{  -270, -1520, -1520,  -270, -1520}
    ,{  -870,  -870,  -870,  -870,  -870}
    ,{  -270, -1520, -1520,  -270, -1520}
    }
   ,{{   240,  -780, -1010,   240, -1010}
    ,{   190, -1060, -1060,   190, -1060}
    ,{   240,  -780, -1010,   240, -1010}
    ,{   190, -1060, -1060,   190, -1060}
    ,{ -1680, -1790, -1850, -1680, -1850}
    }
   }
  ,{{{  -590, -1050,  -870,  -590,  -870}
    ,{  -890, -1240, -1060,  -890, -1060}
    ,{  -590, -1190, -1010,  -590, -1010}
    ,{  -870, -1050,  -870,  -890,  -870}
    ,{  -700, -1300, -1120,  -700, -1120}
    }
   ,{{ -1030, -1370, -1210, -1030, -1210}
    ,{ -1030, -1370, -1210, -1030, -1210}
    ,{ -1340, -1700, -1520, -1340, -1520}
    ,{ -1250, -1600, -1420, -1250, -1420}
    ,{ -1340, -1700, -1520, -1340, -1520}
    }
   ,{{  -650, -1240, -1060,  -650, -1060}
    ,{  -890, -1240, -1060,  -890, -1060}
    ,{  -650, -1250, -1070,  -650, -1070}
    ,{  -890, -1240, -1060,  -890, -1060}
    ,{  -700, -1300, -1120,  -700, -1120}
    }
   ,{{  -870, -1050,  -870, -1340,  -870}
    ,{ -1530, -1890, -1710, -1530, -1710}
    ,{ -1340, -1700, -1520, -1340, -1520}
    ,{  -870, -1050,  -870, -1940,  -870}
    ,{ -1340, -1700, -1520, -1340, -1520}
    }
   ,{{  -590, -1190, -1010,  -590, -1010}
    ,{  -890, -1240, -1060,  -890, -1060}
    ,{  -590, -1190, -1010,  -590, -1010}
    ,{  -890, -1240, -1060,  -890, -1060}
    ,{ -1680, -1790, -1850, -1680, -1850}
    }
   }
  ,{{{  -870,  -870,  -870,  -870,  -870}
    ,{ -1060, -1060, -1060, -1060, -1060}
    ,{ -1010, -1010, -1010, -1010, -1010}
    ,{  -870,  -870,  -870,  -870,  -870}
    ,{ -1120, -1120, -1120, -1120, -1120}
    }
   ,{{ -1180, -1210, -1180, -1210, -1180}
    ,{ -1210, -1210, -1210, -1210, -1210}
    ,{ -1520, -1520, -1520, -1520, -1520}
    ,{ -1180, -1420, -1180, -1420, -1180}
    ,{ -1520, -1520, -1520, -1520, -1520}
    }
   ,{{ -1060, -1060, -1060, -1060, -1060}
    ,{ -1060, -1060, -1060, -1060, -1060}
    ,{ -1070, -1070, -1070, -1070, -1070}
    ,{ -1060, -1060, -1060, -1060, -1060}
    ,{ -1120, -1120, -1120, -1120, -1120}
    }
   ,{{  -870,  -870,  -870,  -870,  -870}
    ,{ -1470, -1710, -1470, -1710, -1470}
    ,{ -1520, -1520, -1520, -1520, -1520}
    ,{  -870,  -870,  -870,  -870,  -870}
    ,{ -1520, -1520, -1520, -1520, -1520}
    }
   ,{{ -1010, -1010, -1010, -1010, -1010}
    ,{ -1060, -1060, -1060, -1060, -1060}
    ,{ -1010, -1010, -1010, -1010, -1010}
    ,{ -1060, -1060, -1060, -1060, -1060}
    ,{ -1850, -1850, -1850, -1850, -1850}
    }
   }
  ,{{{   240,  -780,  -870,   240,  -870}
    ,{   190, -1080, -1060,   190, -1060}
    ,{   240,  -780, -1010,   240, -1010}
    ,{   190, -1080,  -870,   190,  -870}
    ,{   130,  -890, -1120,   130, -1120}
    }
   ,{{    40, -1220, -1210,    40, -1210}
    ,{    40, -1220, -1210,    40, -1210}
    ,{  -270, -1530, -1520,  -270, -1520}
    ,{ -1420, -1440, -1420, -1420, -1420}
    ,{  -270, -1530, -1520,  -270, -1520}
    }
   ,{{   190,  -840, -1060,   190, -1060}
    ,{   190, -1080, -1060,   190, -1060}
    ,{   180,  -840, -1070,   180, -1070}
    ,{   190, -1080, -1060,   190, -1060}
    ,{   130,  -890, -1120,   130, -1120}
    }
   ,{{  -270, -1530,  -870,  -270,  -870}
    ,{ -1710, -1720, -1710, -1710, -1710}
    ,{  -270, -1530, -1520,  -270, -1520}
    ,{  -870, -2130,  -870, -2120,  -870}
    ,{  -270, -1530, -1520,  -270, -1520}
    }
   ,{{   240,  -780, -1010,   240, -1010}
    ,{   190, -1080, -1060,   190, -1060}
    ,{   240,  -780, -1010,   240, -1010}
    ,{   190, -1080, -1060,   190, -1060}
    ,{ -1850, -1870, -1850, -1850, -1850}
    }
   }
  ,{{{  -870,  -870,  -870,  -870,  -970}
    ,{  -970, -1060, -1060, -1060,  -970}
    ,{ -1010, -1010, -1010, -1010, -1010}
    ,{  -870,  -870,  -870,  -870, -1060}
    ,{ -1120, -1120, -1120, -1120, -1120}
    }
   ,{{  -970, -1210, -1180, -1210,  -970}
    ,{  -970, -1210, -1210, -1210,  -970}
    ,{ -1520, -1520, -1520, -1520, -1520}
    ,{ -1180, -1420, -1180, -1420, -1420}
    ,{ -1520, -1520, -1520, -1520, -1520}
    }
   ,{{ -1060, -1060, -1060, -1060, -1060}
    ,{ -1060, -1060, -1060, -1060, -1060}
    ,{ -1070, -1070, -1070, -1070, -1070}
    ,{ -1060, -1060, -1060, -1060, -1060}
    ,{ -1120, -1120, -1120, -1120, -1120}
    }
   ,{{  -870,  -870,  -870,  -870, -1520}
    ,{ -1470, -1710, -1470, -1710, -1710}
    ,{ -1520, -1520, -1520, -1520, -1520}
    ,{  -870,  -870,  -870,  -870, -2120}
    ,{ -1520, -1520, -1520, -1520, -1520}
    }
   ,{{ -1010, -1010, -1010, -1010, -1010}
    ,{ -1060, -1060, -1060, -1060, -1060}
    ,{ -1010, -1010, -1010, -1010, -1010}
    ,{ -1060, -1060, -1060, -1060, -1060}
    ,{ -1850, -1850, -1850, -1850, -1850}
    }
   }
  }
 ,{{{{   210,  -870,  -870,   210,  -800}
    ,{   210, -1040, -1040,   210,  -800}
    ,{  -240, -1490, -1490,  -240, -1490}
    ,{  -160,  -870,  -870,  -160,  -870}
    ,{  -240, -1490, -1490,  -240, -1490}
    }
   ,{{   210, -1040, -1040,   210,  -800}
    ,{   210, -1040, -1040,   210,  -800}
    ,{  -240, -1490, -1490,  -240, -1490}
    ,{ -1990, -2230, -1990, -2060, -1990}
    ,{  -240, -1490, -1490,  -240, -1490}
    }
   ,{{  -160, -1410, -1410,  -160, -1410}
    ,{  -160, -1410, -1410,  -160, -1410}
    ,{  -460, -1490, -1710,  -460, -1710}
    ,{  -160, -1410, -1410,  -160, -1410}
    ,{  -460, -1490, -1710,  -460, -1710}
    }
   ,{{  -240,  -870,  -870,  -240,  -870}
    ,{ -1520, -1760, -1520, -1580, -1520}
    ,{  -240, -1490, -1490,  -240, -1490}
    ,{  -870,  -870,  -870,  -870,  -870}
    ,{  -240, -1490, -1490,  -240, -1490}
    }
   ,{{  -160, -1410, -1410,  -160, -1410}
    ,{  -160, -1410, -1410,  -160, -1410}
    ,{  -770, -1800, -2020,  -770, -2020}
    ,{  -160, -1410, -1410,  -160, -1410}
    ,{ -1520, -1640, -1700, -1520, -1700}
    }
   }
  ,{{{  -870, -1050,  -870,  -870,  -870}
    ,{  -870, -1220, -1040,  -870, -1040}
    ,{ -1300, -1670, -1490, -1300, -1490}
    ,{  -870, -1050,  -870, -1230,  -870}
    ,{ -1300, -1640, -1490, -1300, -1490}
    }
   ,{{  -870, -1220, -1040,  -870, -1040}
    ,{  -870, -1220, -1040,  -870, -1040}
    ,{ -1320, -1670, -1490, -1320, -1490}
    ,{ -2060, -2410, -2230, -2060, -2230}
    ,{ -1320, -1670, -1490, -1320, -1490}
    }
   ,{{ -1230, -1590, -1410, -1230, -1410}
    ,{ -1230, -1590, -1410, -1230, -1410}
    ,{ -1300, -1890, -1710, -1300, -1710}
    ,{ -1230, -1590, -1410, -1230, -1410}
    ,{ -1300, -1890, -1710, -1300, -1710}
    }
   ,{{  -870, -1050,  -870, -1320,  -870}
    ,{ -1580, -1940, -1760, -1580, -1760}
    ,{ -1320, -1670, -1490, -1320, -1490}
    ,{  -870, -1050,  -870, -1940,  -870}
    ,{ -1320, -1670, -1490, -1320, -1490}
    }
   ,{{ -1230, -1590, -1410, -1230, -1410}
    ,{ -1230, -1590, -1410, -1230, -1410}
    ,{ -1610, -2200, -2020, -1610, -2020}
    ,{ -1230, -1590, -1410, -1230, -1410}
    ,{ -1520, -1640, -1700, -1520, -1700}
    }
   }
  ,{{{  -870,  -870,  -870,  -870,  -870}
    ,{ -1040, -1040, -1040, -1040, -1040}
    ,{ -1490, -1490, -1490, -1490, -1490}
    ,{  -870,  -870,  -870,  -870,  -870}
    ,{ -1490, -1490, -1490, -1490, -1490}
    }
   ,{{ -1040, -1040, -1040, -1040, -1040}
    ,{ -1040, -1040, -1040, -1040, -1040}
    ,{ -1490, -1490, -1490, -1490, -1490}
    ,{ -1990, -2230, -1990, -2230, -1990}
    ,{ -1490, -1490, -1490, -1490, -1490}
    }
   ,{{ -1410, -1410, -1410, -1410, -1410}
    ,{ -1410, -1410, -1410, -1410, -1410}
    ,{ -1710, -1710, -1710, -1710, -1710}
    ,{ -1410, -1410, -1410, -1410, -1410}
    ,{ -1710, -1710, -1710, -1710, -1710}
    }
   ,{{  -870,  -870,  -870,  -870,  -870}
    ,{ -1520, -1760, -1520, -1760, -1520}
    ,{ -1490, -1490, -1490, -1490, -1490}
    ,{  -870,  -870,  -870,  -870,  -870}
    ,{ -1490, -1490, -1490, -1490, -1490}
    }
   ,{{ -1410, -1410, -1410, -1410, -1410}
    ,{ -1410, -1410, -1410, -1410, -1410}
    ,{ -2020, -2020, -2020, -2020, -2020}
    ,{ -1410, -1410, -1410, -1410, -1410}
    ,{ -1700, -1700, -1700, -1700, -1700}
    }
   }
  ,{{{   210, -1060,  -870,   210,  -870}
    ,{   210, -1060, -1040,   210, -1040}
    ,{  -240, -1490, -1490,  -240, -1490}
    ,{  -160, -1420,  -870,  -160,  -870}
    ,{  -240, -1490, -1490,  -240, -1490}
    }
   ,{{   210, -1060, -1040,   210, -1040}
    ,{   210, -1060, -1040,   210, -1040}
    ,{  -240, -1510, -1490,  -240, -1490}
    ,{ -2230, -2250, -2230, -2230, -2230}
    ,{  -240, -1510, -1490,  -240, -1490}
    }
   ,{{  -160, -1420, -1410,  -160, -1410}
    ,{  -160, -1420, -1410,  -160, -1410}
    ,{  -460, -1490, -1710,  -460, -1710}
    ,{  -160, -1420, -1410,  -160, -1410}
    ,{  -460, -1490, -1710,  -460, -1710}
    }
   ,{{  -240, -1510,  -870,  -240,  -870}
    ,{ -1760, -1770, -1760, -1760, -1760}
    ,{  -240, -1510, -1490,  -240, -1490}
    ,{  -870, -2130,  -870, -2120,  -870}
    ,{  -240, -1510, -1490,  -240, -1490}
    }
   ,{{  -160, -1420, -1410,  -160, -1410}
    ,{  -160, -1420, -1410,  -160, -1410}
    ,{  -770, -1800, -2020,  -770, -2020}
    ,{  -160, -1420, -1410,  -160, -1410}
    ,{ -1700, -1710, -1700, -1700, -1700}
    }
   }
  ,{{{  -800,  -870,  -870,  -870,  -800}
    ,{  -800, -1040, -1040, -1040,  -800}
    ,{ -1490, -1490, -1490, -1490, -1490}
    ,{  -870,  -870,  -870,  -870, -1410}
    ,{ -1490, -1490, -1490, -1490, -1490}
    }
   ,{{  -800, -1040, -1040, -1040,  -800}
    ,{  -800, -1040, -1040, -1040,  -800}
    ,{ -1490, -1490, -1490, -1490, -1490}
    ,{ -1990, -2230, -1990, -2230, -2230}
    ,{ -1490, -1490, -1490, -1490, -1490}
    }
   ,{{ -1410, -1410, -1410, -1410, -1410}
    ,{ -1410, -1410, -1410, -1410, -1410}
    ,{ -1710, -1710, -1710, -1710, -1710}
    ,{ -1410, -1410, -1410, -1410, -1410}
    ,{ -1710, -1710, -1710, -1710, -1710}
    }
   ,{{  -870,  -870,  -870,  -870, -1490}
    ,{ -1520, -1760, -1520, -1760, -1760}
    ,{ -1490, -1490, -1490, -1490, -1490}
    ,{  -870,  -870,  -870,  -870, -2120}
    ,{ -1490, -1490, -1490, -1490, -1490}
    }
   ,{{ -1410, -1410, -1410, -1410, -1410}
    ,{ -1410, -1410, -1410, -1410, -1410}
    ,{ -2020, -2020, -2020, -2020, -2020}
    ,{ -1410, -1410, -1410, -1410, -1410}
    ,{ -1700, -1700, -1700, -1700, -1700}
    }
   }
  }
 ,{{{{  -710,  -710,  -710,  -710,  -710}
    ,{  -710, -1780, -1540,  -710, -1540}
    ,{  -710, -1730, -1960,  -710, -1960}
    ,{  -710,  -710,  -710,  -710,  -710}
    ,{  -710, -1730, -1960,  -710, -1960}
    }
   ,{{  -710, -1960, -1730,  -710, -1730}
    ,{  -890, -2140, -2140,  -890, -1900}
    ,{  -710, -1960, -1960,  -710, -1960}
    ,{ -1730, -1970, -1730, -1800, -1730}
    ,{  -710, -1960, -1960,  -710, -1960}
    }
   ,{{  -710, -1730, -1960,  -710, -1960}
    ,{  -710, -1960, -1960,  -710, -1960}
    ,{  -710, -1730, -1960,  -710, -1960}
    ,{  -710, -1960, -1960,  -710, -1960}
    ,{  -710, -1730, -1960,  -710, -1960}
    }
   ,{{  -710,  -710,  -710,  -710,  -710}
    ,{ -1540, -1780, -1540, -1610, -1540}
    ,{  -710, -1960, -1960,  -710, -1960}
    ,{  -710,  -710,  -710,  -710,  -710}
    ,{  -710, -1960, -1960,  -710, -1960}
    }
   ,{{  -710, -1730, -1960,  -710, -1960}
    ,{  -710, -1960, -1960,  -710, -1960}
    ,{  -710, -1730, -1960,  -710, -1960}
    ,{  -710, -1960, -1960,  -710, -1960}
    ,{ -1780, -1900, -1960, -1780, -1960}
    }
   }
  ,{{{  -710,  -890,  -710, -1540,  -710}
    ,{ -1610, -1960, -1780, -1610, -1780}
    ,{ -1540, -2140, -1960, -1540, -1960}
    ,{  -710,  -890,  -710, -1780,  -710}
    ,{ -1540, -1900, -1960, -1540, -1960}
    }
   ,{{ -1780, -2140, -1960, -1780, -1960}
    ,{ -1960, -2320, -2140, -1960, -2140}
    ,{ -1780, -2140, -1960, -1780, -1960}
    ,{ -1800, -2150, -1970, -1800, -1970}
    ,{ -1780, -2140, -1960, -1780, -1960}
    }
   ,{{ -1540, -2140, -1960, -1540, -1960}
    ,{ -1780, -2140, -1960, -1780, -1960}
    ,{ -1540, -2140, -1960, -1540, -1960}
    ,{ -1780, -2140, -1960, -1780, -1960}
    ,{ -1540, -2140, -1960, -1540, -1960}
    }
   ,{{  -710,  -890,  -710, -1610,  -710}
    ,{ -1610, -1960, -1780, -1610, -1780}
    ,{ -1780, -2140, -1960, -1780, -1960}
    ,{  -710,  -890,  -710, -1780,  -710}
    ,{ -1780, -2140, -1960, -1780, -1960}
    }
   ,{{ -1540, -1900, -1960, -1540, -1960}
    ,{ -1780, -2140, -1960, -1780, -1960}
    ,{ -1540, -2140, -1960, -1540, -1960}
    ,{ -1780, -2140, -1960, -1780, -1960}
    ,{ -1780, -1900, -1960, -1780, -1960}
    }
   }
  ,{{{  -710,  -710,  -710,  -710,  -710}
    ,{ -1540, -1780, -1540, -1780, -1540}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{  -710,  -710,  -710,  -710,  -710}
    ,{ -1960, -1960, -1960, -1960, -1960}
    }
   ,{{ -1730, -1960, -1730, -1960, -1730}
    ,{ -2140, -2140, -2140, -2140, -2140}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1730, -1970, -1730, -1970, -1730}
    ,{ -1960, -1960, -1960, -1960, -1960}
    }
   ,{{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    }
   ,{{  -710,  -710,  -710,  -710,  -710}
    ,{ -1540, -1780, -1540, -1780, -1540}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{  -710,  -710,  -710,  -710,  -710}
    ,{ -1960, -1960, -1960, -1960, -1960}
    }
   ,{{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    }
   }
  ,{{{  -710, -1730,  -710,  -710,  -710}
    ,{  -710, -1800, -1780,  -710, -1780}
    ,{  -710, -1730, -1960,  -710, -1960}
    ,{  -710, -1970,  -710,  -710,  -710}
    ,{  -710, -1730, -1960,  -710, -1960}
    }
   ,{{  -710, -1970, -1960,  -710, -1960}
    ,{  -890, -2150, -2140,  -890, -2140}
    ,{  -710, -1970, -1960,  -710, -1960}
    ,{ -1970, -1990, -1970, -1970, -1970}
    ,{  -710, -1970, -1960,  -710, -1960}
    }
   ,{{  -710, -1730, -1960,  -710, -1960}
    ,{  -710, -1970, -1960,  -710, -1960}
    ,{  -710, -1730, -1960,  -710, -1960}
    ,{  -710, -1970, -1960,  -710, -1960}
    ,{  -710, -1730, -1960,  -710, -1960}
    }
   ,{{  -710, -1800,  -710,  -710,  -710}
    ,{ -1780, -1800, -1780, -1780, -1780}
    ,{  -710, -1970, -1960,  -710, -1960}
    ,{  -710, -1970,  -710, -1960,  -710}
    ,{  -710, -1970, -1960,  -710, -1960}
    }
   ,{{  -710, -1730, -1960,  -710, -1960}
    ,{  -710, -1970, -1960,  -710, -1960}
    ,{  -710, -1730, -1960,  -710, -1960}
    ,{  -710, -1970, -1960,  -710, -1960}
    ,{ -1960, -1970, -1960, -1960, -1960}
    }
   }
  ,{{{  -710,  -710,  -710,  -710, -1780}
    ,{ -1540, -1780, -1540, -1780, -1780}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{  -710,  -710,  -710,  -710, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    }
   ,{{ -1730, -1960, -1730, -1960, -1900}
    ,{ -1900, -2140, -2140, -2140, -1900}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1730, -1970, -1730, -1970, -1970}
    ,{ -1960, -1960, -1960, -1960, -1960}
    }
   ,{{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    }
   ,{{  -710,  -710,  -710,  -710, -1780}
    ,{ -1540, -1780, -1540, -1780, -1780}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{  -710,  -710,  -710,  -710, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    }
   ,{{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    ,{ -1960, -1960, -1960, -1960, -1960}
    }
   }
  }
 ,{{{{   360,   -70,  -150,   360,  -150}
    ,{   360,   -70,  -890,   360,  -650}
    ,{  -150, -1180, -1400,  -150, -1400}
    ,{  -150,  -150,  -150,  -150,  -150}
    ,{  -150, -1180, -1400,  -150, -1400}
    }
   ,{{   360,   -70,  -890,   360,  -650}
    ,{   360,   -70,  -890,   360,  -650}
    ,{  -150, -1400, -1400,  -150, -1400}
    ,{ -1500, -1600, -1500, -1570, -1500}
    ,{  -150, -1400, -1400,  -150, -1400}
    }
   ,{{  -150, -1180, -1400,  -150, -1400}
    ,{  -150, -1400, -1400,  -150, -1400}
    ,{  -150, -1180, -1400,  -150, -1400}
    ,{  -150, -1400, -1400,  -150, -1400}
    ,{  -150, -1180, -1400,  -150, -1400}
    }
   ,{{  -150,  -150,  -150,  -150,  -150}
    ,{ -1670, -1910, -1670, -1740, -1670}
    ,{  -150, -1400, -1400,  -150, -1400}
    ,{  -150,  -150,  -150,  -150,  -150}
    ,{  -150, -1400, -1400,  -150, -1400}
    }
   ,{{  -150, -1180, -1400,  -150, -1400}
    ,{  -150, -1400, -1400,  -150, -1400}
    ,{  -150, -1180, -1400,  -150, -1400}
    ,{  -150, -1400, -1400,  -150, -1400}
    ,{ -1230, -1340, -1400, -1230, -1400}
    }
   }
  ,{{{   -30,   -70,  -150,   -30,  -150}
    ,{   -30,   -70,  -890,   -30,  -890}
    ,{  -990, -1580, -1400,  -990, -1400}
    ,{  -150,  -330,  -150, -1230,  -150}
    ,{  -990, -1340, -1400,  -990, -1400}
    }
   ,{{   -30,   -70,  -890,   -30,  -890}
    ,{   -30,   -70,  -890,   -30,  -890}
    ,{ -1230, -1580, -1400, -1230, -1400}
    ,{ -1570, -1600, -1740, -1570, -1740}
    ,{ -1230, -1580, -1400, -1230, -1400}
    }
   ,{{  -990, -1580, -1400,  -990, -1400}
    ,{ -1230, -1580, -1400, -1230, -1400}
    ,{  -990, -1580, -1400,  -990, -1400}
    ,{ -1230, -1580, -1400, -1230, -1400}
    ,{  -990, -1580, -1400,  -990, -1400}
    }
   ,{{  -150,  -330,  -150, -1230,  -150}
    ,{ -1740, -2090, -1910, -1740, -1910}
    ,{ -1230, -1580, -1400, -1230, -1400}
    ,{  -150,  -330,  -150, -1230,  -150}
    ,{ -1230, -1580, -1400, -1230, -1400}
    }
   ,{{  -990, -1340, -1400,  -990, -1400}
    ,{ -1230, -1580, -1400, -1230, -1400}
    ,{  -990, -1580, -1400,  -990, -1400}
    ,{ -1230, -1580, -1400, -1230, -1400}
    ,{ -1230, -1340, -1400, -1230, -1400}
    }
   }
  ,{{{  -150,  -150,  -150,  -150,  -150}
    ,{  -890,  -890,  -890,  -890,  -890}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{  -150,  -150,  -150,  -150,  -150}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{  -890,  -890,  -890,  -890,  -890}
    ,{  -890,  -890,  -890,  -890,  -890}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1500, -1740, -1500, -1740, -1500}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{  -150,  -150,  -150,  -150,  -150}
    ,{ -1670, -1910, -1670, -1910, -1670}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{  -150,  -150,  -150,  -150,  -150}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   }
  ,{{{   360,  -910,  -150,   360,  -150}
    ,{   360,  -910,  -890,   360,  -890}
    ,{  -150, -1180, -1400,  -150, -1400}
    ,{  -150, -1420,  -150,  -150,  -150}
    ,{  -150, -1180, -1400,  -150, -1400}
    }
   ,{{   360,  -910,  -890,   360,  -890}
    ,{   360,  -910,  -890,   360,  -890}
    ,{  -150, -1420, -1400,  -150, -1400}
    ,{ -1740, -3040, -1740, -1740, -1740}
    ,{  -150, -1420, -1400,  -150, -1400}
    }
   ,{{  -150, -1180, -1400,  -150, -1400}
    ,{  -150, -1420, -1400,  -150, -1400}
    ,{  -150, -1180, -1400,  -150, -1400}
    ,{  -150, -1420, -1400,  -150, -1400}
    ,{  -150, -1180, -1400,  -150, -1400}
    }
   ,{{  -150, -1420,  -150,  -150,  -150}
    ,{ -1910, -1930, -1910, -1910, -1910}
    ,{  -150, -1420, -1400,  -150, -1400}
    ,{  -150, -1420,  -150, -1400,  -150}
    ,{  -150, -1420, -1400,  -150, -1400}
    }
   ,{{  -150, -1180, -1400,  -150, -1400}
    ,{  -150, -1420, -1400,  -150, -1400}
    ,{  -150, -1180, -1400,  -150, -1400}
    ,{  -150, -1420, -1400,  -150, -1400}
    ,{ -1400, -1420, -1400, -1400, -1400}
    }
   }
  ,{{{  -150,  -150,  -150,  -150,  -650}
    ,{  -650,  -890,  -890,  -890,  -650}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{  -150,  -150,  -150,  -150, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{  -650,  -890,  -890,  -890,  -650}
    ,{  -650,  -890,  -890,  -890,  -650}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1500, -1740, -1500, -1740, -1740}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{  -150,  -150,  -150,  -150, -1400}
    ,{ -1670, -1910, -1670, -1910, -1910}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{  -150,  -150,  -150,  -150, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   }
  }
 ,{{{{   940,   220,   220,   940,   220}
    ,{   940,  -310,  -310,   940,   -70}
    ,{   640,  -380,  -610,   640,  -610}
    ,{   650,   220,   220,   650,   220}
    ,{   640,  -380,  -610,   640,  -610}
    }
   ,{{   940,  -310,  -310,   940,   -70}
    ,{   940,  -310,  -310,   940,   -70}
    ,{   630,  -620,  -620,   630,  -620}
    ,{ -1460, -1700, -1460, -1520, -1460}
    ,{   630,  -620,  -620,   630,  -620}
    }
   ,{{   650,  -380,  -600,   650,  -600}
    ,{   650,  -600,  -600,   650,  -600}
    ,{   640,  -380,  -610,   640,  -610}
    ,{   650,  -600,  -600,   650,  -600}
    ,{   640,  -380,  -610,   640,  -610}
    }
   ,{{   630,   220,   220,   630,   220}
    ,{ -1280, -1520, -1280, -1340, -1280}
    ,{   630,  -620,  -620,   630,  -620}
    ,{   220,   220,   220,   220,   220}
    ,{   630,  -620,  -620,   630,  -620}
    }
   ,{{   650,  -380,  -600,   650,  -600}
    ,{   650,  -600,  -600,   650,  -600}
    ,{   640,  -380,  -610,   640,  -610}
    ,{   650,  -600,  -600,   650,  -600}
    ,{ -1410, -1530, -1590, -1410, -1590}
    }
   }
  ,{{{   220,    40,   220,  -130,   220}
    ,{  -130,  -490,  -310,  -130,  -310}
    ,{  -190,  -790,  -610,  -190,  -610}
    ,{   220,    40,   220,  -430,   220}
    ,{  -190,  -790,  -610,  -190,  -610}
    }
   ,{{  -130,  -490,  -310,  -130,  -310}
    ,{  -130,  -490,  -310,  -130,  -310}
    ,{  -440,  -800,  -620,  -440,  -620}
    ,{ -1520, -1880, -1700, -1520, -1700}
    ,{  -440,  -800,  -620,  -440,  -620}
    }
   ,{{  -190,  -780,  -600,  -190,  -600}
    ,{  -430,  -780,  -600,  -430,  -600}
    ,{  -190,  -790,  -610,  -190,  -610}
    ,{  -430,  -780,  -600,  -430,  -600}
    ,{  -190,  -790,  -610,  -190,  -610}
    }
   ,{{   220,    40,   220,  -440,   220}
    ,{ -1340, -1700, -1520, -1340, -1520}
    ,{  -440,  -800,  -620,  -440,  -620}
    ,{   220,    40,   220,  -850,   220}
    ,{  -440,  -800,  -620,  -440,  -620}
    }
   ,{{  -190,  -780,  -600,  -190,  -600}
    ,{  -430,  -780,  -600,  -430,  -600}
    ,{  -190,  -790,  -610,  -190,  -610}
    ,{  -430,  -780,  -600,  -430,  -600}
    ,{ -1410, -1530, -1590, -1410, -1590}
    }
   }
  ,{{{   220,   220,   220,   220,   220}
    ,{  -310,  -310,  -310,  -310,  -310}
    ,{  -610,  -610,  -610,  -610,  -610}
    ,{   220,   220,   220,   220,   220}
    ,{  -610,  -610,  -610,  -610,  -610}
    }
   ,{{  -310,  -310,  -310,  -310,  -310}
    ,{  -310,  -310,  -310,  -310,  -310}
    ,{  -620,  -620,  -620,  -620,  -620}
    ,{ -1460, -1700, -1460, -1700, -1460}
    ,{  -620,  -620,  -620,  -620,  -620}
    }
   ,{{  -600,  -600,  -600,  -600,  -600}
    ,{  -600,  -600,  -600,  -600,  -600}
    ,{  -610,  -610,  -610,  -610,  -610}
    ,{  -600,  -600,  -600,  -600,  -600}
    ,{  -610,  -610,  -610,  -610,  -610}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{ -1280, -1520, -1280, -1520, -1280}
    ,{  -620,  -620,  -620,  -620,  -620}
    ,{   220,   220,   220,   220,   220}
    ,{  -620,  -620,  -620,  -620,  -620}
    }
   ,{{  -600,  -600,  -600,  -600,  -600}
    ,{  -600,  -600,  -600,  -600,  -600}
    ,{  -610,  -610,  -610,  -610,  -610}
    ,{  -600,  -600,  -600,  -600,  -600}
    ,{ -1590, -1590, -1590, -1590, -1590}
    }
   }
  ,{{{   940,  -320,   220,   940,   220}
    ,{   940,  -320,  -310,   940,  -310}
    ,{   640,  -380,  -610,   640,  -610}
    ,{   650,  -620,   220,   650,   220}
    ,{   640,  -380,  -610,   640,  -610}
    }
   ,{{   940,  -320,  -310,   940,  -310}
    ,{   940,  -320,  -310,   940,  -310}
    ,{   630,  -630,  -620,   630,  -620}
    ,{ -1700, -1710, -1700, -1700, -1700}
    ,{   630,  -630,  -620,   630,  -620}
    }
   ,{{   650,  -380,  -600,   650,  -600}
    ,{   650,  -620,  -600,   650,  -600}
    ,{   640,  -380,  -610,   640,  -610}
    ,{   650,  -620,  -600,   650,  -600}
    ,{   640,  -380,  -610,   640,  -610}
    }
   ,{{   630,  -630,   220,   630,   220}
    ,{ -1520, -1530, -1520, -1520, -1520}
    ,{   630,  -630,  -620,   630,  -620}
    ,{   220, -1040,   220, -1030,   220}
    ,{   630,  -630,  -620,   630,  -620}
    }
   ,{{   650,  -380,  -600,   650,  -600}
    ,{   650,  -620,  -600,   650,  -600}
    ,{   640,  -380,  -610,   640,  -610}
    ,{   650,  -620,  -600,   650,  -600}
    ,{ -1590, -1600, -1590, -1590, -1590}
    }
   }
  ,{{{   220,   220,   220,   220,   -70}
    ,{   -70,  -310,  -310,  -310,   -70}
    ,{  -610,  -610,  -610,  -610,  -610}
    ,{   220,   220,   220,   220,  -600}
    ,{  -610,  -610,  -610,  -610,  -610}
    }
   ,{{   -70,  -310,  -310,  -310,   -70}
    ,{   -70,  -310,  -310,  -310,   -70}
    ,{  -620,  -620,  -620,  -620,  -620}
    ,{ -1460, -1700, -1460, -1700, -1700}
    ,{  -620,  -620,  -620,  -620,  -620}
    }
   ,{{  -600,  -600,  -600,  -600,  -600}
    ,{  -600,  -600,  -600,  -600,  -600}
    ,{  -610,  -610,  -610,  -610,  -610}
    ,{  -600,  -600,  -600,  -600,  -600}
    ,{  -610,  -610,  -610,  -610,  -610}
    }
   ,{{   220,   220,   220,   220,  -620}
    ,{ -1280, -1520, -1280, -1520, -1520}
    ,{  -620,  -620,  -620,  -620,  -620}
    ,{   220,   220,   220,   220, -1030}
    ,{  -620,  -620,  -620,  -620,  -620}
    }
   ,{{  -600,  -600,  -600,  -600,  -600}
    ,{  -600,  -600,  -600,  -600,  -600}
    ,{  -610,  -610,  -610,  -610,  -610}
    ,{  -600,  -600,  -600,  -600,  -600}
    ,{ -1590, -1590, -1590, -1590, -1590}
    }
   }
  }
 ,{{{{  1010,   410,   410,  1010,   410}
    ,{  1010,  -240,  -240,  1010,     0}
    ,{   880,  -150,  -370,   880,  -370}
    ,{   880,   410,   410,   880,   410}
    ,{   750,  -280,  -500,   750,  -500}
    }
   ,{{  1010,  -240,  -240,  1010,     0}
    ,{  1010,  -240,  -240,  1010,     0}
    ,{   730,  -520,  -520,   730,  -520}
    ,{ -1410, -1650, -1410, -1470, -1410}
    ,{   730,  -520,  -520,   730,  -520}
    }
   ,{{   880,  -150,  -370,   880,  -370}
    ,{   880,  -370,  -370,   880,  -370}
    ,{   880,  -150,  -370,   880,  -370}
    ,{   880,  -370,  -370,   880,  -370}
    ,{   750,  -280,  -500,   750,  -500}
    }
   ,{{   730,   410,   410,   730,   410}
    ,{ -1710, -1950, -1710, -1770, -1710}
    ,{   730,  -520,  -520,   730,  -520}
    ,{   410,   410,   410,   410,   410}
    ,{   730,  -520,  -520,   730,  -520}
    }
   ,{{   880,  -370,  -370,   880,  -370}
    ,{   880,  -370,  -370,   880,  -370}
    ,{   440,  -590,  -810,   440,  -810}
    ,{   880,  -370,  -370,   880,  -370}
    ,{ -1140, -1250, -1310, -1140, -1310}
    }
   }
  ,{{{   410,   230,   410,    40,   410}
    ,{   -70,  -420,  -240,   -70,  -240}
    ,{    40,  -550,  -370,    40,  -370}
    ,{   410,   230,   410,  -200,   410}
    ,{   -90,  -680,  -500,   -90,  -500}
    }
   ,{{   -70,  -420,  -240,   -70,  -240}
    ,{   -70,  -420,  -240,   -70,  -240}
    ,{  -350,  -700,  -520,  -350,  -520}
    ,{ -1470, -1830, -1650, -1470, -1650}
    ,{  -350,  -700,  -520,  -350,  -520}
    }
   ,{{    40,  -550,  -370,    40,  -370}
    ,{  -200,  -550,  -370,  -200,  -370}
    ,{    40,  -550,  -370,    40,  -370}
    ,{  -200,  -550,  -370,  -200,  -370}
    ,{   -90,  -680,  -500,   -90,  -500}
    }
   ,{{   410,   230,   410,  -350,   410}
    ,{ -1770, -2130, -1950, -1770, -1950}
    ,{  -350,  -700,  -520,  -350,  -520}
    ,{   410,   230,   410,  -670,   410}
    ,{  -350,  -700,  -520,  -350,  -520}
    }
   ,{{  -200,  -550,  -370,  -200,  -370}
    ,{  -200,  -550,  -370,  -200,  -370}
    ,{  -400,  -990,  -810,  -400,  -810}
    ,{  -200,  -550,  -370,  -200,  -370}
    ,{ -1140, -1250, -1310, -1140, -1310}
    }
   }
  ,{{{   410,   410,   410,   410,   410}
    ,{  -240,  -240,  -240,  -240,  -240}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{   410,   410,   410,   410,   410}
    ,{  -500,  -500,  -500,  -500,  -500}
    }
   ,{{  -240,  -240,  -240,  -240,  -240}
    ,{  -240,  -240,  -240,  -240,  -240}
    ,{  -520,  -520,  -520,  -520,  -520}
    ,{ -1410, -1650, -1410, -1650, -1410}
    ,{  -520,  -520,  -520,  -520,  -520}
    }
   ,{{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -500,  -500,  -500,  -500,  -500}
    }
   ,{{   410,   410,   410,   410,   410}
    ,{ -1710, -1950, -1710, -1950, -1710}
    ,{  -520,  -520,  -520,  -520,  -520}
    ,{   410,   410,   410,   410,   410}
    ,{  -520,  -520,  -520,  -520,  -520}
    }
   ,{{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -810,  -810,  -810,  -810,  -810}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{ -1310, -1310, -1310, -1310, -1310}
    }
   }
  ,{{{  1010,  -150,   410,  1010,   410}
    ,{  1010,  -260,  -240,  1010,  -240}
    ,{   880,  -150,  -370,   880,  -370}
    ,{   880,  -390,   410,   880,   410}
    ,{   750,  -280,  -500,   750,  -500}
    }
   ,{{  1010,  -260,  -240,  1010,  -240}
    ,{  1010,  -260,  -240,  1010,  -240}
    ,{   730,  -540,  -520,   730,  -520}
    ,{ -1650, -1660, -1650, -1650, -1650}
    ,{   730,  -540,  -520,   730,  -520}
    }
   ,{{   880,  -150,  -370,   880,  -370}
    ,{   880,  -390,  -370,   880,  -370}
    ,{   880,  -150,  -370,   880,  -370}
    ,{   880,  -390,  -370,   880,  -370}
    ,{   750,  -280,  -500,   750,  -500}
    }
   ,{{   730,  -540,   410,   730,   410}
    ,{ -1950, -1960, -1950, -1950, -1950}
    ,{   730,  -540,  -520,   730,  -520}
    ,{   410,  -860,   410,  -840,   410}
    ,{   730,  -540,  -520,   730,  -520}
    }
   ,{{   880,  -390,  -370,   880,  -370}
    ,{   880,  -390,  -370,   880,  -370}
    ,{   440,  -590,  -810,   440,  -810}
    ,{   880,  -390,  -370,   880,  -370}
    ,{ -1310, -1330, -1310, -1310, -1310}
    }
   }
  ,{{{   410,   410,   410,   410,     0}
    ,{     0,  -240,  -240,  -240,     0}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{   410,   410,   410,   410,  -370}
    ,{  -500,  -500,  -500,  -500,  -500}
    }
   ,{{     0,  -240,  -240,  -240,     0}
    ,{     0,  -240,  -240,  -240,     0}
    ,{  -520,  -520,  -520,  -520,  -520}
    ,{ -1410, -1650, -1410, -1650, -1650}
    ,{  -520,  -520,  -520,  -520,  -520}
    }
   ,{{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -500,  -500,  -500,  -500,  -500}
    }
   ,{{   410,   410,   410,   410,  -520}
    ,{ -1710, -1950, -1710, -1950, -1950}
    ,{  -520,  -520,  -520,  -520,  -520}
    ,{   410,   410,   410,   410,  -840}
    ,{  -520,  -520,  -520,  -520,  -520}
    }
   ,{{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -810,  -810,  -810,  -810,  -810}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{ -1310, -1310, -1310, -1310, -1310}
    }
   }
  }
 ,{{{{  1010,   410,   410,  1010,   410}
    ,{  1010,   -70,  -240,  1010,     0}
    ,{   880,  -150,  -370,   880,  -370}
    ,{   880,   410,   410,   880,   410}
    ,{   750,  -280,  -500,   750,  -500}
    }
   ,{{  1010,   -70,  -240,  1010,     0}
    ,{  1010,   -70,  -240,  1010,     0}
    ,{   730,  -520,  -520,   730,  -520}
    ,{ -1180, -1420, -1180, -1250, -1180}
    ,{   730,  -520,  -520,   730,  -520}
    }
   ,{{   880,  -150,  -370,   880,  -370}
    ,{   880,  -370,  -370,   880,  -370}
    ,{   880,  -150,  -370,   880,  -370}
    ,{   880,  -370,  -370,   880,  -370}
    ,{   750,  -280,  -500,   750,  -500}
    }
   ,{{   730,   410,   410,   730,   410}
    ,{ -1280, -1520, -1280, -1340, -1280}
    ,{   730,  -520,  -520,   730,  -520}
    ,{   410,   410,   410,   410,   410}
    ,{   730,  -520,  -520,   730,  -520}
    }
   ,{{   880,  -370,  -370,   880,  -370}
    ,{   880,  -370,  -370,   880,  -370}
    ,{   640,  -380,  -610,   640,  -610}
    ,{   880,  -370,  -370,   880,  -370}
    ,{ -1140, -1250, -1310, -1140, -1310}
    }
   }
  ,{{{   410,   230,   410,    40,   410}
    ,{   -30,   -70,  -240,   -30,  -240}
    ,{    40,  -550,  -370,    40,  -370}
    ,{   410,   230,   410,  -200,   410}
    ,{   -90,  -680,  -500,   -90,  -500}
    }
   ,{{   -30,   -70,  -240,   -30,  -240}
    ,{   -30,   -70,  -240,   -30,  -240}
    ,{  -350,  -700,  -520,  -350,  -520}
    ,{ -1250, -1600, -1420, -1250, -1420}
    ,{  -350,  -700,  -520,  -350,  -520}
    }
   ,{{    40,  -550,  -370,    40,  -370}
    ,{  -200,  -550,  -370,  -200,  -370}
    ,{    40,  -550,  -370,    40,  -370}
    ,{  -200,  -550,  -370,  -200,  -370}
    ,{   -90,  -680,  -500,   -90,  -500}
    }
   ,{{   410,   230,   410,  -350,   410}
    ,{ -1340, -1700, -1520, -1340, -1520}
    ,{  -350,  -700,  -520,  -350,  -520}
    ,{   410,   230,   410,  -670,   410}
    ,{  -350,  -700,  -520,  -350,  -520}
    }
   ,{{  -190,  -550,  -370,  -190,  -370}
    ,{  -200,  -550,  -370,  -200,  -370}
    ,{  -190,  -790,  -610,  -190,  -610}
    ,{  -200,  -550,  -370,  -200,  -370}
    ,{ -1140, -1250, -1310, -1140, -1310}
    }
   }
  ,{{{   410,   410,   410,   410,   410}
    ,{  -240,  -240,  -240,  -240,  -240}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{   410,   410,   410,   410,   410}
    ,{  -500,  -500,  -500,  -500,  -500}
    }
   ,{{  -240,  -240,  -240,  -240,  -240}
    ,{  -240,  -240,  -240,  -240,  -240}
    ,{  -520,  -520,  -520,  -520,  -520}
    ,{ -1180, -1420, -1180, -1420, -1180}
    ,{  -520,  -520,  -520,  -520,  -520}
    }
   ,{{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -500,  -500,  -500,  -500,  -500}
    }
   ,{{   410,   410,   410,   410,   410}
    ,{ -1280, -1520, -1280, -1520, -1280}
    ,{  -520,  -520,  -520,  -520,  -520}
    ,{   410,   410,   410,   410,   410}
    ,{  -520,  -520,  -520,  -520,  -520}
    }
   ,{{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -610,  -610,  -610,  -610,  -610}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{ -1310, -1310, -1310, -1310, -1310}
    }
   }
  ,{{{  1010,  -150,   410,  1010,   410}
    ,{  1010,  -260,  -240,  1010,  -240}
    ,{   880,  -150,  -370,   880,  -370}
    ,{   880,  -390,   410,   880,   410}
    ,{   750,  -280,  -500,   750,  -500}
    }
   ,{{  1010,  -260,  -240,  1010,  -240}
    ,{  1010,  -260,  -240,  1010,  -240}
    ,{   730,  -540,  -520,   730,  -520}
    ,{ -1420, -1440, -1420, -1420, -1420}
    ,{   730,  -540,  -520,   730,  -520}
    }
   ,{{   880,  -150,  -370,   880,  -370}
    ,{   880,  -390,  -370,   880,  -370}
    ,{   880,  -150,  -370,   880,  -370}
    ,{   880,  -390,  -370,   880,  -370}
    ,{   750,  -280,  -500,   750,  -500}
    }
   ,{{   730,  -540,   410,   730,   410}
    ,{ -1520, -1530, -1520, -1520, -1520}
    ,{   730,  -540,  -520,   730,  -520}
    ,{   410,  -860,   410,  -840,   410}
    ,{   730,  -540,  -520,   730,  -520}
    }
   ,{{   880,  -380,  -370,   880,  -370}
    ,{   880,  -390,  -370,   880,  -370}
    ,{   640,  -380,  -610,   640,  -610}
    ,{   880,  -390,  -370,   880,  -370}
    ,{ -1310, -1330, -1310, -1310, -1310}
    }
   }
  ,{{{   410,   410,   410,   410,     0}
    ,{     0,  -240,  -240,  -240,     0}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{   410,   410,   410,   410,  -370}
    ,{  -500,  -500,  -500,  -500,  -500}
    }
   ,{{     0,  -240,  -240,  -240,     0}
    ,{     0,  -240,  -240,  -240,     0}
    ,{  -520,  -520,  -520,  -520,  -520}
    ,{ -1180, -1420, -1180, -1420, -1420}
    ,{  -520,  -520,  -520,  -520,  -520}
    }
   ,{{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -500,  -500,  -500,  -500,  -500}
    }
   ,{{   410,   410,   410,   410,  -520}
    ,{ -1280, -1520, -1280, -1520, -1520}
    ,{  -520,  -520,  -520,  -520,  -520}
    ,{   410,   410,   410,   410,  -840}
    ,{  -520,  -520,  -520,  -520,  -520}
    }
   ,{{  -370,  -370,  -370,  -370,  -370}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{  -610,  -610,  -610,  -610,  -610}
    ,{  -370,  -370,  -370,  -370,  -370}
    ,{ -1310, -1310, -1310, -1310, -1310}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   800,   200,  -310,   800,  -310}
    ,{   740,     0,  -510,   740,  -410}
    ,{   800,    50,  -450,   800,  -450}
    ,{   740,   200,  -310,   740,  -310}
    ,{   690,   -50,  -560,   690,  -560}
    }
   ,{{   600,  -140,  -630,   600,  -410}
    ,{   600,  -140,  -650,   600,  -410}
    ,{   290,  -450,  -960,   290,  -960}
    ,{  -360,  -360,  -630,  -870,  -630}
    ,{   290,  -450,  -960,   290,  -960}
    }
   ,{{   740,     0,  -510,   740,  -510}
    ,{   740,     0,  -510,   740,  -510}
    ,{   740,     0,  -510,   740,  -510}
    ,{   740,     0,  -510,   740,  -510}
    ,{   690,   -50,  -560,   690,  -560}
    }
   ,{{   290,   200,  -310,   290,  -310}
    ,{  -640,  -640,  -910, -1150,  -910}
    ,{   290,  -450,  -960,   290,  -960}
    ,{   200,   200,  -310,  -310,  -310}
    ,{   290,  -450,  -960,   290,  -960}
    }
   ,{{   800,    50,  -450,   800,  -450}
    ,{   740,     0,  -510,   740,  -510}
    ,{   800,    50,  -450,   800,  -450}
    ,{   740,     0,  -510,   740,  -510}
    ,{  -550,  -550, -1300, -1300, -1300}
    }
   }
  ,{{{   200,   200,  -310,  -720,  -310}
    ,{     0,     0,  -510, -1020,  -510}
    ,{    50,    50,  -450,  -720,  -450}
    ,{   200,   200,  -310, -1020,  -310}
    ,{   -50,   -50,  -560,  -830,  -560}
    }
   ,{{  -140,  -140,  -650, -1160,  -650}
    ,{  -140,  -140,  -650, -1160,  -650}
    ,{  -450,  -450,  -960, -1470,  -960}
    ,{  -360,  -360,  -870, -1380,  -870}
    ,{  -450,  -450,  -960, -1470,  -960}
    }
   ,{{     0,     0,  -510,  -780,  -510}
    ,{     0,     0,  -510, -1020,  -510}
    ,{     0,     0,  -510,  -780,  -510}
    ,{     0,     0,  -510, -1020,  -510}
    ,{   -50,   -50,  -560,  -830,  -560}
    }
   ,{{   200,   200,  -310, -1470,  -310}
    ,{  -640,  -640, -1150, -1660, -1150}
    ,{  -450,  -450,  -960, -1470,  -960}
    ,{   200,   200,  -310, -2070,  -310}
    ,{  -450,  -450,  -960, -1470,  -960}
    }
   ,{{    50,    50,  -450,  -720,  -450}
    ,{     0,     0,  -510, -1020,  -510}
    ,{    50,    50,  -450,  -720,  -450}
    ,{     0,     0,  -510, -1020,  -510}
    ,{  -550,  -550, -1300, -1810, -1300}
    }
   }
  ,{{{  -310,  -310,  -310,  -310,  -310}
    ,{  -510,  -510,  -510,  -510,  -510}
    ,{  -450,  -450,  -450,  -450,  -450}
    ,{  -310,  -310,  -310,  -310,  -310}
    ,{  -560,  -560,  -560,  -560,  -560}
    }
   ,{{  -630,  -650,  -630,  -650,  -630}
    ,{  -650,  -650,  -650,  -650,  -650}
    ,{  -960,  -960,  -960,  -960,  -960}
    ,{  -630,  -870,  -630,  -870,  -630}
    ,{  -960,  -960,  -960,  -960,  -960}
    }
   ,{{  -510,  -510,  -510,  -510,  -510}
    ,{  -510,  -510,  -510,  -510,  -510}
    ,{  -510,  -510,  -510,  -510,  -510}
    ,{  -510,  -510,  -510,  -510,  -510}
    ,{  -560,  -560,  -560,  -560,  -560}
    }
   ,{{  -310,  -310,  -310,  -310,  -310}
    ,{  -910, -1150,  -910, -1150,  -910}
    ,{  -960,  -960,  -960,  -960,  -960}
    ,{  -310,  -310,  -310,  -310,  -310}
    ,{  -960,  -960,  -960,  -960,  -960}
    }
   ,{{  -450,  -450,  -450,  -450,  -450}
    ,{  -510,  -510,  -510,  -510,  -510}
    ,{  -450,  -450,  -450,  -450,  -450}
    ,{  -510,  -510,  -510,  -510,  -510}
    ,{ -1300, -1300, -1300, -1300, -1300}
    }
   }
  ,{{{   800,  -550,  -310,   800,  -310}
    ,{   740,  -850,  -510,   740,  -510}
    ,{   800,  -550,  -450,   800,  -450}
    ,{   740,  -850,  -310,   740,  -310}
    ,{   690,  -660,  -560,   690,  -560}
    }
   ,{{   600,  -990,  -650,   600,  -650}
    ,{   600,  -990,  -650,   600,  -650}
    ,{   290, -1300,  -960,   290,  -960}
    ,{  -870, -1210,  -870,  -870,  -870}
    ,{   290, -1300,  -960,   290,  -960}
    }
   ,{{   740,  -610,  -510,   740,  -510}
    ,{   740,  -850,  -510,   740,  -510}
    ,{   740,  -610,  -510,   740,  -510}
    ,{   740,  -850,  -510,   740,  -510}
    ,{   690,  -660,  -560,   690,  -560}
    }
   ,{{   290, -1300,  -310,   290,  -310}
    ,{ -1150, -1490, -1150, -1150, -1150}
    ,{   290, -1300,  -960,   290,  -960}
    ,{  -310, -1900,  -310, -1560,  -310}
    ,{   290, -1300,  -960,   290,  -960}
    }
   ,{{   800,  -550,  -450,   800,  -450}
    ,{   740,  -850,  -510,   740,  -510}
    ,{   800,  -550,  -450,   800,  -450}
    ,{   740,  -850,  -510,   740,  -510}
    ,{ -1300, -1640, -1300, -1300, -1300}
    }
   }
  ,{{{  -310,  -310,  -310,  -310,  -410}
    ,{  -410,  -510,  -510,  -510,  -410}
    ,{  -450,  -450,  -450,  -450,  -450}
    ,{  -310,  -310,  -310,  -310,  -510}
    ,{  -560,  -560,  -560,  -560,  -560}
    }
   ,{{  -410,  -650,  -630,  -650,  -410}
    ,{  -410,  -650,  -650,  -650,  -410}
    ,{  -960,  -960,  -960,  -960,  -960}
    ,{  -630,  -870,  -630,  -870,  -870}
    ,{  -960,  -960,  -960,  -960,  -960}
    }
   ,{{  -510,  -510,  -510,  -510,  -510}
    ,{  -510,  -510,  -510,  -510,  -510}
    ,{  -510,  -510,  -510,  -510,  -510}
    ,{  -510,  -510,  -510,  -510,  -510}
    ,{  -560,  -560,  -560,  -560,  -560}
    }
   ,{{  -310,  -310,  -310,  -310,  -960}
    ,{  -910, -1150,  -910, -1150, -1150}
    ,{  -960,  -960,  -960,  -960,  -960}
    ,{  -310,  -310,  -310,  -310, -1560}
    ,{  -960,  -960,  -960,  -960,  -960}
    }
   ,{{  -450,  -450,  -450,  -450,  -450}
    ,{  -510,  -510,  -510,  -510,  -510}
    ,{  -450,  -450,  -450,  -450,  -450}
    ,{  -510,  -510,  -510,  -510,  -510}
    ,{ -1300, -1300, -1300, -1300, -1300}
    }
   }
  }
 ,{{{{   760,   200,  -310,   760,  -250}
    ,{   760,  -340,  -490,   760,  -250}
    ,{   310,  -430,  -940,   310,  -940}
    ,{   400,   200,  -310,   400,  -310}
    ,{   310,  -390,  -940,   310,  -940}
    }
   ,{{   760,  -430,  -490,   760,  -250}
    ,{   760,  -490,  -490,   760,  -250}
    ,{   310,  -430,  -940,   310,  -940}
    ,{ -1170, -1170, -1440, -1680, -1440}
    ,{   310,  -430,  -940,   310,  -940}
    }
   ,{{   400,  -340,  -850,   400,  -850}
    ,{   400,  -340,  -850,   400,  -850}
    ,{    90,  -650, -1160,    90, -1160}
    ,{   400,  -340,  -850,   400,  -850}
    ,{    90,  -650, -1160,    90, -1160}
    }
   ,{{   310,   200,  -310,   310,  -310}
    ,{  -690,  -690,  -960, -1200,  -960}
    ,{   310,  -430,  -940,   310,  -940}
    ,{   200,   200,  -310,  -310,  -310}
    ,{   310,  -430,  -940,   310,  -940}
    }
   ,{{   400,  -340,  -850,   400,  -850}
    ,{   400,  -340,  -850,   400,  -850}
    ,{  -220,  -960, -1470,  -220, -1470}
    ,{   400,  -340,  -850,   400,  -850}
    ,{  -390,  -390, -1140, -1140, -1140}
    }
   }
  ,{{{   200,   200,  -310, -1000,  -310}
    ,{  -340,  -340,  -490, -1000,  -490}
    ,{  -430,  -430,  -940, -1430,  -940}
    ,{   200,   200,  -310, -1360,  -310}
    ,{  -390,  -390,  -940, -1430,  -940}
    }
   ,{{  -430,  -430,  -490, -1000,  -490}
    ,{  -490, -2040,  -490, -1000,  -490}
    ,{  -430,  -430,  -940, -1450,  -940}
    ,{ -1170, -1170, -1680, -2190, -1680}
    ,{  -430,  -430,  -940, -1450,  -940}
    }
   ,{{  -340,  -340,  -850, -1360,  -850}
    ,{  -340,  -340,  -850, -1360,  -850}
    ,{  -650,  -650, -1160, -1430, -1160}
    ,{  -340,  -340,  -850, -1360,  -850}
    ,{  -650,  -650, -1160, -1430, -1160}
    }
   ,{{   200,   200,  -310, -1450,  -310}
    ,{  -690,  -690, -1200, -1710, -1200}
    ,{  -430,  -430,  -940, -1450,  -940}
    ,{   200,   200,  -310, -2070,  -310}
    ,{  -430,  -430,  -940, -1450,  -940}
    }
   ,{{  -340,  -340,  -850, -1360,  -850}
    ,{  -340,  -340,  -850, -1360,  -850}
    ,{  -960,  -960, -1470, -1740, -1470}
    ,{  -340,  -340,  -850, -1360,  -850}
    ,{  -390,  -390, -1140, -1650, -1140}
    }
   }
  ,{{{  -310,  -310,  -310,  -310,  -310}
    ,{  -490,  -490,  -490,  -490,  -490}
    ,{  -940,  -940,  -940,  -940,  -940}
    ,{  -310,  -310,  -310,  -310,  -310}
    ,{  -940,  -940,  -940,  -940,  -940}
    }
   ,{{  -490,  -490,  -490,  -490,  -490}
    ,{  -490,  -490,  -490,  -490,  -490}
    ,{  -940,  -940,  -940,  -940,  -940}
    ,{ -1440, -1680, -1440, -1680, -1440}
    ,{  -940,  -940,  -940,  -940,  -940}
    }
   ,{{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{ -1160, -1160, -1160, -1160, -1160}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{ -1160, -1160, -1160, -1160, -1160}
    }
   ,{{  -310,  -310,  -310,  -310,  -310}
    ,{  -960, -1200,  -960, -1200,  -960}
    ,{  -940,  -940,  -940,  -940,  -940}
    ,{  -310,  -310,  -310,  -310,  -310}
    ,{  -940,  -940,  -940,  -940,  -940}
    }
   ,{{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{ -1470, -1470, -1470, -1470, -1470}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{ -1140, -1140, -1140, -1140, -1140}
    }
   }
  ,{{{   760,  -830,  -310,   760,  -310}
    ,{   760,  -830,  -490,   760,  -490}
    ,{   310, -1260,  -940,   310,  -940}
    ,{   400, -1190,  -310,   400,  -310}
    ,{   310, -1260,  -940,   310,  -940}
    }
   ,{{   760,  -830,  -490,   760,  -490}
    ,{   760,  -830,  -490,   760,  -490}
    ,{   310, -1280,  -940,   310,  -940}
    ,{ -1680, -2020, -1680, -1680, -1680}
    ,{   310, -1280,  -940,   310,  -940}
    }
   ,{{   400, -1190,  -850,   400,  -850}
    ,{   400, -1190,  -850,   400,  -850}
    ,{    90, -1260, -1160,    90, -1160}
    ,{   400, -1190,  -850,   400,  -850}
    ,{    90, -1260, -1160,    90, -1160}
    }
   ,{{   310, -1280,  -310,   310,  -310}
    ,{ -1200, -1540, -1200, -1200, -1200}
    ,{   310, -1280,  -940,   310,  -940}
    ,{  -310, -1900,  -310, -1560,  -310}
    ,{   310, -1280,  -940,   310,  -940}
    }
   ,{{   400, -1190,  -850,   400,  -850}
    ,{   400, -1190,  -850,   400,  -850}
    ,{  -220, -1570, -1470,  -220, -1470}
    ,{   400, -1190,  -850,   400,  -850}
    ,{ -1140, -1480, -1140, -1140, -1140}
    }
   }
  ,{{{  -250,  -310,  -310,  -310,  -250}
    ,{  -250,  -490,  -490,  -490,  -250}
    ,{  -940,  -940,  -940,  -940,  -940}
    ,{  -310,  -310,  -310,  -310,  -850}
    ,{  -940,  -940,  -940,  -940,  -940}
    }
   ,{{  -250,  -490,  -490,  -490,  -250}
    ,{  -250,  -490,  -490,  -490,  -250}
    ,{  -940,  -940,  -940,  -940,  -940}
    ,{ -1440, -1680, -1440, -1680, -1680}
    ,{  -940,  -940,  -940,  -940,  -940}
    }
   ,{{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{ -1160, -1160, -1160, -1160, -1160}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{ -1160, -1160, -1160, -1160, -1160}
    }
   ,{{  -310,  -310,  -310,  -310,  -940}
    ,{  -960, -1200,  -960, -1200, -1200}
    ,{  -940,  -940,  -940,  -940,  -940}
    ,{  -310,  -310,  -310,  -310, -1560}
    ,{  -940,  -940,  -940,  -940,  -940}
    }
   ,{{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{ -1470, -1470, -1470, -1470, -1470}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{ -1140, -1140, -1140, -1140, -1140}
    }
   }
  }
 ,{{{{   360,   360,  -150,  -150,  -150}
    ,{   -30,   -30,  -990,  -150,  -990}
    ,{  -150,  -890, -1400,  -150, -1400}
    ,{   360,   360,  -150,  -150,  -150}
    ,{  -150,  -650, -1400,  -150, -1400}
    }
   ,{{   -70,   -70, -1180,  -150, -1180}
    ,{   -70,   -70, -1580,  -330, -1340}
    ,{  -150,  -890, -1400,  -150, -1400}
    ,{  -910,  -910, -1180, -1420, -1180}
    ,{  -150,  -890, -1400,  -150, -1400}
    }
   ,{{  -150,  -890, -1400,  -150, -1400}
    ,{  -150,  -890, -1400,  -150, -1400}
    ,{  -150,  -890, -1400,  -150, -1400}
    ,{  -150,  -890, -1400,  -150, -1400}
    ,{  -150,  -890, -1400,  -150, -1400}
    }
   ,{{   360,   360,  -150,  -150,  -150}
    ,{   -30,   -30,  -990, -1230,  -990}
    ,{  -150,  -890, -1400,  -150, -1400}
    ,{   360,   360,  -150,  -150,  -150}
    ,{  -150,  -890, -1400,  -150, -1400}
    }
   ,{{  -150,  -650, -1400,  -150, -1400}
    ,{  -150,  -890, -1400,  -150, -1400}
    ,{  -150,  -890, -1400,  -150, -1400}
    ,{  -150,  -890, -1400,  -150, -1400}
    ,{  -650,  -650, -1400, -1400, -1400}
    }
   }
  ,{{{   360,   360,  -150, -1670,  -150}
    ,{   -30,   -30, -1230, -1740, -1230}
    ,{  -890,  -890, -1400, -1670, -1400}
    ,{   360,   360,  -150, -1910,  -150}
    ,{  -650,  -650, -1400, -1670, -1400}
    }
   ,{{   -70,   -70, -1400, -1910, -1400}
    ,{   -70,   -70, -1580, -2090, -1580}
    ,{  -890,  -890, -1400, -1910, -1400}
    ,{  -910,  -910, -1420, -1930, -1420}
    ,{  -890,  -890, -1400, -1910, -1400}
    }
   ,{{  -890,  -890, -1400, -1670, -1400}
    ,{  -890,  -890, -1400, -1910, -1400}
    ,{  -890,  -890, -1400, -1670, -1400}
    ,{  -890,  -890, -1400, -1910, -1400}
    ,{  -890,  -890, -1400, -1670, -1400}
    }
   ,{{   360,   360,  -150, -1740,  -150}
    ,{   -30,   -30, -1230, -1740, -1230}
    ,{  -890,  -890, -1400, -1910, -1400}
    ,{   360,   360,  -150, -1910,  -150}
    ,{  -890,  -890, -1400, -1910, -1400}
    }
   ,{{  -650,  -650, -1400, -1670, -1400}
    ,{  -890,  -890, -1400, -1910, -1400}
    ,{  -890,  -890, -1400, -1670, -1400}
    ,{  -890,  -890, -1400, -1910, -1400}
    ,{  -650,  -650, -1400, -1910, -1400}
    }
   }
  ,{{{  -150,  -150,  -150,  -150,  -150}
    ,{  -990, -1230,  -990, -1230,  -990}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{  -150,  -150,  -150,  -150,  -150}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{ -1180, -1400, -1180, -1400, -1180}
    ,{ -1580, -1580, -1580, -1580, -1580}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1180, -1420, -1180, -1420, -1180}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{  -150,  -150,  -150,  -150,  -150}
    ,{  -990, -1230,  -990, -1230,  -990}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{  -150,  -150,  -150,  -150,  -150}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   }
  ,{{{  -150, -1500,  -150,  -150,  -150}
    ,{  -150, -1570, -1230,  -150, -1230}
    ,{  -150, -1500, -1400,  -150, -1400}
    ,{  -150, -1740,  -150,  -150,  -150}
    ,{  -150, -1500, -1400,  -150, -1400}
    }
   ,{{  -150, -1600, -1400,  -150, -1400}
    ,{  -330, -1600, -1580,  -330, -1580}
    ,{  -150, -1740, -1400,  -150, -1400}
    ,{ -1420, -3040, -1420, -1420, -1420}
    ,{  -150, -1740, -1400,  -150, -1400}
    }
   ,{{  -150, -1500, -1400,  -150, -1400}
    ,{  -150, -1740, -1400,  -150, -1400}
    ,{  -150, -1500, -1400,  -150, -1400}
    ,{  -150, -1740, -1400,  -150, -1400}
    ,{  -150, -1500, -1400,  -150, -1400}
    }
   ,{{  -150, -1570,  -150,  -150,  -150}
    ,{ -1230, -1570, -1230, -1230, -1230}
    ,{  -150, -1740, -1400,  -150, -1400}
    ,{  -150, -1740,  -150, -1400,  -150}
    ,{  -150, -1740, -1400,  -150, -1400}
    }
   ,{{  -150, -1500, -1400,  -150, -1400}
    ,{  -150, -1740, -1400,  -150, -1400}
    ,{  -150, -1500, -1400,  -150, -1400}
    ,{  -150, -1740, -1400,  -150, -1400}
    ,{ -1400, -1740, -1400, -1400, -1400}
    }
   }
  ,{{{  -150,  -150,  -150,  -150, -1230}
    ,{  -990, -1230,  -990, -1230, -1230}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{  -150,  -150,  -150,  -150, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{ -1180, -1400, -1180, -1400, -1340}
    ,{ -1340, -1580, -1580, -1580, -1340}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1180, -1420, -1180, -1420, -1420}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{  -150,  -150,  -150,  -150, -1230}
    ,{  -990, -1230,  -990, -1230, -1230}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{  -150,  -150,  -150,  -150, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   ,{{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    ,{ -1400, -1400, -1400, -1400, -1400}
    }
   }
  }
 ,{{{{   910,   910,   400,   910,   400}
    ,{   910,   170,  -340,   910,  -100}
    ,{   400,  -340,  -850,   400,  -850}
    ,{   910,   910,   400,   400,   400}
    ,{   400,  -100,  -850,   400,  -850}
    }
   ,{{   910,   170,  -340,   910,  -100}
    ,{   910,   170,  -340,   910,  -100}
    ,{   400,  -340,  -850,   400,  -850}
    ,{  -680,  -680,  -950, -1190,  -950}
    ,{   400,  -340,  -850,   400,  -850}
    }
   ,{{   400,  -340,  -850,   400,  -850}
    ,{   400,  -340,  -850,   400,  -850}
    ,{   400,  -340,  -850,   400,  -850}
    ,{   400,  -340,  -850,   400,  -850}
    ,{   400,  -340,  -850,   400,  -850}
    }
   ,{{   910,   910,   400,   400,   400}
    ,{  -850,  -850, -1120, -1360, -1120}
    ,{   400,  -340,  -850,   400,  -850}
    ,{   910,   910,   400,   400,   400}
    ,{   400,  -340,  -850,   400,  -850}
    }
   ,{{   400,  -100,  -850,   400,  -850}
    ,{   400,  -340,  -850,   400,  -850}
    ,{   400,  -340,  -850,   400,  -850}
    ,{   400,  -340,  -850,   400,  -850}
    ,{  -100,  -100,  -850,  -850,  -850}
    }
   }
  ,{{{   910,   910,   400,  -850,   400}
    ,{   170,   170,  -340,  -850,  -340}
    ,{  -340,  -340,  -850, -1120,  -850}
    ,{   910,   910,   400, -1360,   400}
    ,{  -100,  -100,  -850, -1120,  -850}
    }
   ,{{   170,   170,  -340,  -850,  -340}
    ,{   170,   170,  -340,  -850,  -340}
    ,{  -340,  -340,  -850, -1360,  -850}
    ,{  -680,  -680, -1190, -1700, -1190}
    ,{  -340,  -340,  -850, -1360,  -850}
    }
   ,{{  -340,  -340,  -850, -1120,  -850}
    ,{  -340,  -340,  -850, -1360,  -850}
    ,{  -340,  -340,  -850, -1120,  -850}
    ,{  -340,  -340,  -850, -1360,  -850}
    ,{  -340,  -340,  -850, -1120,  -850}
    }
   ,{{   910,   910,   400, -1360,   400}
    ,{  -850,  -850, -1360, -1870, -1360}
    ,{  -340,  -340,  -850, -1360,  -850}
    ,{   910,   910,   400, -1360,   400}
    ,{  -340,  -340,  -850, -1360,  -850}
    }
   ,{{  -100,  -100,  -850, -1120,  -850}
    ,{  -340,  -340,  -850, -1360,  -850}
    ,{  -340,  -340,  -850, -1120,  -850}
    ,{  -340,  -340,  -850, -1360,  -850}
    ,{  -100,  -100,  -850, -1360,  -850}
    }
   }
  ,{{{   400,   400,   400,   400,   400}
    ,{  -340,  -340,  -340,  -340,  -340}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{   400,   400,   400,   400,   400}
    ,{  -850,  -850,  -850,  -850,  -850}
    }
   ,{{  -340,  -340,  -340,  -340,  -340}
    ,{  -340,  -340,  -340,  -340,  -340}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -950, -1190,  -950, -1190,  -950}
    ,{  -850,  -850,  -850,  -850,  -850}
    }
   ,{{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    }
   ,{{   400,   400,   400,   400,   400}
    ,{ -1120, -1360, -1120, -1360, -1120}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{   400,   400,   400,   400,   400}
    ,{  -850,  -850,  -850,  -850,  -850}
    }
   ,{{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    }
   }
  ,{{{   910,  -680,   400,   910,   400}
    ,{   910,  -680,  -340,   910,  -340}
    ,{   400,  -950,  -850,   400,  -850}
    ,{   400, -1190,   400,   400,   400}
    ,{   400,  -950,  -850,   400,  -850}
    }
   ,{{   910,  -680,  -340,   910,  -340}
    ,{   910,  -680,  -340,   910,  -340}
    ,{   400, -1190,  -850,   400,  -850}
    ,{ -1190, -1530, -1190, -1190, -1190}
    ,{   400, -1190,  -850,   400,  -850}
    }
   ,{{   400,  -950,  -850,   400,  -850}
    ,{   400, -1190,  -850,   400,  -850}
    ,{   400,  -950,  -850,   400,  -850}
    ,{   400, -1190,  -850,   400,  -850}
    ,{   400,  -950,  -850,   400,  -850}
    }
   ,{{   400, -1190,   400,   400,   400}
    ,{ -1360, -1700, -1360, -1360, -1360}
    ,{   400, -1190,  -850,   400,  -850}
    ,{   400, -1190,   400,  -850,   400}
    ,{   400, -1190,  -850,   400,  -850}
    }
   ,{{   400,  -950,  -850,   400,  -850}
    ,{   400, -1190,  -850,   400,  -850}
    ,{   400,  -950,  -850,   400,  -850}
    ,{   400, -1190,  -850,   400,  -850}
    ,{  -850, -1190,  -850,  -850,  -850}
    }
   }
  ,{{{   400,   400,   400,   400,  -100}
    ,{  -100,  -340,  -340,  -340,  -100}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{   400,   400,   400,   400,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    }
   ,{{  -100,  -340,  -340,  -340,  -100}
    ,{  -100,  -340,  -340,  -340,  -100}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -950, -1190,  -950, -1190, -1190}
    ,{  -850,  -850,  -850,  -850,  -850}
    }
   ,{{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    }
   ,{{   400,   400,   400,   400,  -850}
    ,{ -1120, -1360, -1120, -1360, -1360}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{   400,   400,   400,   400,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    }
   ,{{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    ,{  -850,  -850,  -850,  -850,  -850}
    }
   }
  }
 ,{{{{  1490,  1280,   780,  1490,   780}
    ,{  1490,   750,   240,  1490,   480}
    ,{  1200,   450,   -50,  1200,   -50}
    ,{  1280,  1280,   780,  1200,   780}
    ,{  1200,   450,   -50,  1200,   -50}
    }
   ,{{  1490,   750,   240,  1490,   480}
    ,{  1490,   750,   240,  1490,   480}
    ,{  1190,   440,   -60,  1190,   -60}
    ,{  -630,  -630,  -900, -1140,  -900}
    ,{  1190,   440,   -60,  1190,   -60}
    }
   ,{{  1200,   460,   -50,  1200,   -50}
    ,{  1200,   460,   -50,  1200,   -50}
    ,{  1200,   450,   -50,  1200,   -50}
    ,{  1200,   460,   -50,  1200,   -50}
    ,{  1200,   450,   -50,  1200,   -50}
    }
   ,{{  1280,  1280,   780,  1190,   780}
    ,{  -450,  -450,  -720,  -960,  -720}
    ,{  1190,   440,   -60,  1190,   -60}
    ,{  1280,  1280,   780,   780,   780}
    ,{  1190,   440,   -60,  1190,   -60}
    }
   ,{{  1200,   460,   -50,  1200,   -50}
    ,{  1200,   460,   -50,  1200,   -50}
    ,{  1200,   450,   -50,  1200,   -50}
    ,{  1200,   460,   -50,  1200,   -50}
    ,{  -280,  -280, -1030, -1030, -1030}
    }
   }
  ,{{{  1280,  1280,   780,  -260,   780}
    ,{   750,   750,   240,  -260,   240}
    ,{   450,   450,   -50,  -320,   -50}
    ,{  1280,  1280,   780,  -560,   780}
    ,{   450,   450,   -50,  -320,   -50}
    }
   ,{{   750,   750,   240,  -260,   240}
    ,{   750,   750,   240,  -260,   240}
    ,{   440,   440,   -60,  -570,   -60}
    ,{  -630,  -630, -1140, -1650, -1140}
    ,{   440,   440,   -60,  -570,   -60}
    }
   ,{{   460,   460,   -50,  -320,   -50}
    ,{   460,   460,   -50,  -560,   -50}
    ,{   450,   450,   -50,  -320,   -50}
    ,{   460,   460,   -50,  -560,   -50}
    ,{   450,   450,   -50,  -320,   -50}
    }
   ,{{  1280,  1280,   780,  -570,   780}
    ,{  -450,  -450,  -960, -1470,  -960}
    ,{   440,   440,   -60,  -570,   -60}
    ,{  1280,  1280,   780,  -980,   780}
    ,{   440,   440,   -60,  -570,   -60}
    }
   ,{{   460,   460,   -50,  -320,   -50}
    ,{   460,   460,   -50,  -560,   -50}
    ,{   450,   450,   -50,  -320,   -50}
    ,{   460,   460,   -50,  -560,   -50}
    ,{  -280,  -280, -1030, -1540, -1030}
    }
   }
  ,{{{   780,   780,   780,   780,   780}
    ,{   240,   240,   240,   240,   240}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   780,   780,   780,   780,   780}
    ,{   -50,   -50,   -50,   -50,   -50}
    }
   ,{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   -60,   -60,   -60,   -60,   -60}
    ,{  -900, -1140,  -900, -1140,  -900}
    ,{   -60,   -60,   -60,   -60,   -60}
    }
   ,{{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    }
   ,{{   780,   780,   780,   780,   780}
    ,{  -720,  -960,  -720,  -960,  -720}
    ,{   -60,   -60,   -60,   -60,   -60}
    ,{   780,   780,   780,   780,   780}
    ,{   -60,   -60,   -60,   -60,   -60}
    }
   ,{{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{ -1030, -1030, -1030, -1030, -1030}
    }
   }
  ,{{{  1490,   -90,   780,  1490,   780}
    ,{  1490,   -90,   240,  1490,   240}
    ,{  1200,  -150,   -50,  1200,   -50}
    ,{  1200,  -390,   780,  1200,   780}
    ,{  1200,  -150,   -50,  1200,   -50}
    }
   ,{{  1490,   -90,   240,  1490,   240}
    ,{  1490,   -90,   240,  1490,   240}
    ,{  1190,  -400,   -60,  1190,   -60}
    ,{ -1140, -1480, -1140, -1140, -1140}
    ,{  1190,  -400,   -60,  1190,   -60}
    }
   ,{{  1200,  -150,   -50,  1200,   -50}
    ,{  1200,  -390,   -50,  1200,   -50}
    ,{  1200,  -150,   -50,  1200,   -50}
    ,{  1200,  -390,   -50,  1200,   -50}
    ,{  1200,  -150,   -50,  1200,   -50}
    }
   ,{{  1190,  -400,   780,  1190,   780}
    ,{  -960, -1300,  -960,  -960,  -960}
    ,{  1190,  -400,   -60,  1190,   -60}
    ,{   780,  -810,   780,  -470,   780}
    ,{  1190,  -400,   -60,  1190,   -60}
    }
   ,{{  1200,  -150,   -50,  1200,   -50}
    ,{  1200,  -390,   -50,  1200,   -50}
    ,{  1200,  -150,   -50,  1200,   -50}
    ,{  1200,  -390,   -50,  1200,   -50}
    ,{ -1030, -1370, -1030, -1030, -1030}
    }
   }
  ,{{{   780,   780,   780,   780,   480}
    ,{   480,   240,   240,   240,   480}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   780,   780,   780,   780,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    }
   ,{{   480,   240,   240,   240,   480}
    ,{   480,   240,   240,   240,   480}
    ,{   -60,   -60,   -60,   -60,   -60}
    ,{  -900, -1140,  -900, -1140, -1140}
    ,{   -60,   -60,   -60,   -60,   -60}
    }
   ,{{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    }
   ,{{   780,   780,   780,   780,   -60}
    ,{  -720,  -960,  -720,  -960,  -960}
    ,{   -60,   -60,   -60,   -60,   -60}
    ,{   780,   780,   780,   780,  -470}
    ,{   -60,   -60,   -60,   -60,   -60}
    }
   ,{{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{ -1030, -1030, -1030, -1030, -1030}
    }
   }
  }
 ,{{{{  1560,  1470,   960,  1560,   960}
    ,{  1560,   820,   310,  1560,   550}
    ,{  1430,   690,   180,  1430,   180}
    ,{  1470,  1470,   960,  1430,   960}
    ,{  1300,   560,    50,  1300,    50}
    }
   ,{{  1560,   820,   310,  1560,   550}
    ,{  1560,   820,   310,  1560,   550}
    ,{  1280,   540,    30,  1280,    30}
    ,{  -580,  -580,  -850, -1090,  -850}
    ,{  1280,   540,    30,  1280,    30}
    }
   ,{{  1430,   690,   180,  1430,   180}
    ,{  1430,   690,   180,  1430,   180}
    ,{  1430,   690,   180,  1430,   180}
    ,{  1430,   690,   180,  1430,   180}
    ,{  1300,   560,    50,  1300,    50}
    }
   ,{{  1470,  1470,   960,  1280,   960}
    ,{  -880,  -880, -1150, -1390, -1150}
    ,{  1280,   540,    30,  1280,    30}
    ,{  1470,  1470,   960,   960,   960}
    ,{  1280,   540,    30,  1280,    30}
    }
   ,{{  1430,   690,   180,  1430,   180}
    ,{  1430,   690,   180,  1430,   180}
    ,{   990,   250,  -260,   990,  -260}
    ,{  1430,   690,   180,  1430,   180}
    ,{   -10,   -10,  -760,  -760,  -760}
    }
   }
  ,{{{  1470,  1470,   960,   -90,   960}
    ,{   820,   820,   310,  -200,   310}
    ,{   690,   690,   180,   -90,   180}
    ,{  1470,  1470,   960,  -330,   960}
    ,{   560,   560,    50,  -220,    50}
    }
   ,{{   820,   820,   310,  -200,   310}
    ,{   820,   820,   310,  -200,   310}
    ,{   540,   540,    30,  -480,    30}
    ,{  -580,  -580, -1090, -1600, -1090}
    ,{   540,   540,    30,  -480,    30}
    }
   ,{{   690,   690,   180,   -90,   180}
    ,{   690,   690,   180,  -330,   180}
    ,{   690,   690,   180,   -90,   180}
    ,{   690,   690,   180,  -330,   180}
    ,{   560,   560,    50,  -220,    50}
    }
   ,{{  1470,  1470,   960,  -480,   960}
    ,{  -880,  -880, -1390, -1900, -1390}
    ,{   540,   540,    30,  -480,    30}
    ,{  1470,  1470,   960,  -800,   960}
    ,{   540,   540,    30,  -480,    30}
    }
   ,{{   690,   690,   180,  -330,   180}
    ,{   690,   690,   180,  -330,   180}
    ,{   250,   250,  -260,  -530,  -260}
    ,{   690,   690,   180,  -330,   180}
    ,{   -10,   -10,  -760, -1270,  -760}
    }
   }
  ,{{{   960,   960,   960,   960,   960}
    ,{   310,   310,   310,   310,   310}
    ,{   180,   180,   180,   180,   180}
    ,{   960,   960,   960,   960,   960}
    ,{    50,    50,    50,    50,    50}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{    30,    30,    30,    30,    30}
    ,{  -850, -1090,  -850, -1090,  -850}
    ,{    30,    30,    30,    30,    30}
    }
   ,{{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{    50,    50,    50,    50,    50}
    }
   ,{{   960,   960,   960,   960,   960}
    ,{ -1150, -1390, -1150, -1390, -1150}
    ,{    30,    30,    30,    30,    30}
    ,{   960,   960,   960,   960,   960}
    ,{    30,    30,    30,    30,    30}
    }
   ,{{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{  -260,  -260,  -260,  -260,  -260}
    ,{   180,   180,   180,   180,   180}
    ,{  -760,  -760,  -760,  -760,  -760}
    }
   }
  ,{{{  1560,    80,   960,  1560,   960}
    ,{  1560,   -30,   310,  1560,   310}
    ,{  1430,    80,   180,  1430,   180}
    ,{  1430,  -160,   960,  1430,   960}
    ,{  1300,   -50,    50,  1300,    50}
    }
   ,{{  1560,   -30,   310,  1560,   310}
    ,{  1560,   -30,   310,  1560,   310}
    ,{  1280,  -310,    30,  1280,    30}
    ,{ -1090, -1430, -1090, -1090, -1090}
    ,{  1280,  -310,    30,  1280,    30}
    }
   ,{{  1430,    80,   180,  1430,   180}
    ,{  1430,  -160,   180,  1430,   180}
    ,{  1430,    80,   180,  1430,   180}
    ,{  1430,  -160,   180,  1430,   180}
    ,{  1300,   -50,    50,  1300,    50}
    }
   ,{{  1280,  -310,   960,  1280,   960}
    ,{ -1390, -1730, -1390, -1390, -1390}
    ,{  1280,  -310,    30,  1280,    30}
    ,{   960,  -630,   960,  -290,   960}
    ,{  1280,  -310,    30,  1280,    30}
    }
   ,{{  1430,  -160,   180,  1430,   180}
    ,{  1430,  -160,   180,  1430,   180}
    ,{   990,  -360,  -260,   990,  -260}
    ,{  1430,  -160,   180,  1430,   180}
    ,{  -760, -1100,  -760,  -760,  -760}
    }
   }
  ,{{{   960,   960,   960,   960,   550}
    ,{   550,   310,   310,   310,   550}
    ,{   180,   180,   180,   180,   180}
    ,{   960,   960,   960,   960,   180}
    ,{    50,    50,    50,    50,    50}
    }
   ,{{   550,   310,   310,   310,   550}
    ,{   550,   310,   310,   310,   550}
    ,{    30,    30,    30,    30,    30}
    ,{  -850, -1090,  -850, -1090, -1090}
    ,{    30,    30,    30,    30,    30}
    }
   ,{{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{    50,    50,    50,    50,    50}
    }
   ,{{   960,   960,   960,   960,    30}
    ,{ -1150, -1390, -1150, -1390, -1390}
    ,{    30,    30,    30,    30,    30}
    ,{   960,   960,   960,   960,  -290}
    ,{    30,    30,    30,    30,    30}
    }
   ,{{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{  -260,  -260,  -260,  -260,  -260}
    ,{   180,   180,   180,   180,   180}
    ,{  -760,  -760,  -760,  -760,  -760}
    }
   }
  }
 ,{{{{  1560,  1470,   960,  1560,   960}
    ,{  1560,   820,   310,  1560,   550}
    ,{  1430,   690,   180,  1430,   180}
    ,{  1470,  1470,   960,  1430,   960}
    ,{  1300,   560,    50,  1300,    50}
    }
   ,{{  1560,   820,   310,  1560,   550}
    ,{  1560,   820,   310,  1560,   550}
    ,{  1280,   540,    30,  1280,    30}
    ,{  -360,  -360,  -630,  -870,  -630}
    ,{  1280,   540,    30,  1280,    30}
    }
   ,{{  1430,   690,   180,  1430,   180}
    ,{  1430,   690,   180,  1430,   180}
    ,{  1430,   690,   180,  1430,   180}
    ,{  1430,   690,   180,  1430,   180}
    ,{  1300,   560,    50,  1300,    50}
    }
   ,{{  1470,  1470,   960,  1280,   960}
    ,{   -30,   -30,  -720,  -960,  -720}
    ,{  1280,   540,    30,  1280,    30}
    ,{  1470,  1470,   960,   960,   960}
    ,{  1280,   540,    30,  1280,    30}
    }
   ,{{  1430,   690,   180,  1430,   180}
    ,{  1430,   690,   180,  1430,   180}
    ,{  1200,   450,   -50,  1200,   -50}
    ,{  1430,   690,   180,  1430,   180}
    ,{   -10,   -10,  -760,  -760,  -760}
    }
   }
  ,{{{  1470,  1470,   960,   -90,   960}
    ,{   820,   820,   310,  -200,   310}
    ,{   690,   690,   180,   -90,   180}
    ,{  1470,  1470,   960,  -330,   960}
    ,{   560,   560,    50,  -220,    50}
    }
   ,{{   820,   820,   310,  -200,   310}
    ,{   820,   820,   310,  -200,   310}
    ,{   540,   540,    30,  -480,    30}
    ,{  -360,  -360,  -870, -1380,  -870}
    ,{   540,   540,    30,  -480,    30}
    }
   ,{{   690,   690,   180,   -90,   180}
    ,{   690,   690,   180,  -330,   180}
    ,{   690,   690,   180,   -90,   180}
    ,{   690,   690,   180,  -330,   180}
    ,{   560,   560,    50,  -220,    50}
    }
   ,{{  1470,  1470,   960,  -480,   960}
    ,{   -30,   -30,  -960, -1470,  -960}
    ,{   540,   540,    30,  -480,    30}
    ,{  1470,  1470,   960,  -800,   960}
    ,{   540,   540,    30,  -480,    30}
    }
   ,{{   690,   690,   180,  -320,   180}
    ,{   690,   690,   180,  -330,   180}
    ,{   450,   450,   -50,  -320,   -50}
    ,{   690,   690,   180,  -330,   180}
    ,{   -10,   -10,  -760, -1270,  -760}
    }
   }
  ,{{{   960,   960,   960,   960,   960}
    ,{   310,   310,   310,   310,   310}
    ,{   180,   180,   180,   180,   180}
    ,{   960,   960,   960,   960,   960}
    ,{    50,    50,    50,    50,    50}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{    30,    30,    30,    30,    30}
    ,{  -630,  -870,  -630,  -870,  -630}
    ,{    30,    30,    30,    30,    30}
    }
   ,{{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{    50,    50,    50,    50,    50}
    }
   ,{{   960,   960,   960,   960,   960}
    ,{  -720,  -960,  -720,  -960,  -720}
    ,{    30,    30,    30,    30,    30}
    ,{   960,   960,   960,   960,   960}
    ,{    30,    30,    30,    30,    30}
    }
   ,{{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   180,   180,   180,   180,   180}
    ,{  -760,  -760,  -760,  -760,  -760}
    }
   }
  ,{{{  1560,    80,   960,  1560,   960}
    ,{  1560,   -30,   310,  1560,   310}
    ,{  1430,    80,   180,  1430,   180}
    ,{  1430,  -160,   960,  1430,   960}
    ,{  1300,   -50,    50,  1300,    50}
    }
   ,{{  1560,   -30,   310,  1560,   310}
    ,{  1560,   -30,   310,  1560,   310}
    ,{  1280,  -310,    30,  1280,    30}
    ,{  -870, -1210,  -870,  -870,  -870}
    ,{  1280,  -310,    30,  1280,    30}
    }
   ,{{  1430,    80,   180,  1430,   180}
    ,{  1430,  -160,   180,  1430,   180}
    ,{  1430,    80,   180,  1430,   180}
    ,{  1430,  -160,   180,  1430,   180}
    ,{  1300,   -50,    50,  1300,    50}
    }
   ,{{  1280,  -310,   960,  1280,   960}
    ,{  -960, -1300,  -960,  -960,  -960}
    ,{  1280,  -310,    30,  1280,    30}
    ,{   960,  -630,   960,  -290,   960}
    ,{  1280,  -310,    30,  1280,    30}
    }
   ,{{  1430,  -150,   180,  1430,   180}
    ,{  1430,  -160,   180,  1430,   180}
    ,{  1200,  -150,   -50,  1200,   -50}
    ,{  1430,  -160,   180,  1430,   180}
    ,{  -760, -1100,  -760,  -760,  -760}
    }
   }
  ,{{{   960,   960,   960,   960,   550}
    ,{   550,   310,   310,   310,   550}
    ,{   180,   180,   180,   180,   180}
    ,{   960,   960,   960,   960,   180}
    ,{    50,    50,    50,    50,    50}
    }
   ,{{   550,   310,   310,   310,   550}
    ,{   550,   310,   310,   310,   550}
    ,{    30,    30,    30,    30,    30}
    ,{  -630,  -870,  -630,  -870,  -870}
    ,{    30,    30,    30,    30,    30}
    }
   ,{{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{    50,    50,    50,    50,    50}
    }
   ,{{   960,   960,   960,   960,    30}
    ,{  -720,  -960,  -720,  -960,  -960}
    ,{    30,    30,    30,    30,    30}
    ,{   960,   960,   960,   960,  -290}
    ,{    30,    30,    30,    30,    30}
    }
   ,{{   180,   180,   180,   180,   180}
    ,{   180,   180,   180,   180,   180}
    ,{   -50,   -50,   -50,   -50,   -50}
    ,{   180,   180,   180,   180,   180}
    ,{  -760,  -760,  -760,  -760,  -760}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{  1170,   780,   490,  1170,   490}
    ,{  1120,   580,   290,  1120,   290}
    ,{  1170,   640,   340,  1170,   340}
    ,{  1120,   780,   490,  1120,   490}
    ,{  1060,   530,   230,  1060,   230}
    }
   ,{{   970,   440,   170,   970,   170}
    ,{   970,   440,   140,   970,   140}
    ,{   660,   130,  -160,   660,  -160}
    ,{   220,   220,   170,   -80,   170}
    ,{   660,   130,  -160,   660,  -160}
    }
   ,{{  1120,   580,   290,  1120,   290}
    ,{  1120,   580,   290,  1120,   290}
    ,{  1110,   580,   280,  1110,   280}
    ,{  1120,   580,   290,  1120,   290}
    ,{  1060,   530,   230,  1060,   230}
    }
   ,{{   780,   780,   490,   660,   490}
    ,{   -60,   -60,  -120,  -370,  -120}
    ,{   660,   130,  -160,   660,  -160}
    ,{   780,   780,   490,   470,   490}
    ,{   660,   130,  -160,   660,  -160}
    }
   ,{{  1170,   640,   340,  1170,   340}
    ,{  1120,   580,   290,  1120,   290}
    ,{  1170,   640,   340,  1170,   340}
    ,{  1120,   580,   290,  1120,   290}
    ,{    40,    40,  -500,  -510,  -500}
    }
   }
  ,{{{   780,   780,   490,  -330,   490}
    ,{   580,   580,   290,  -620,   290}
    ,{   640,   640,   340,  -330,   340}
    ,{   780,   780,   490,  -620,   490}
    ,{   530,   530,   230,  -440,   230}
    }
   ,{{   440,   440,   140,  -770,   140}
    ,{   440,   440,   140,  -770,   140}
    ,{   130,   130,  -160, -1080,  -160}
    ,{   220,   220,   -70,  -980,   -70}
    ,{   130,   130,  -160, -1080,  -160}
    }
   ,{{   580,   580,   290,  -390,   290}
    ,{   580,   580,   290,  -620,   290}
    ,{   580,   580,   280,  -390,   280}
    ,{   580,   580,   290,  -620,   290}
    ,{   530,   530,   230,  -440,   230}
    }
   ,{{   780,   780,   490, -1080,   490}
    ,{   -60,   -60,  -350, -1270,  -350}
    ,{   130,   130,  -160, -1080,  -160}
    ,{   780,   780,   490, -1680,   490}
    ,{   130,   130,  -160, -1080,  -160}
    }
   ,{{   640,   640,   340,  -330,   340}
    ,{   580,   580,   290,  -620,   290}
    ,{   640,   640,   340,  -330,   340}
    ,{   580,   580,   290,  -620,   290}
    ,{    40,    40,  -500, -1410,  -500}
    }
   }
  ,{{{   480,   470,   480,   470,   480}
    ,{   280,   270,   280,   270,   280}
    ,{   340,   330,   340,   330,   340}
    ,{   480,   470,   480,   470,   480}
    ,{   230,   220,   230,   220,   230}
    }
   ,{{   170,   130,   170,   130,   170}
    ,{   140,   130,   140,   130,   140}
    ,{  -170,  -180,  -170,  -180,  -170}
    ,{   170,   -80,   170,   -80,   170}
    ,{  -170,  -180,  -170,  -180,  -170}
    }
   ,{{   280,   270,   280,   270,   280}
    ,{   280,   270,   280,   270,   280}
    ,{   280,   270,   280,   270,   280}
    ,{   280,   270,   280,   270,   280}
    ,{   230,   220,   230,   220,   230}
    }
   ,{{   480,   470,   480,   470,   480}
    ,{  -120,  -370,  -120,  -370,  -120}
    ,{  -170,  -180,  -170,  -180,  -170}
    ,{   480,   470,   480,   470,   480}
    ,{  -170,  -180,  -170,  -180,  -170}
    }
   ,{{   340,   330,   340,   330,   340}
    ,{   280,   270,   280,   270,   280}
    ,{   340,   330,   340,   330,   340}
    ,{   280,   270,   280,   270,   280}
    ,{  -500,  -510,  -500,  -510,  -500}
    }
   }
  ,{{{  1170,  -510,   490,  1170,   490}
    ,{  1120,  -800,   290,  1120,   290}
    ,{  1170,  -510,   340,  1170,   340}
    ,{  1120,  -800,   490,  1120,   490}
    ,{  1060,  -620,   230,  1060,   230}
    }
   ,{{   970,  -950,   140,   970,   140}
    ,{   970,  -950,   140,   970,   140}
    ,{   660, -1260,  -160,   660,  -160}
    ,{   -70, -1160,   -70,  -490,   -70}
    ,{   660, -1260,  -160,   660,  -160}
    }
   ,{{  1120,  -570,   290,  1120,   290}
    ,{  1120,  -800,   290,  1120,   290}
    ,{  1110,  -570,   280,  1110,   280}
    ,{  1120,  -800,   290,  1120,   290}
    ,{  1060,  -620,   230,  1060,   230}
    }
   ,{{   660, -1260,   490,   660,   490}
    ,{  -350, -1450,  -350,  -780,  -350}
    ,{   660, -1260,  -160,   660,  -160}
    ,{   490, -1860,   490, -1190,   490}
    ,{   660, -1260,  -160,   660,  -160}
    }
   ,{{  1170,  -510,   340,  1170,   340}
    ,{  1120,  -800,   290,  1120,   290}
    ,{  1170,  -510,   340,  1170,   340}
    ,{  1120,  -800,   290,  1120,   290}
    ,{  -500, -1590,  -500,  -920,  -500}
    }
   }
  ,{{{   480,   470,   480,   470,  -600}
    ,{   280,   270,   280,   270,  -600}
    ,{   340,   330,   340,   330,  -640}
    ,{   480,   470,   480,   470,  -690}
    ,{   230,   220,   230,   220,  -750}
    }
   ,{{   170,   130,   170,   130,  -600}
    ,{   140,   130,   140,   130,  -600}
    ,{  -170,  -180,  -170,  -180, -1150}
    ,{   170,   -80,   170,   -80, -1050}
    ,{  -170,  -180,  -170,  -180, -1150}
    }
   ,{{   280,   270,   280,   270,  -690}
    ,{   280,   270,   280,   270,  -690}
    ,{   280,   270,   280,   270,  -700}
    ,{   280,   270,   280,   270,  -690}
    ,{   230,   220,   230,   220,  -750}
    }
   ,{{   480,   470,   480,   470, -1150}
    ,{  -120,  -370,  -120,  -370, -1340}
    ,{  -170,  -180,  -170,  -180, -1150}
    ,{   480,   470,   480,   470, -1750}
    ,{  -170,  -180,  -170,  -180, -1150}
    }
   ,{{   340,   330,   340,   330,  -640}
    ,{   280,   270,   280,   270,  -690}
    ,{   340,   330,   340,   330,  -640}
    ,{   280,   270,   280,   270,  -690}
    ,{  -500,  -510,  -500,  -510, -1480}
    }
   }
  }
 ,{{{{  1140,   780,   490,  1140,   490}
    ,{  1140,   600,   310,  1140,   310}
    ,{   690,   150,  -140,   690,  -140}
    ,{   780,   780,   490,   770,   490}
    ,{   690,   190,  -140,   690,  -140}
    }
   ,{{  1140,   600,   310,  1140,   310}
    ,{  1140,   600,   310,  1140,   310}
    ,{   690,   150,  -140,   690,  -140}
    ,{  -580,  -580,  -640,  -890,  -640}
    ,{   690,   150,  -140,   690,  -140}
    }
   ,{{   770,   240,   -50,   770,   -50}
    ,{   770,   240,   -50,   770,   -50}
    ,{   470,   -60,  -360,   470,  -360}
    ,{   770,   240,   -50,   770,   -50}
    ,{   470,   -60,  -360,   470,  -360}
    }
   ,{{   780,   780,   490,   690,   490}
    ,{  -110,  -110,  -170,  -420,  -170}
    ,{   690,   150,  -140,   690,  -140}
    ,{   780,   780,   490,   470,   490}
    ,{   690,   150,  -140,   690,  -140}
    }
   ,{{   770,   240,   -50,   770,   -50}
    ,{   770,   240,   -50,   770,   -50}
    ,{   160,  -370,  -670,   160,  -670}
    ,{   770,   240,   -50,   770,   -50}
    ,{   190,   190,  -340,  -360,  -340}
    }
   }
  ,{{{   780,   780,   490,  -600,   490}
    ,{   600,   600,   310,  -600,   310}
    ,{   150,   150,  -140, -1030,  -140}
    ,{   780,   780,   490,  -970,   490}
    ,{   190,   190,  -140, -1030,  -140}
    }
   ,{{   600,   600,   310,  -600,   310}
    ,{   600,   600,   310,  -600,   310}
    ,{   150,   150,  -140, -1050,  -140}
    ,{  -580,  -580,  -880, -1790,  -880}
    ,{   150,   150,  -140, -1050,  -140}
    }
   ,{{   240,   240,   -50,  -970,   -50}
    ,{   240,   240,   -50,  -970,   -50}
    ,{   -60,   -60,  -360, -1030,  -360}
    ,{   240,   240,   -50,  -970,   -50}
    ,{   -60,   -60,  -360, -1030,  -360}
    }
   ,{{   780,   780,   490, -1050,   490}
    ,{  -110,  -110,  -400, -1320,  -400}
    ,{   150,   150,  -140, -1050,  -140}
    ,{   780,   780,   490, -1680,   490}
    ,{   150,   150,  -140, -1050,  -140}
    }
   ,{{   240,   240,   -50,  -970,   -50}
    ,{   240,   240,   -50,  -970,   -50}
    ,{  -370,  -370,  -670, -1340,  -670}
    ,{   240,   240,   -50,  -970,   -50}
    ,{   190,   190,  -340, -1260,  -340}
    }
   }
  ,{{{   480,   470,   480,   470,   480}
    ,{   300,   290,   300,   290,   300}
    ,{  -140,  -150,  -140,  -150,  -140}
    ,{   480,   470,   480,   470,   480}
    ,{  -140,  -150,  -140,  -150,  -140}
    }
   ,{{   300,   290,   300,   290,   300}
    ,{   300,   290,   300,   290,   300}
    ,{  -140,  -150,  -140,  -150,  -140}
    ,{  -640,  -890,  -640,  -890,  -640}
    ,{  -140,  -150,  -140,  -150,  -140}
    }
   ,{{   -60,   -70,   -60,   -70,   -60}
    ,{   -60,   -70,   -60,   -70,   -60}
    ,{  -360,  -370,  -360,  -370,  -360}
    ,{   -60,   -70,   -60,   -70,   -60}
    ,{  -360,  -370,  -360,  -370,  -360}
    }
   ,{{   480,   470,   480,   470,   480}
    ,{  -170,  -420,  -170,  -420,  -170}
    ,{  -140,  -150,  -140,  -150,  -140}
    ,{   480,   470,   480,   470,   480}
    ,{  -140,  -150,  -140,  -150,  -140}
    }
   ,{{   -60,   -70,   -60,   -70,   -60}
    ,{   -60,   -70,   -60,   -70,   -60}
    ,{  -670,  -680,  -670,  -680,  -670}
    ,{   -60,   -70,   -60,   -70,   -60}
    ,{  -350,  -360,  -350,  -360,  -350}
    }
   }
  ,{{{  1140,  -780,   490,  1140,   490}
    ,{  1140,  -780,   310,  1140,   310}
    ,{   690, -1210,  -140,   690,  -140}
    ,{   770, -1150,   490,   770,   490}
    ,{   690, -1210,  -140,   690,  -140}
    }
   ,{{  1140,  -780,   310,  1140,   310}
    ,{  1140,  -780,   310,  1140,   310}
    ,{   690, -1230,  -140,   690,  -140}
    ,{  -880, -1970,  -880, -1300,  -880}
    ,{   690, -1230,  -140,   690,  -140}
    }
   ,{{   770, -1150,   -50,   770,   -50}
    ,{   770, -1150,   -50,   770,   -50}
    ,{   470, -1210,  -360,   470,  -360}
    ,{   770, -1150,   -50,   770,   -50}
    ,{   470, -1210,  -360,   470,  -360}
    }
   ,{{   690, -1230,   490,   690,   490}
    ,{  -400, -1500,  -400,  -830,  -400}
    ,{   690, -1230,  -140,   690,  -140}
    ,{   490, -1860,   490, -1190,   490}
    ,{   690, -1230,  -140,   690,  -140}
    }
   ,{{   770, -1150,   -50,   770,   -50}
    ,{   770, -1150,   -50,   770,   -50}
    ,{   160, -1520,  -670,   160,  -670}
    ,{   770, -1150,   -50,   770,   -50}
    ,{  -340, -1440,  -340,  -770,  -340}
    }
   }
  ,{{{   480,   470,   480,   470,  -430}
    ,{   300,   290,   300,   290,  -430}
    ,{  -140,  -150,  -140,  -150, -1120}
    ,{   480,   470,   480,   470, -1040}
    ,{  -140,  -150,  -140,  -150, -1120}
    }
   ,{{   300,   290,   300,   290,  -430}
    ,{   300,   290,   300,   290,  -430}
    ,{  -140,  -150,  -140,  -150, -1120}
    ,{  -640,  -890,  -640,  -890, -1860}
    ,{  -140,  -150,  -140,  -150, -1120}
    }
   ,{{   -60,   -70,   -60,   -70, -1040}
    ,{   -60,   -70,   -60,   -70, -1040}
    ,{  -360,  -370,  -360,  -370, -1340}
    ,{   -60,   -70,   -60,   -70, -1040}
    ,{  -360,  -370,  -360,  -370, -1340}
    }
   ,{{   480,   470,   480,   470, -1120}
    ,{  -170,  -420,  -170,  -420, -1390}
    ,{  -140,  -150,  -140,  -150, -1120}
    ,{   480,   470,   480,   470, -1750}
    ,{  -140,  -150,  -140,  -150, -1120}
    }
   ,{{   -60,   -70,   -60,   -70, -1040}
    ,{   -60,   -70,   -60,   -70, -1040}
    ,{  -670,  -680,  -670,  -680, -1650}
    ,{   -60,   -70,   -60,   -70, -1040}
    ,{  -350,  -360,  -350,  -360, -1330}
    }
   }
  }
 ,{{{{   940,   940,   650,   630,   650}
    ,{   220,  -130,  -190,   220,  -190}
    ,{   220,  -310,  -600,   220,  -600}
    ,{   940,   940,   650,   630,   650}
    ,{   220,   -70,  -600,   220,  -600}
    }
   ,{{   220,  -310,  -380,   220,  -380}
    ,{    40,  -490,  -780,    40,  -780}
    ,{   220,  -310,  -600,   220,  -600}
    ,{  -320,  -320,  -380,  -630,  -380}
    ,{   220,  -310,  -600,   220,  -600}
    }
   ,{{   220,  -310,  -600,   220,  -600}
    ,{   220,  -310,  -600,   220,  -600}
    ,{   220,  -310,  -600,   220,  -600}
    ,{   220,  -310,  -600,   220,  -600}
    ,{   220,  -310,  -600,   220,  -600}
    }
   ,{{   940,   940,   650,   630,   650}
    ,{  -130,  -130,  -190,  -440,  -190}
    ,{   220,  -310,  -600,   220,  -600}
    ,{   940,   940,   650,   630,   650}
    ,{   220,  -310,  -600,   220,  -600}
    }
   ,{{   220,   -70,  -600,   220,  -600}
    ,{   220,  -310,  -600,   220,  -600}
    ,{   220,  -310,  -600,   220,  -600}
    ,{   220,  -310,  -600,   220,  -600}
    ,{   -70,   -70,  -600,  -620,  -600}
    }
   }
  ,{{{   940,   940,   650, -1280,   650}
    ,{  -130,  -130,  -430, -1340,  -430}
    ,{  -310,  -310,  -600, -1280,  -600}
    ,{   940,   940,   650, -1520,   650}
    ,{   -70,   -70,  -600, -1280,  -600}
    }
   ,{{  -310,  -310,  -600, -1520,  -600}
    ,{  -490,  -490,  -780, -1700,  -780}
    ,{  -310,  -310,  -600, -1520,  -600}
    ,{  -320,  -320,  -620, -1530,  -620}
    ,{  -310,  -310,  -600, -1520,  -600}
    }
   ,{{  -310,  -310,  -600, -1280,  -600}
    ,{  -310,  -310,  -600, -1520,  -600}
    ,{  -310,  -310,  -600, -1280,  -600}
    ,{  -310,  -310,  -600, -1520,  -600}
    ,{  -310,  -310,  -600, -1280,  -600}
    }
   ,{{   940,   940,   650, -1340,   650}
    ,{  -130,  -130,  -430, -1340,  -430}
    ,{  -310,  -310,  -600, -1520,  -600}
    ,{   940,   940,   650, -1520,   650}
    ,{  -310,  -310,  -600, -1520,  -600}
    }
   ,{{   -70,   -70,  -600, -1280,  -600}
    ,{  -310,  -310,  -600, -1520,  -600}
    ,{  -310,  -310,  -600, -1280,  -600}
    ,{  -310,  -310,  -600, -1520,  -600}
    ,{   -70,   -70,  -600, -1520,  -600}
    }
   }
  ,{{{   640,   630,   640,   630,   640}
    ,{  -190,  -440,  -190,  -440,  -190}
    ,{  -610,  -620,  -610,  -620,  -610}
    ,{   640,   630,   640,   630,   640}
    ,{  -610,  -620,  -610,  -620,  -610}
    }
   ,{{  -380,  -620,  -380,  -620,  -380}
    ,{  -790,  -800,  -790,  -800,  -790}
    ,{  -610,  -620,  -610,  -620,  -610}
    ,{  -380,  -630,  -380,  -630,  -380}
    ,{  -610,  -620,  -610,  -620,  -610}
    }
   ,{{  -610,  -620,  -610,  -620,  -610}
    ,{  -610,  -620,  -610,  -620,  -610}
    ,{  -610,  -620,  -610,  -620,  -610}
    ,{  -610,  -620,  -610,  -620,  -610}
    ,{  -610,  -620,  -610,  -620,  -610}
    }
   ,{{   640,   630,   640,   630,   640}
    ,{  -190,  -440,  -190,  -440,  -190}
    ,{  -610,  -620,  -610,  -620,  -610}
    ,{   640,   630,   640,   630,   640}
    ,{  -610,  -620,  -610,  -620,  -610}
    }
   ,{{  -610,  -620,  -610,  -620,  -610}
    ,{  -610,  -620,  -610,  -620,  -610}
    ,{  -610,  -620,  -610,  -620,  -610}
    ,{  -610,  -620,  -610,  -620,  -610}
    ,{  -610,  -620,  -610,  -620,  -610}
    }
   }
  ,{{{   650, -1460,   650,   220,   650}
    ,{   220, -1520,  -430,   220,  -430}
    ,{   220, -1460,  -600,   220,  -600}
    ,{   650, -1700,   650,   220,   650}
    ,{   220, -1460,  -600,   220,  -600}
    }
   ,{{   220, -1700,  -600,   220,  -600}
    ,{    40, -1880,  -780,    40,  -780}
    ,{   220, -1700,  -600,   220,  -600}
    ,{  -620, -1710,  -620, -1040,  -620}
    ,{   220, -1700,  -600,   220,  -600}
    }
   ,{{   220, -1460,  -600,   220,  -600}
    ,{   220, -1700,  -600,   220,  -600}
    ,{   220, -1460,  -600,   220,  -600}
    ,{   220, -1700,  -600,   220,  -600}
    ,{   220, -1460,  -600,   220,  -600}
    }
   ,{{   650, -1520,   650,   220,   650}
    ,{  -430, -1520,  -430,  -850,  -430}
    ,{   220, -1700,  -600,   220,  -600}
    ,{   650, -1700,   650, -1030,   650}
    ,{   220, -1700,  -600,   220,  -600}
    }
   ,{{   220, -1460,  -600,   220,  -600}
    ,{   220, -1700,  -600,   220,  -600}
    ,{   220, -1460,  -600,   220,  -600}
    ,{   220, -1700,  -600,   220,  -600}
    ,{  -600, -1700,  -600, -1030,  -600}
    }
   }
  ,{{{   640,   630,   640,   630, -1410}
    ,{  -190,  -440,  -190,  -440, -1410}
    ,{  -610,  -620,  -610,  -620, -1590}
    ,{   640,   630,   640,   630, -1590}
    ,{  -610,  -620,  -610,  -620, -1590}
    }
   ,{{  -380,  -620,  -380,  -620, -1530}
    ,{  -790,  -800,  -790,  -800, -1530}
    ,{  -610,  -620,  -610,  -620, -1590}
    ,{  -380,  -630,  -380,  -630, -1600}
    ,{  -610,  -620,  -610,  -620, -1590}
    }
   ,{{  -610,  -620,  -610,  -620, -1590}
    ,{  -610,  -620,  -610,  -620, -1590}
    ,{  -610,  -620,  -610,  -620, -1590}
    ,{  -610,  -620,  -610,  -620, -1590}
    ,{  -610,  -620,  -610,  -620, -1590}
    }
   ,{{   640,   630,   640,   630, -1410}
    ,{  -190,  -440,  -190,  -440, -1410}
    ,{  -610,  -620,  -610,  -620, -1590}
    ,{   640,   630,   640,   630, -1590}
    ,{  -610,  -620,  -610,  -620, -1590}
    }
   ,{{  -610,  -620,  -610,  -620, -1590}
    ,{  -610,  -620,  -610,  -620, -1590}
    ,{  -610,  -620,  -610,  -620, -1590}
    ,{  -610,  -620,  -610,  -620, -1590}
    ,{  -610,  -620,  -610,  -620, -1590}
    }
   }
  }
 ,{{{{  1490,  1490,  1200,  1280,  1200}
    ,{  1280,   750,   460,  1280,   460}
    ,{   780,   240,   -50,   780,   -50}
    ,{  1490,  1490,  1200,  1190,  1200}
    ,{   780,   480,   -50,   780,   -50}
    }
   ,{{  1280,   750,   460,  1280,   460}
    ,{  1280,   750,   460,  1280,   460}
    ,{   780,   240,   -50,   780,   -50}
    ,{   -90,   -90,  -150,  -400,  -150}
    ,{   780,   240,   -50,   780,   -50}
    }
   ,{{   780,   240,   -50,   780,   -50}
    ,{   780,   240,   -50,   780,   -50}
    ,{   780,   240,   -50,   780,   -50}
    ,{   780,   240,   -50,   780,   -50}
    ,{   780,   240,   -50,   780,   -50}
    }
   ,{{  1490,  1490,  1200,  1190,  1200}
    ,{  -260,  -260,  -320,  -570,  -320}
    ,{   780,   240,   -50,   780,   -50}
    ,{  1490,  1490,  1200,  1190,  1200}
    ,{   780,   240,   -50,   780,   -50}
    }
   ,{{   780,   480,   -50,   780,   -50}
    ,{   780,   240,   -50,   780,   -50}
    ,{   780,   240,   -50,   780,   -50}
    ,{   780,   240,   -50,   780,   -50}
    ,{   480,   480,   -50,   -60,   -50}
    }
   }
  ,{{{  1490,  1490,  1200,  -450,  1200}
    ,{   750,   750,   460,  -450,   460}
    ,{   240,   240,   -50,  -720,   -50}
    ,{  1490,  1490,  1200,  -960,  1200}
    ,{   480,   480,   -50,  -720,   -50}
    }
   ,{{   750,   750,   460,  -450,   460}
    ,{   750,   750,   460,  -450,   460}
    ,{   240,   240,   -50,  -960,   -50}
    ,{   -90,   -90,  -390, -1300,  -390}
    ,{   240,   240,   -50,  -960,   -50}
    }
   ,{{   240,   240,   -50,  -720,   -50}
    ,{   240,   240,   -50,  -960,   -50}
    ,{   240,   240,   -50,  -720,   -50}
    ,{   240,   240,   -50,  -960,   -50}
    ,{   240,   240,   -50,  -720,   -50}
    }
   ,{{  1490,  1490,  1200,  -960,  1200}
    ,{  -260,  -260,  -560, -1470,  -560}
    ,{   240,   240,   -50,  -960,   -50}
    ,{  1490,  1490,  1200,  -960,  1200}
    ,{   240,   240,   -50,  -960,   -50}
    }
   ,{{   480,   480,   -50,  -720,   -50}
    ,{   240,   240,   -50,  -960,   -50}
    ,{   240,   240,   -50,  -720,   -50}
    ,{   240,   240,   -50,  -960,   -50}
    ,{   480,   480,   -50,  -960,   -50}
    }
   }
  ,{{{  1200,  1190,  1200,  1190,  1200}
    ,{   450,   440,   450,   440,   450}
    ,{   -50,   -60,   -50,   -60,   -50}
    ,{  1200,  1190,  1200,  1190,  1200}
    ,{   -50,   -60,   -50,   -60,   -50}
    }
   ,{{   450,   440,   450,   440,   450}
    ,{   450,   440,   450,   440,   450}
    ,{   -50,   -60,   -50,   -60,   -50}
    ,{  -150,  -400,  -150,  -400,  -150}
    ,{   -50,   -60,   -50,   -60,   -50}
    }
   ,{{   -50,   -60,   -50,   -60,   -50}
    ,{   -50,   -60,   -50,   -60,   -50}
    ,{   -50,   -60,   -50,   -60,   -50}
    ,{   -50,   -60,   -50,   -60,   -50}
    ,{   -50,   -60,   -50,   -60,   -50}
    }
   ,{{  1200,  1190,  1200,  1190,  1200}
    ,{  -320,  -570,  -320,  -570,  -320}
    ,{   -50,   -60,   -50,   -60,   -50}
    ,{  1200,  1190,  1200,  1190,  1200}
    ,{   -50,   -60,   -50,   -60,   -50}
    }
   ,{{   -50,   -60,   -50,   -60,   -50}
    ,{   -50,   -60,   -50,   -60,   -50}
    ,{   -50,   -60,   -50,   -60,   -50}
    ,{   -50,   -60,   -50,   -60,   -50}
    ,{   -50,   -60,   -50,   -60,   -50}
    }
   }
  ,{{{  1280,  -630,  1200,  1280,  1200}
    ,{  1280,  -630,   460,  1280,   460}
    ,{   780,  -900,   -50,   780,   -50}
    ,{  1200, -1140,  1200,   780,  1200}
    ,{   780,  -900,   -50,   780,   -50}
    }
   ,{{  1280,  -630,   460,  1280,   460}
    ,{  1280,  -630,   460,  1280,   460}
    ,{   780, -1140,   -50,   780,   -50}
    ,{  -390, -1480,  -390,  -810,  -390}
    ,{   780, -1140,   -50,   780,   -50}
    }
   ,{{   780,  -900,   -50,   780,   -50}
    ,{   780, -1140,   -50,   780,   -50}
    ,{   780,  -900,   -50,   780,   -50}
    ,{   780, -1140,   -50,   780,   -50}
    ,{   780,  -900,   -50,   780,   -50}
    }
   ,{{  1200, -1140,  1200,   780,  1200}
    ,{  -560, -1650,  -560,  -980,  -560}
    ,{   780, -1140,   -50,   780,   -50}
    ,{  1200, -1140,  1200,  -470,  1200}
    ,{   780, -1140,   -50,   780,   -50}
    }
   ,{{   780,  -900,   -50,   780,   -50}
    ,{   780, -1140,   -50,   780,   -50}
    ,{   780,  -900,   -50,   780,   -50}
    ,{   780, -1140,   -50,   780,   -50}
    ,{   -50, -1140,   -50,  -470,   -50}
    }
   }
  ,{{{  1200,  1190,  1200,  1190,  -280}
    ,{   450,   440,   450,   440,  -280}
    ,{   -50,   -60,   -50,   -60, -1030}
    ,{  1200,  1190,  1200,  1190, -1030}
    ,{   -50,   -60,   -50,   -60, -1030}
    }
   ,{{   450,   440,   450,   440,  -280}
    ,{   450,   440,   450,   440,  -280}
    ,{   -50,   -60,   -50,   -60, -1030}
    ,{  -150,  -400,  -150,  -400, -1370}
    ,{   -50,   -60,   -50,   -60, -1030}
    }
   ,{{   -50,   -60,   -50,   -60, -1030}
    ,{   -50,   -60,   -50,   -60, -1030}
    ,{   -50,   -60,   -50,   -60, -1030}
    ,{   -50,   -60,   -50,   -60, -1030}
    ,{   -50,   -60,   -50,   -60, -1030}
    }
   ,{{  1200,  1190,  1200,  1190, -1030}
    ,{  -320,  -570,  -320,  -570, -1540}
    ,{   -50,   -60,   -50,   -60, -1030}
    ,{  1200,  1190,  1200,  1190, -1030}
    ,{   -50,   -60,   -50,   -60, -1030}
    }
   ,{{   -50,   -60,   -50,   -60, -1030}
    ,{   -50,   -60,   -50,   -60, -1030}
    ,{   -50,   -60,   -50,   -60, -1030}
    ,{   -50,   -60,   -50,   -60, -1030}
    ,{   -50,   -60,   -50,   -60, -1030}
    }
   }
  }
 ,{{{{  1870,  1870,  1570,  1870,  1570}
    ,{  1870,  1340,  1040,  1870,  1040}
    ,{  1570,  1040,   740,  1570,   740}
    ,{  1870,  1870,  1570,  1570,  1570}
    ,{  1570,  1040,   740,  1570,   740}
    }
   ,{{  1870,  1340,  1040,  1870,  1040}
    ,{  1870,  1340,  1040,  1870,  1040}
    ,{  1560,  1030,   730,  1560,   730}
    ,{   -50,   -50,  -110,  -360,  -110}
    ,{  1560,  1030,   730,  1560,   730}
    }
   ,{{  1570,  1040,   750,  1570,   750}
    ,{  1570,  1040,   750,  1570,   750}
    ,{  1570,  1040,   740,  1570,   740}
    ,{  1570,  1040,   750,  1570,   750}
    ,{  1570,  1040,   740,  1570,   740}
    }
   ,{{  1870,  1870,  1570,  1560,  1570}
    ,{   130,   130,    70,  -180,    70}
    ,{  1560,  1030,   730,  1560,   730}
    ,{  1870,  1870,  1570,  1560,  1570}
    ,{  1560,  1030,   730,  1560,   730}
    }
   ,{{  1570,  1040,   750,  1570,   750}
    ,{  1570,  1040,   750,  1570,   750}
    ,{  1570,  1040,   740,  1570,   740}
    ,{  1570,  1040,   750,  1570,   750}
    ,{   300,   300,  -230,  -250,  -230}
    }
   }
  ,{{{  1870,  1870,  1570,   130,  1570}
    ,{  1340,  1340,  1040,   130,  1040}
    ,{  1040,  1040,   740,    70,   740}
    ,{  1870,  1870,  1570,  -160,  1570}
    ,{  1040,  1040,   740,    70,   740}
    }
   ,{{  1340,  1340,  1040,   130,  1040}
    ,{  1340,  1340,  1040,   130,  1040}
    ,{  1030,  1030,   730,  -180,   730}
    ,{   -50,   -50,  -340, -1260,  -340}
    ,{  1030,  1030,   730,  -180,   730}
    }
   ,{{  1040,  1040,   750,    70,   750}
    ,{  1040,  1040,   750,  -160,   750}
    ,{  1040,  1040,   740,    70,   740}
    ,{  1040,  1040,   750,  -160,   750}
    ,{  1040,  1040,   740,    70,   740}
    }
   ,{{  1870,  1870,  1570,  -180,  1570}
    ,{   130,   130,  -160, -1080,  -160}
    ,{  1030,  1030,   730,  -180,   730}
    ,{  1870,  1870,  1570,  -590,  1570}
    ,{  1030,  1030,   730,  -180,   730}
    }
   ,{{  1040,  1040,   750,    70,   750}
    ,{  1040,  1040,   750,  -160,   750}
    ,{  1040,  1040,   740,    70,   740}
    ,{  1040,  1040,   750,  -160,   750}
    ,{   300,   300,  -230, -1150,  -230}
    }
   }
  ,{{{  1570,  1560,  1570,  1560,  1570}
    ,{  1040,  1030,  1040,  1030,  1040}
    ,{   740,   730,   740,   730,   740}
    ,{  1570,  1560,  1570,  1560,  1570}
    ,{   740,   730,   740,   730,   740}
    }
   ,{{  1040,  1030,  1040,  1030,  1040}
    ,{  1040,  1030,  1040,  1030,  1040}
    ,{   730,   720,   730,   720,   730}
    ,{  -110,  -360,  -110,  -360,  -110}
    ,{   730,   720,   730,   720,   730}
    }
   ,{{   740,   730,   740,   730,   740}
    ,{   740,   730,   740,   730,   740}
    ,{   740,   730,   740,   730,   740}
    ,{   740,   730,   740,   730,   740}
    ,{   740,   730,   740,   730,   740}
    }
   ,{{  1570,  1560,  1570,  1560,  1570}
    ,{    70,  -180,    70,  -180,    70}
    ,{   730,   720,   730,   720,   730}
    ,{  1570,  1560,  1570,  1560,  1570}
    ,{   730,   720,   730,   720,   730}
    }
   ,{{   740,   730,   740,   730,   740}
    ,{   740,   730,   740,   730,   740}
    ,{   740,   730,   740,   730,   740}
    ,{   740,   730,   740,   730,   740}
    ,{  -240,  -250,  -240,  -250,  -240}
    }
   }
  ,{{{  1870,   -50,  1570,  1870,  1570}
    ,{  1870,   -50,  1040,  1870,  1040}
    ,{  1570,  -110,   740,  1570,   740}
    ,{  1570,  -340,  1570,  1570,  1570}
    ,{  1570,  -110,   740,  1570,   740}
    }
   ,{{  1870,   -50,  1040,  1870,  1040}
    ,{  1870,   -50,  1040,  1870,  1040}
    ,{  1560,  -360,   730,  1560,   730}
    ,{  -340, -1440,  -340,  -770,  -340}
    ,{  1560,  -360,   730,  1560,   730}
    }
   ,{{  1570,  -110,   750,  1570,   750}
    ,{  1570,  -340,   750,  1570,   750}
    ,{  1570,  -110,   740,  1570,   740}
    ,{  1570,  -340,   750,  1570,   750}
    ,{  1570,  -110,   740,  1570,   740}
    }
   ,{{  1570,  -360,  1570,  1560,  1570}
    ,{  -160, -1260,  -160,  -590,  -160}
    ,{  1560,  -360,   730,  1560,   730}
    ,{  1570,  -770,  1570,  -100,  1570}
    ,{  1560,  -360,   730,  1560,   730}
    }
   ,{{  1570,  -110,   750,  1570,   750}
    ,{  1570,  -340,   750,  1570,   750}
    ,{  1570,  -110,   740,  1570,   740}
    ,{  1570,  -340,   750,  1570,   750}
    ,{  -230, -1330,  -230,  -660,  -230}
    }
   }
  ,{{{  1570,  1560,  1570,  1560,   300}
    ,{  1040,  1030,  1040,  1030,   300}
    ,{   740,   730,   740,   730,  -240}
    ,{  1570,  1560,  1570,  1560,  -230}
    ,{   740,   730,   740,   730,  -240}
    }
   ,{{  1040,  1030,  1040,  1030,   300}
    ,{  1040,  1030,  1040,  1030,   300}
    ,{   730,   720,   730,   720,  -250}
    ,{  -110,  -360,  -110,  -360, -1330}
    ,{   730,   720,   730,   720,  -250}
    }
   ,{{   740,   730,   740,   730,  -230}
    ,{   740,   730,   740,   730,  -230}
    ,{   740,   730,   740,   730,  -240}
    ,{   740,   730,   740,   730,  -230}
    ,{   740,   730,   740,   730,  -240}
    }
   ,{{  1570,  1560,  1570,  1560,  -250}
    ,{    70,  -180,    70,  -180, -1150}
    ,{   730,   720,   730,   720,  -250}
    ,{  1570,  1560,  1570,  1560,  -660}
    ,{   730,   720,   730,   720,  -250}
    }
   ,{{   740,   730,   740,   730,  -230}
    ,{   740,   730,   740,   730,  -230}
    ,{   740,   730,   740,   730,  -240}
    ,{   740,   730,   740,   730,  -230}
    ,{  -240,  -250,  -240,  -250, -1220}
    }
   }
  }
 ,{{{{  2050,  2050,  1760,  1930,  1760}
    ,{  1930,  1400,  1110,  1930,  1110}
    ,{  1800,  1270,   980,  1800,   980}
    ,{  2050,  2050,  1760,  1800,  1760}
    ,{  1670,  1140,   850,  1670,   850}
    }
   ,{{  1930,  1400,  1110,  1930,  1110}
    ,{  1930,  1400,  1110,  1930,  1110}
    ,{  1650,  1120,   830,  1650,   830}
    ,{     0,     0,   -60,  -310,   -60}
    ,{  1650,  1120,   830,  1650,   830}
    }
   ,{{  1800,  1270,   980,  1800,   980}
    ,{  1800,  1270,   980,  1800,   980}
    ,{  1800,  1270,   980,  1800,   980}
    ,{  1800,  1270,   980,  1800,   980}
    ,{  1670,  1140,   850,  1670,   850}
    }
   ,{{  2050,  2050,  1760,  1740,  1760}
    ,{  -300,  -300,  -360,  -610,  -360}
    ,{  1650,  1120,   830,  1650,   830}
    ,{  2050,  2050,  1760,  1740,  1760}
    ,{  1650,  1120,   830,  1650,   830}
    }
   ,{{  1800,  1270,   980,  1800,   980}
    ,{  1800,  1270,   980,  1800,   980}
    ,{  1360,   830,   540,  1360,   540}
    ,{  1800,  1270,   980,  1800,   980}
    ,{   570,   570,    40,    20,    40}
    }
   }
  ,{{{  2050,  2050,  1760,   300,  1760}
    ,{  1400,  1400,  1110,   190,  1110}
    ,{  1270,  1270,   980,   300,   980}
    ,{  2050,  2050,  1760,    60,  1760}
    ,{  1140,  1140,   850,   180,   850}
    }
   ,{{  1400,  1400,  1110,   190,  1110}
    ,{  1400,  1400,  1110,   190,  1110}
    ,{  1120,  1120,   830,   -80,   830}
    ,{     0,     0,  -290, -1210,  -290}
    ,{  1120,  1120,   830,   -80,   830}
    }
   ,{{  1270,  1270,   980,   300,   980}
    ,{  1270,  1270,   980,    60,   980}
    ,{  1270,  1270,   980,   300,   980}
    ,{  1270,  1270,   980,    60,   980}
    ,{  1140,  1140,   850,   180,   850}
    }
   ,{{  2050,  2050,  1760,   -80,  1760}
    ,{  -300,  -300,  -590, -1510,  -590}
    ,{  1120,  1120,   830,   -80,   830}
    ,{  2050,  2050,  1760,  -400,  1760}
    ,{  1120,  1120,   830,   -80,   830}
    }
   ,{{  1270,  1270,   980,    60,   980}
    ,{  1270,  1270,   980,    60,   980}
    ,{   830,   830,   540,  -130,   540}
    ,{  1270,  1270,   980,    60,   980}
    ,{   570,   570,    40,  -870,    40}
    }
   }
  ,{{{  1750,  1740,  1750,  1740,  1750}
    ,{  1100,  1090,  1100,  1090,  1100}
    ,{   970,   960,   970,   960,   970}
    ,{  1750,  1740,  1750,  1740,  1750}
    ,{   840,   830,   840,   830,   840}
    }
   ,{{  1100,  1090,  1100,  1090,  1100}
    ,{  1100,  1090,  1100,  1090,  1100}
    ,{   820,   810,   820,   810,   820}
    ,{   -60,  -310,   -60,  -310,   -60}
    ,{   820,   810,   820,   810,   820}
    }
   ,{{   970,   960,   970,   960,   970}
    ,{   970,   960,   970,   960,   970}
    ,{   970,   960,   970,   960,   970}
    ,{   970,   960,   970,   960,   970}
    ,{   840,   830,   840,   830,   840}
    }
   ,{{  1750,  1740,  1750,  1740,  1750}
    ,{  -360,  -610,  -360,  -610,  -360}
    ,{   820,   810,   820,   810,   820}
    ,{  1750,  1740,  1750,  1740,  1750}
    ,{   820,   810,   820,   810,   820}
    }
   ,{{   970,   960,   970,   960,   970}
    ,{   970,   960,   970,   960,   970}
    ,{   530,   520,   530,   520,   530}
    ,{   970,   960,   970,   960,   970}
    ,{    30,    20,    30,    20,    30}
    }
   }
  ,{{{  1930,   130,  1760,  1930,  1760}
    ,{  1930,    10,  1110,  1930,  1110}
    ,{  1800,   130,   980,  1800,   980}
    ,{  1800,  -110,  1760,  1800,  1760}
    ,{  1670,     0,   850,  1670,   850}
    }
   ,{{  1930,    10,  1110,  1930,  1110}
    ,{  1930,    10,  1110,  1930,  1110}
    ,{  1650,  -260,   830,  1650,   830}
    ,{  -290, -1390,  -290,  -720,  -290}
    ,{  1650,  -260,   830,  1650,   830}
    }
   ,{{  1800,   130,   980,  1800,   980}
    ,{  1800,  -110,   980,  1800,   980}
    ,{  1800,   130,   980,  1800,   980}
    ,{  1800,  -110,   980,  1800,   980}
    ,{  1670,     0,   850,  1670,   850}
    }
   ,{{  1760,  -260,  1760,  1650,  1760}
    ,{  -590, -1690,  -590, -1020,  -590}
    ,{  1650,  -260,   830,  1650,   830}
    ,{  1760,  -580,  1760,    80,  1760}
    ,{  1650,  -260,   830,  1650,   830}
    }
   ,{{  1800,  -110,   980,  1800,   980}
    ,{  1800,  -110,   980,  1800,   980}
    ,{  1360,  -310,   540,  1360,   540}
    ,{  1800,  -110,   980,  1800,   980}
    ,{    40, -1050,    40,  -380,    40}
    }
   }
  ,{{{  1750,  1740,  1750,  1740,   360}
    ,{  1100,  1090,  1100,  1090,   360}
    ,{   970,   960,   970,   960,     0}
    ,{  1750,  1740,  1750,  1740,     0}
    ,{   840,   830,   840,   830,  -130}
    }
   ,{{  1100,  1090,  1100,  1090,   360}
    ,{  1100,  1090,  1100,  1090,   360}
    ,{   820,   810,   820,   810,  -150}
    ,{   -60,  -310,   -60,  -310, -1280}
    ,{   820,   810,   820,   810,  -150}
    }
   ,{{   970,   960,   970,   960,     0}
    ,{   970,   960,   970,   960,     0}
    ,{   970,   960,   970,   960,     0}
    ,{   970,   960,   970,   960,     0}
    ,{   840,   830,   840,   830,  -130}
    }
   ,{{  1750,  1740,  1750,  1740,  -150}
    ,{  -360,  -610,  -360,  -610, -1580}
    ,{   820,   810,   820,   810,  -150}
    ,{  1750,  1740,  1750,  1740,  -470}
    ,{   820,   810,   820,   810,  -150}
    }
   ,{{   970,   960,   970,   960,     0}
    ,{   970,   960,   970,   960,     0}
    ,{   530,   520,   530,   520,  -440}
    ,{   970,   960,   970,   960,     0}
    ,{    30,    20,    30,    20,  -940}
    }
   }
  }
 ,{{{{  2050,  2050,  1760,  1930,  1760}
    ,{  1930,  1400,  1110,  1930,  1110}
    ,{  1800,  1270,   980,  1800,   980}
    ,{  2050,  2050,  1760,  1800,  1760}
    ,{  1670,  1140,   850,  1670,   850}
    }
   ,{{  1930,  1400,  1110,  1930,  1110}
    ,{  1930,  1400,  1110,  1930,  1110}
    ,{  1650,  1120,   830,  1650,   830}
    ,{   220,   220,   170,   -80,   170}
    ,{  1650,  1120,   830,  1650,   830}
    }
   ,{{  1800,  1270,   980,  1800,   980}
    ,{  1800,  1270,   980,  1800,   980}
    ,{  1800,  1270,   980,  1800,   980}
    ,{  1800,  1270,   980,  1800,   980}
    ,{  1670,  1140,   850,  1670,   850}
    }
   ,{{  2050,  2050,  1760,  1740,  1760}
    ,{   130,   130,    70,  -180,    70}
    ,{  1650,  1120,   830,  1650,   830}
    ,{  2050,  2050,  1760,  1740,  1760}
    ,{  1650,  1120,   830,  1650,   830}
    }
   ,{{  1800,  1270,   980,  1800,   980}
    ,{  1800,  1270,   980,  1800,   980}
    ,{  1570,  1040,   740,  1570,   740}
    ,{  1800,  1270,   980,  1800,   980}
    ,{   570,   570,    40,    20,    40}
    }
   }
  ,{{{  2050,  2050,  1760,   300,  1760}
    ,{  1400,  1400,  1110,   190,  1110}
    ,{  1270,  1270,   980,   300,   980}
    ,{  2050,  2050,  1760,    60,  1760}
    ,{  1140,  1140,   850,   180,   850}
    }
   ,{{  1400,  1400,  1110,   190,  1110}
    ,{  1400,  1400,  1110,   190,  1110}
    ,{  1120,  1120,   830,   -80,   830}
    ,{   220,   220,   -70,  -980,   -70}
    ,{  1120,  1120,   830,   -80,   830}
    }
   ,{{  1270,  1270,   980,   300,   980}
    ,{  1270,  1270,   980,    60,   980}
    ,{  1270,  1270,   980,   300,   980}
    ,{  1270,  1270,   980,    60,   980}
    ,{  1140,  1140,   850,   180,   850}
    }
   ,{{  2050,  2050,  1760,   -80,  1760}
    ,{   130,   130,  -160, -1080,  -160}
    ,{  1120,  1120,   830,   -80,   830}
    ,{  2050,  2050,  1760,  -400,  1760}
    ,{  1120,  1120,   830,   -80,   830}
    }
   ,{{  1270,  1270,   980,    70,   980}
    ,{  1270,  1270,   980,    60,   980}
    ,{  1040,  1040,   740,    70,   740}
    ,{  1270,  1270,   980,    60,   980}
    ,{   570,   570,    40,  -870,    40}
    }
   }
  ,{{{  1750,  1740,  1750,  1740,  1750}
    ,{  1100,  1090,  1100,  1090,  1100}
    ,{   970,   960,   970,   960,   970}
    ,{  1750,  1740,  1750,  1740,  1750}
    ,{   840,   830,   840,   830,   840}
    }
   ,{{  1100,  1090,  1100,  1090,  1100}
    ,{  1100,  1090,  1100,  1090,  1100}
    ,{   820,   810,   820,   810,   820}
    ,{   170,   -80,   170,   -80,   170}
    ,{   820,   810,   820,   810,   820}
    }
   ,{{   970,   960,   970,   960,   970}
    ,{   970,   960,   970,   960,   970}
    ,{   970,   960,   970,   960,   970}
    ,{   970,   960,   970,   960,   970}
    ,{   840,   830,   840,   830,   840}
    }
   ,{{  1750,  1740,  1750,  1740,  1750}
    ,{    70,  -180,    70,  -180,    70}
    ,{   820,   810,   820,   810,   820}
    ,{  1750,  1740,  1750,  1740,  1750}
    ,{   820,   810,   820,   810,   820}
    }
   ,{{   970,   960,   970,   960,   970}
    ,{   970,   960,   970,   960,   970}
    ,{   740,   730,   740,   730,   740}
    ,{   970,   960,   970,   960,   970}
    ,{    30,    20,    30,    20,    30}
    }
   }
  ,{{{  1930,   130,  1760,  1930,  1760}
    ,{  1930,    10,  1110,  1930,  1110}
    ,{  1800,   130,   980,  1800,   980}
    ,{  1800,  -110,  1760,  1800,  1760}
    ,{  1670,     0,   850,  1670,   850}
    }
   ,{{  1930,    10,  1110,  1930,  1110}
    ,{  1930,    10,  1110,  1930,  1110}
    ,{  1650,  -260,   830,  1650,   830}
    ,{   -70, -1160,   -70,  -490,   -70}
    ,{  1650,  -260,   830,  1650,   830}
    }
   ,{{  1800,   130,   980,  1800,   980}
    ,{  1800,  -110,   980,  1800,   980}
    ,{  1800,   130,   980,  1800,   980}
    ,{  1800,  -110,   980,  1800,   980}
    ,{  1670,     0,   850,  1670,   850}
    }
   ,{{  1760,  -260,  1760,  1650,  1760}
    ,{  -160, -1260,  -160,  -590,  -160}
    ,{  1650,  -260,   830,  1650,   830}
    ,{  1760,  -580,  1760,    80,  1760}
    ,{  1650,  -260,   830,  1650,   830}
    }
   ,{{  1800,  -110,   980,  1800,   980}
    ,{  1800,  -110,   980,  1800,   980}
    ,{  1570,  -110,   740,  1570,   740}
    ,{  1800,  -110,   980,  1800,   980}
    ,{    40, -1050,    40,  -380,    40}
    }
   }
  ,{{{  1750,  1740,  1750,  1740,   360}
    ,{  1100,  1090,  1100,  1090,   360}
    ,{   970,   960,   970,   960,     0}
    ,{  1750,  1740,  1750,  1740,     0}
    ,{   840,   830,   840,   830,  -130}
    }
   ,{{  1100,  1090,  1100,  1090,   360}
    ,{  1100,  1090,  1100,  1090,   360}
    ,{   820,   810,   820,   810,  -150}
    ,{   170,   -80,   170,   -80, -1050}
    ,{   820,   810,   820,   810,  -150}
    }
   ,{{   970,   960,   970,   960,     0}
    ,{   970,   960,   970,   960,     0}
    ,{   970,   960,   970,   960,     0}
    ,{   970,   960,   970,   960,     0}
    ,{   840,   830,   840,   830,  -130}
    }
   ,{{  1750,  1740,  1750,  1740,  -150}
    ,{    70,  -180,    70,  -180, -1150}
    ,{   820,   810,   820,   810,  -150}
    ,{  1750,  1740,  1750,  1740,  -470}
    ,{   820,   810,   820,   810,  -150}
    }
   ,{{   970,   960,   970,   960,     0}
    ,{   970,   960,   970,   960,     0}
    ,{   740,   730,   740,   730,  -240}
    ,{   970,   960,   970,   960,     0}
    ,{    30,    20,    30,    20,  -940}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{  1350,   850,   720,  1350,   720}
    ,{  1300,   650,   520,  1300,   520}
    ,{  1350,   700,   570,  1350,   570}
    ,{  1300,   850,   720,  1300,   720}
    ,{  1250,   590,   460,  1250,   460}
    }
   ,{{  1160,   500,   400,  1160,   370}
    ,{  1160,   500,   370,  1160,   370}
    ,{   850,   190,    60,   850,    60}
    ,{   400,   290,   400,    10,   160}
    ,{   850,   190,    60,   850,    60}
    }
   ,{{  1300,   650,   520,  1300,   520}
    ,{  1300,   650,   520,  1300,   520}
    ,{  1290,   640,   510,  1290,   510}
    ,{  1300,   650,   520,  1300,   520}
    ,{  1250,   590,   460,  1250,   460}
    }
   ,{{   850,   850,   720,   850,   720}
    ,{   120,     0,   120,  -270,  -120}
    ,{   850,   190,    60,   850,    60}
    ,{   850,   850,   720,   570,   720}
    ,{   850,   190,    60,   850,    60}
    }
   ,{{  1350,   700,   570,  1350,   570}
    ,{  1300,   650,   520,  1300,   520}
    ,{  1350,   700,   570,  1350,   570}
    ,{  1300,   650,   520,  1300,   520}
    ,{   100,   100,  -270,  -420,  -270}
    }
   }
  ,{{{   850,   850,   720,  -760,   720}
    ,{   650,   650,   520, -1050,   520}
    ,{   700,   700,   570,  -760,   570}
    ,{   850,   850,   720, -1050,   720}
    ,{   590,   590,   460,  -870,   460}
    }
   ,{{   500,   500,   370, -1200,   370}
    ,{   500,   500,   370, -1200,   370}
    ,{   190,   190,    60, -1510,    60}
    ,{   290,   290,   160, -1410,   160}
    ,{   190,   190,    60, -1510,    60}
    }
   ,{{   650,   650,   520,  -820,   520}
    ,{   650,   650,   520, -1050,   520}
    ,{   640,   640,   510,  -820,   510}
    ,{   650,   650,   520, -1050,   520}
    ,{   590,   590,   460,  -870,   460}
    }
   ,{{   850,   850,   720, -1510,   720}
    ,{     0,     0,  -120, -1700,  -120}
    ,{   190,   190,    60, -1510,    60}
    ,{   850,   850,   720, -2110,   720}
    ,{   190,   190,    60, -1510,    60}
    }
   ,{{   700,   700,   570,  -760,   570}
    ,{   650,   650,   520, -1050,   520}
    ,{   700,   700,   570,  -760,   570}
    ,{   650,   650,   520, -1050,   520}
    ,{   100,   100,  -270, -1840,  -270}
    }
   }
  ,{{{   720,   570,   720,   570,   280}
    ,{   520,   370,   520,   370,    80}
    ,{   570,   420,   570,   420,   130}
    ,{   720,   570,   720,   570,   280}
    ,{   460,   310,   460,   310,    20}
    }
   ,{{   400,   220,   400,   220,   -40}
    ,{   370,   220,   370,   220,   -60}
    ,{    60,   -80,    60,   -80,  -370}
    ,{   400,    10,   400,    10,   -40}
    ,{    60,   -80,    60,   -80,  -370}
    }
   ,{{   520,   370,   520,   370,    80}
    ,{   520,   370,   520,   370,    80}
    ,{   510,   360,   510,   360,    70}
    ,{   520,   370,   520,   370,    80}
    ,{   460,   310,   460,   310,    20}
    }
   ,{{   720,   570,   720,   570,   280}
    ,{   120,  -270,   120,  -270,  -320}
    ,{    60,   -80,    60,   -80,  -370}
    ,{   720,   570,   720,   570,   280}
    ,{    60,   -80,    60,   -80,  -370}
    }
   ,{{   570,   420,   570,   420,   130}
    ,{   520,   370,   520,   370,    80}
    ,{   570,   420,   570,   420,   130}
    ,{   520,   370,   520,   370,    80}
    ,{  -270,  -420,  -270,  -420,  -710}
    }
   }
  ,{{{  1350,  -460,   720,  1350,   720}
    ,{  1300,  -750,   520,  1300,   520}
    ,{  1350,  -460,   570,  1350,   570}
    ,{  1300,  -750,   720,  1300,   720}
    ,{  1250,  -570,   460,  1250,   460}
    }
   ,{{  1160,  -900,   370,  1160,   370}
    ,{  1160,  -900,   370,  1160,   370}
    ,{   850, -1210,    60,   850,    60}
    ,{   160, -1110,   160,  -310,   160}
    ,{   850, -1210,    60,   850,    60}
    }
   ,{{  1300,  -520,   520,  1300,   520}
    ,{  1300,  -750,   520,  1300,   520}
    ,{  1290,  -520,   510,  1290,   510}
    ,{  1300,  -750,   520,  1300,   520}
    ,{  1250,  -570,   460,  1250,   460}
    }
   ,{{   850, -1210,   720,   850,   720}
    ,{  -120, -1400,  -120,  -590,  -120}
    ,{   850, -1210,    60,   850,    60}
    ,{   720, -1810,   720, -1000,   720}
    ,{   850, -1210,    60,   850,    60}
    }
   ,{{  1350,  -460,   570,  1350,   570}
    ,{  1300,  -750,   520,  1300,   520}
    ,{  1350,  -460,   570,  1350,   570}
    ,{  1300,  -750,   520,  1300,   520}
    ,{  -270, -1540,  -270,  -740,  -270}
    }
   }
  ,{{{   590,   570,   590,   570,  -320}
    ,{   390,   370,   390,   370,  -320}
    ,{   440,   420,   440,   420,  -360}
    ,{   590,   570,   590,   570,  -420}
    ,{   330,   310,   330,   310,  -470}
    }
   ,{{   270,   220,   270,   220,  -320}
    ,{   240,   220,   240,   220,  -320}
    ,{   -60,   -80,   -60,   -80,  -870}
    ,{   270,    10,   270,    10,  -780}
    ,{   -60,   -80,   -60,   -80,  -870}
    }
   ,{{   390,   370,   390,   370,  -420}
    ,{   390,   370,   390,   370,  -420}
    ,{   380,   360,   380,   360,  -420}
    ,{   390,   370,   390,   370,  -420}
    ,{   330,   310,   330,   310,  -470}
    }
   ,{{   590,   570,   590,   570,  -870}
    ,{   -10,  -270,   -10,  -270, -1060}
    ,{   -60,   -80,   -60,   -80,  -870}
    ,{   590,   570,   590,   570, -1470}
    ,{   -60,   -80,   -60,   -80,  -870}
    }
   ,{{   440,   420,   440,   420,  -360}
    ,{   390,   370,   390,   370,  -420}
    ,{   440,   420,   440,   420,  -360}
    ,{   390,   370,   390,   370,  -420}
    ,{  -400,  -420,  -400,  -420, -1210}
    }
   }
  }
 ,{{{{  1320,   850,   720,  1320,   720}
    ,{  1320,   670,   540,  1320,   540}
    ,{   870,   220,    90,   870,    90}
    ,{   960,   850,   720,   960,   720}
    ,{   870,   250,    90,   870,    90}
    }
   ,{{  1320,   670,   540,  1320,   540}
    ,{  1320,   670,   540,  1320,   540}
    ,{   870,   220,    90,   870,    90}
    ,{  -410,  -520,  -410,  -800,  -650}
    ,{   870,   220,    90,   870,    90}
    }
   ,{{   960,   300,   170,   960,   170}
    ,{   960,   300,   170,   960,   170}
    ,{   650,     0,  -130,   650,  -130}
    ,{   960,   300,   170,   960,   170}
    ,{   650,     0,  -130,   650,  -130}
    }
   ,{{   870,   850,   720,   870,   720}
    ,{    70,   -40,    70,  -320,  -170}
    ,{   870,   220,    90,   870,    90}
    ,{   850,   850,   720,   570,   720}
    ,{   870,   220,    90,   870,    90}
    }
   ,{{   960,   300,   170,   960,   170}
    ,{   960,   300,   170,   960,   170}
    ,{   340,  -310,  -440,   340,  -440}
    ,{   960,   300,   170,   960,   170}
    ,{   250,   250,  -110,  -260,  -110}
    }
   }
  ,{{{   850,   850,   720, -1030,   720}
    ,{   670,   670,   540, -1030,   540}
    ,{   220,   220,    90, -1460,    90}
    ,{   850,   850,   720, -1400,   720}
    ,{   250,   250,    90, -1460,    90}
    }
   ,{{   670,   670,   540, -1030,   540}
    ,{   670,   670,   540, -1030,   540}
    ,{   220,   220,    90, -1480,    90}
    ,{  -520,  -520,  -650, -2220,  -650}
    ,{   220,   220,    90, -1480,    90}
    }
   ,{{   300,   300,   170, -1400,   170}
    ,{   300,   300,   170, -1400,   170}
    ,{     0,     0,  -130, -1460,  -130}
    ,{   300,   300,   170, -1400,   170}
    ,{     0,     0,  -130, -1460,  -130}
    }
   ,{{   850,   850,   720, -1480,   720}
    ,{   -40,   -40,  -170, -1750,  -170}
    ,{   220,   220,    90, -1480,    90}
    ,{   850,   850,   720, -2110,   720}
    ,{   220,   220,    90, -1480,    90}
    }
   ,{{   300,   300,   170, -1400,   170}
    ,{   300,   300,   170, -1400,   170}
    ,{  -310,  -310,  -440, -1770,  -440}
    ,{   300,   300,   170, -1400,   170}
    ,{   250,   250,  -110, -1690,  -110}
    }
   }
  ,{{{   720,   570,   720,   570,   280}
    ,{   540,   390,   540,   390,   100}
    ,{    90,   -60,    90,   -60,  -350}
    ,{   720,   570,   720,   570,   280}
    ,{    90,   -60,    90,   -60,  -350}
    }
   ,{{   540,   390,   540,   390,   100}
    ,{   540,   390,   540,   390,   100}
    ,{    90,   -60,    90,   -60,  -350}
    ,{  -410,  -800,  -410,  -800,  -850}
    ,{    90,   -60,    90,   -60,  -350}
    }
   ,{{   170,    20,   170,    20,  -260}
    ,{   170,    20,   170,    20,  -260}
    ,{  -130,  -280,  -130,  -280,  -570}
    ,{   170,    20,   170,    20,  -260}
    ,{  -130,  -280,  -130,  -280,  -570}
    }
   ,{{   720,   570,   720,   570,   280}
    ,{    70,  -320,    70,  -320,  -370}
    ,{    90,   -60,    90,   -60,  -350}
    ,{   720,   570,   720,   570,   280}
    ,{    90,   -60,    90,   -60,  -350}
    }
   ,{{   170,    20,   170,    20,  -260}
    ,{   170,    20,   170,    20,  -260}
    ,{  -440,  -590,  -440,  -590,  -880}
    ,{   170,    20,   170,    20,  -260}
    ,{  -110,  -260,  -110,  -260,  -550}
    }
   }
  ,{{{  1320,  -730,   720,  1320,   720}
    ,{  1320,  -730,   540,  1320,   540}
    ,{   870, -1160,    90,   870,    90}
    ,{   960, -1100,   720,   960,   720}
    ,{   870, -1160,    90,   870,    90}
    }
   ,{{  1320,  -730,   540,  1320,   540}
    ,{  1320,  -730,   540,  1320,   540}
    ,{   870, -1180,    90,   870,    90}
    ,{  -650, -1920,  -650, -1120,  -650}
    ,{   870, -1180,    90,   870,    90}
    }
   ,{{   960, -1100,   170,   960,   170}
    ,{   960, -1100,   170,   960,   170}
    ,{   650, -1160,  -130,   650,  -130}
    ,{   960, -1100,   170,   960,   170}
    ,{   650, -1160,  -130,   650,  -130}
    }
   ,{{   870, -1180,   720,   870,   720}
    ,{  -170, -1450,  -170,  -640,  -170}
    ,{   870, -1180,    90,   870,    90}
    ,{   720, -1810,   720, -1000,   720}
    ,{   870, -1180,    90,   870,    90}
    }
   ,{{   960, -1100,   170,   960,   170}
    ,{   960, -1100,   170,   960,   170}
    ,{   340, -1470,  -440,   340,  -440}
    ,{   960, -1100,   170,   960,   170}
    ,{  -110, -1390,  -110,  -580,  -110}
    }
   }
  ,{{{   590,   570,   590,   570,  -160}
    ,{   410,   390,   410,   390,  -160}
    ,{   -40,   -60,   -40,   -60,  -850}
    ,{   590,   570,   590,   570,  -760}
    ,{   -40,   -60,   -40,   -60,  -850}
    }
   ,{{   410,   390,   410,   390,  -160}
    ,{   410,   390,   410,   390,  -160}
    ,{   -40,   -60,   -40,   -60,  -850}
    ,{  -540,  -800,  -540,  -800, -1590}
    ,{   -40,   -60,   -40,   -60,  -850}
    }
   ,{{    40,    20,    40,    20,  -760}
    ,{    40,    20,    40,    20,  -760}
    ,{  -260,  -280,  -260,  -280, -1070}
    ,{    40,    20,    40,    20,  -760}
    ,{  -260,  -280,  -260,  -280, -1070}
    }
   ,{{   590,   570,   590,   570,  -850}
    ,{   -60,  -320,   -60,  -320, -1110}
    ,{   -40,   -60,   -40,   -60,  -850}
    ,{   590,   570,   590,   570, -1470}
    ,{   -40,   -60,   -40,   -60,  -850}
    }
   ,{{    40,    20,    40,    20,  -760}
    ,{    40,    20,    40,    20,  -760}
    ,{  -570,  -590,  -570,  -590, -1380}
    ,{    40,    20,    40,    20,  -760}
    ,{  -240,  -260,  -240,  -260, -1050}
    }
   }
  }
 ,{{{{  1010,  1010,   880,   730,   880}
    ,{   410,   -70,    40,   410,  -200}
    ,{   410,  -240,  -370,   410,  -370}
    ,{  1010,  1010,   880,   730,   880}
    ,{   410,     0,  -370,   410,  -370}
    }
   ,{{   410,  -240,  -150,   410,  -370}
    ,{   230,  -420,  -550,   230,  -550}
    ,{   410,  -240,  -370,   410,  -370}
    ,{  -150,  -260,  -150,  -540,  -390}
    ,{   410,  -240,  -370,   410,  -370}
    }
   ,{{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    }
   ,{{  1010,  1010,   880,   730,   880}
    ,{    40,   -70,    40,  -350,  -200}
    ,{   410,  -240,  -370,   410,  -370}
    ,{  1010,  1010,   880,   730,   880}
    ,{   410,  -240,  -370,   410,  -370}
    }
   ,{{   410,     0,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{     0,     0,  -370,  -520,  -370}
    }
   }
  ,{{{  1010,  1010,   880, -1710,   880}
    ,{   -70,   -70,  -200, -1770,  -200}
    ,{  -240,  -240,  -370, -1710,  -370}
    ,{  1010,  1010,   880, -1950,   880}
    ,{     0,     0,  -370, -1710,  -370}
    }
   ,{{  -240,  -240,  -370, -1950,  -370}
    ,{  -420,  -420,  -550, -2130,  -550}
    ,{  -240,  -240,  -370, -1950,  -370}
    ,{  -260,  -260,  -390, -1960,  -390}
    ,{  -240,  -240,  -370, -1950,  -370}
    }
   ,{{  -240,  -240,  -370, -1710,  -370}
    ,{  -240,  -240,  -370, -1950,  -370}
    ,{  -240,  -240,  -370, -1710,  -370}
    ,{  -240,  -240,  -370, -1950,  -370}
    ,{  -240,  -240,  -370, -1710,  -370}
    }
   ,{{  1010,  1010,   880, -1770,   880}
    ,{   -70,   -70,  -200, -1770,  -200}
    ,{  -240,  -240,  -370, -1950,  -370}
    ,{  1010,  1010,   880, -1950,   880}
    ,{  -240,  -240,  -370, -1950,  -370}
    }
   ,{{     0,     0,  -370, -1710,  -370}
    ,{  -240,  -240,  -370, -1950,  -370}
    ,{  -240,  -240,  -370, -1710,  -370}
    ,{  -240,  -240,  -370, -1950,  -370}
    ,{     0,     0,  -370, -1950,  -370}
    }
   }
  ,{{{   880,   730,   880,   730,   440}
    ,{    40,  -350,    40,  -350,  -400}
    ,{  -370,  -520,  -370,  -520,  -810}
    ,{   880,   730,   880,   730,   440}
    ,{  -370,  -520,  -370,  -520,  -810}
    }
   ,{{  -150,  -520,  -150,  -520,  -590}
    ,{  -550,  -700,  -550,  -700,  -990}
    ,{  -370,  -520,  -370,  -520,  -810}
    ,{  -150,  -540,  -150,  -540,  -590}
    ,{  -370,  -520,  -370,  -520,  -810}
    }
   ,{{  -370,  -520,  -370,  -520,  -810}
    ,{  -370,  -520,  -370,  -520,  -810}
    ,{  -370,  -520,  -370,  -520,  -810}
    ,{  -370,  -520,  -370,  -520,  -810}
    ,{  -370,  -520,  -370,  -520,  -810}
    }
   ,{{   880,   730,   880,   730,   440}
    ,{    40,  -350,    40,  -350,  -400}
    ,{  -370,  -520,  -370,  -520,  -810}
    ,{   880,   730,   880,   730,   440}
    ,{  -370,  -520,  -370,  -520,  -810}
    }
   ,{{  -370,  -520,  -370,  -520,  -810}
    ,{  -370,  -520,  -370,  -520,  -810}
    ,{  -370,  -520,  -370,  -520,  -810}
    ,{  -370,  -520,  -370,  -520,  -810}
    ,{  -370,  -520,  -370,  -520,  -810}
    }
   }
  ,{{{   880, -1410,   880,   410,   880}
    ,{   410, -1470,  -200,   410,  -200}
    ,{   410, -1410,  -370,   410,  -370}
    ,{   880, -1650,   880,   410,   880}
    ,{   410, -1410,  -370,   410,  -370}
    }
   ,{{   410, -1650,  -370,   410,  -370}
    ,{   230, -1830,  -550,   230,  -550}
    ,{   410, -1650,  -370,   410,  -370}
    ,{  -390, -1660,  -390,  -860,  -390}
    ,{   410, -1650,  -370,   410,  -370}
    }
   ,{{   410, -1410,  -370,   410,  -370}
    ,{   410, -1650,  -370,   410,  -370}
    ,{   410, -1410,  -370,   410,  -370}
    ,{   410, -1650,  -370,   410,  -370}
    ,{   410, -1410,  -370,   410,  -370}
    }
   ,{{   880, -1470,   880,   410,   880}
    ,{  -200, -1470,  -200,  -670,  -200}
    ,{   410, -1650,  -370,   410,  -370}
    ,{   880, -1650,   880,  -840,   880}
    ,{   410, -1650,  -370,   410,  -370}
    }
   ,{{   410, -1410,  -370,   410,  -370}
    ,{   410, -1650,  -370,   410,  -370}
    ,{   410, -1410,  -370,   410,  -370}
    ,{   410, -1650,  -370,   410,  -370}
    ,{  -370, -1650,  -370,  -840,  -370}
    }
   }
  ,{{{   750,   730,   750,   730, -1140}
    ,{   -90,  -350,   -90,  -350, -1140}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{   750,   730,   750,   730, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    }
   ,{{  -280,  -520,  -280,  -520, -1250}
    ,{  -680,  -700,  -680,  -700, -1250}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -280,  -540,  -280,  -540, -1330}
    ,{  -500,  -520,  -500,  -520, -1310}
    }
   ,{{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    }
   ,{{   750,   730,   750,   730, -1140}
    ,{   -90,  -350,   -90,  -350, -1140}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{   750,   730,   750,   730, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    }
   ,{{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    }
   }
  }
 ,{{{{  1560,  1560,  1430,  1470,  1430}
    ,{  1470,   820,   690,  1470,   690}
    ,{   960,   310,   180,   960,   180}
    ,{  1560,  1560,  1430,  1280,  1430}
    ,{   960,   550,   180,   960,   180}
    }
   ,{{  1470,   820,   690,  1470,   690}
    ,{  1470,   820,   690,  1470,   690}
    ,{   960,   310,   180,   960,   180}
    ,{    80,   -30,    80,  -310,  -160}
    ,{   960,   310,   180,   960,   180}
    }
   ,{{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    }
   ,{{  1560,  1560,  1430,  1280,  1430}
    ,{   -90,  -200,   -90,  -480,  -330}
    ,{   960,   310,   180,   960,   180}
    ,{  1560,  1560,  1430,  1280,  1430}
    ,{   960,   310,   180,   960,   180}
    }
   ,{{   960,   550,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   550,   550,   180,    30,   180}
    }
   }
  ,{{{  1560,  1560,  1430,  -880,  1430}
    ,{   820,   820,   690,  -880,   690}
    ,{   310,   310,   180, -1150,   180}
    ,{  1560,  1560,  1430, -1390,  1430}
    ,{   550,   550,   180, -1150,   180}
    }
   ,{{   820,   820,   690,  -880,   690}
    ,{   820,   820,   690,  -880,   690}
    ,{   310,   310,   180, -1390,   180}
    ,{   -30,   -30,  -160, -1730,  -160}
    ,{   310,   310,   180, -1390,   180}
    }
   ,{{   310,   310,   180, -1150,   180}
    ,{   310,   310,   180, -1390,   180}
    ,{   310,   310,   180, -1150,   180}
    ,{   310,   310,   180, -1390,   180}
    ,{   310,   310,   180, -1150,   180}
    }
   ,{{  1560,  1560,  1430, -1390,  1430}
    ,{  -200,  -200,  -330, -1900,  -330}
    ,{   310,   310,   180, -1390,   180}
    ,{  1560,  1560,  1430, -1390,  1430}
    ,{   310,   310,   180, -1390,   180}
    }
   ,{{   550,   550,   180, -1150,   180}
    ,{   310,   310,   180, -1390,   180}
    ,{   310,   310,   180, -1150,   180}
    ,{   310,   310,   180, -1390,   180}
    ,{   550,   550,   180, -1390,   180}
    }
   }
  ,{{{  1430,  1280,  1430,  1280,   990}
    ,{   690,   540,   690,   540,   250}
    ,{   180,    30,   180,    30,  -260}
    ,{  1430,  1280,  1430,  1280,   990}
    ,{   180,    30,   180,    30,  -260}
    }
   ,{{   690,   540,   690,   540,   250}
    ,{   690,   540,   690,   540,   250}
    ,{   180,    30,   180,    30,  -260}
    ,{    80,  -310,    80,  -310,  -360}
    ,{   180,    30,   180,    30,  -260}
    }
   ,{{   180,    30,   180,    30,  -260}
    ,{   180,    30,   180,    30,  -260}
    ,{   180,    30,   180,    30,  -260}
    ,{   180,    30,   180,    30,  -260}
    ,{   180,    30,   180,    30,  -260}
    }
   ,{{  1430,  1280,  1430,  1280,   990}
    ,{   -90,  -480,   -90,  -480,  -530}
    ,{   180,    30,   180,    30,  -260}
    ,{  1430,  1280,  1430,  1280,   990}
    ,{   180,    30,   180,    30,  -260}
    }
   ,{{   180,    30,   180,    30,  -260}
    ,{   180,    30,   180,    30,  -260}
    ,{   180,    30,   180,    30,  -260}
    ,{   180,    30,   180,    30,  -260}
    ,{   180,    30,   180,    30,  -260}
    }
   }
  ,{{{  1470,  -580,  1430,  1470,  1430}
    ,{  1470,  -580,   690,  1470,   690}
    ,{   960,  -850,   180,   960,   180}
    ,{  1430, -1090,  1430,   960,  1430}
    ,{   960,  -850,   180,   960,   180}
    }
   ,{{  1470,  -580,   690,  1470,   690}
    ,{  1470,  -580,   690,  1470,   690}
    ,{   960, -1090,   180,   960,   180}
    ,{  -160, -1430,  -160,  -630,  -160}
    ,{   960, -1090,   180,   960,   180}
    }
   ,{{   960,  -850,   180,   960,   180}
    ,{   960, -1090,   180,   960,   180}
    ,{   960,  -850,   180,   960,   180}
    ,{   960, -1090,   180,   960,   180}
    ,{   960,  -850,   180,   960,   180}
    }
   ,{{  1430, -1090,  1430,   960,  1430}
    ,{  -330, -1600,  -330,  -800,  -330}
    ,{   960, -1090,   180,   960,   180}
    ,{  1430, -1090,  1430,  -290,  1430}
    ,{   960, -1090,   180,   960,   180}
    }
   ,{{   960,  -850,   180,   960,   180}
    ,{   960, -1090,   180,   960,   180}
    ,{   960,  -850,   180,   960,   180}
    ,{   960, -1090,   180,   960,   180}
    ,{   180, -1090,   180,  -290,   180}
    }
   }
  ,{{{  1300,  1280,  1300,  1280,   -10}
    ,{   560,   540,   560,   540,   -10}
    ,{    50,    30,    50,    30,  -760}
    ,{  1300,  1280,  1300,  1280,  -760}
    ,{    50,    30,    50,    30,  -760}
    }
   ,{{   560,   540,   560,   540,   -10}
    ,{   560,   540,   560,   540,   -10}
    ,{    50,    30,    50,    30,  -760}
    ,{   -50,  -310,   -50,  -310, -1100}
    ,{    50,    30,    50,    30,  -760}
    }
   ,{{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    }
   ,{{  1300,  1280,  1300,  1280,  -760}
    ,{  -220,  -480,  -220,  -480, -1270}
    ,{    50,    30,    50,    30,  -760}
    ,{  1300,  1280,  1300,  1280,  -760}
    ,{    50,    30,    50,    30,  -760}
    }
   ,{{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    }
   }
  }
 ,{{{{  2050,  1930,  1800,  2050,  1800}
    ,{  2050,  1400,  1270,  2050,  1270}
    ,{  1750,  1100,   970,  1750,   970}
    ,{  1930,  1930,  1800,  1760,  1800}
    ,{  1750,  1100,   970,  1750,   970}
    }
   ,{{  2050,  1400,  1270,  2050,  1270}
    ,{  2050,  1400,  1270,  2050,  1270}
    ,{  1740,  1090,   960,  1740,   960}
    ,{   130,    10,   130,  -260,  -110}
    ,{  1740,  1090,   960,  1740,   960}
    }
   ,{{  1760,  1110,   980,  1760,   980}
    ,{  1760,  1110,   980,  1760,   980}
    ,{  1750,  1100,   970,  1750,   970}
    ,{  1760,  1110,   980,  1760,   980}
    ,{  1750,  1100,   970,  1750,   970}
    }
   ,{{  1930,  1930,  1800,  1740,  1800}
    ,{   300,   190,   300,   -80,    60}
    ,{  1740,  1090,   960,  1740,   960}
    ,{  1930,  1930,  1800,  1650,  1800}
    ,{  1740,  1090,   960,  1740,   960}
    }
   ,{{  1760,  1110,   980,  1760,   980}
    ,{  1760,  1110,   980,  1760,   980}
    ,{  1750,  1100,   970,  1750,   970}
    ,{  1760,  1110,   980,  1760,   980}
    ,{   360,   360,     0,  -150,     0}
    }
   }
  ,{{{  1930,  1930,  1800,  -300,  1800}
    ,{  1400,  1400,  1270,  -300,  1270}
    ,{  1100,  1100,   970,  -360,   970}
    ,{  1930,  1930,  1800,  -590,  1800}
    ,{  1100,  1100,   970,  -360,   970}
    }
   ,{{  1400,  1400,  1270,  -300,  1270}
    ,{  1400,  1400,  1270,  -300,  1270}
    ,{  1090,  1090,   960,  -610,   960}
    ,{    10,    10,  -110, -1690,  -110}
    ,{  1090,  1090,   960,  -610,   960}
    }
   ,{{  1110,  1110,   980,  -360,   980}
    ,{  1110,  1110,   980,  -590,   980}
    ,{  1100,  1100,   970,  -360,   970}
    ,{  1110,  1110,   980,  -590,   980}
    ,{  1100,  1100,   970,  -360,   970}
    }
   ,{{  1930,  1930,  1800,  -610,  1800}
    ,{   190,   190,    60, -1510,    60}
    ,{  1090,  1090,   960,  -610,   960}
    ,{  1930,  1930,  1800, -1020,  1800}
    ,{  1090,  1090,   960,  -610,   960}
    }
   ,{{  1110,  1110,   980,  -360,   980}
    ,{  1110,  1110,   980,  -590,   980}
    ,{  1100,  1100,   970,  -360,   970}
    ,{  1110,  1110,   980,  -590,   980}
    ,{   360,   360,     0, -1580,     0}
    }
   }
  ,{{{  1800,  1650,  1800,  1650,  1360}
    ,{  1270,  1120,  1270,  1120,   830}
    ,{   970,   820,   970,   820,   530}
    ,{  1800,  1650,  1800,  1650,  1360}
    ,{   970,   820,   970,   820,   530}
    }
   ,{{  1270,  1120,  1270,  1120,   830}
    ,{  1270,  1120,  1270,  1120,   830}
    ,{   960,   810,   960,   810,   520}
    ,{   130,  -260,   130,  -260,  -310}
    ,{   960,   810,   960,   810,   520}
    }
   ,{{   980,   830,   980,   830,   540}
    ,{   980,   830,   980,   830,   540}
    ,{   970,   820,   970,   820,   530}
    ,{   980,   830,   980,   830,   540}
    ,{   970,   820,   970,   820,   530}
    }
   ,{{  1800,  1650,  1800,  1650,  1360}
    ,{   300,   -80,   300,   -80,  -130}
    ,{   960,   810,   960,   810,   520}
    ,{  1800,  1650,  1800,  1650,  1360}
    ,{   960,   810,   960,   810,   520}
    }
   ,{{   980,   830,   980,   830,   540}
    ,{   980,   830,   980,   830,   540}
    ,{   970,   820,   970,   820,   530}
    ,{   980,   830,   980,   830,   540}
    ,{     0,  -150,     0,  -150,  -440}
    }
   }
  ,{{{  2050,     0,  1800,  2050,  1800}
    ,{  2050,     0,  1270,  2050,  1270}
    ,{  1750,   -60,   970,  1750,   970}
    ,{  1800,  -290,  1800,  1760,  1800}
    ,{  1750,   -60,   970,  1750,   970}
    }
   ,{{  2050,     0,  1270,  2050,  1270}
    ,{  2050,     0,  1270,  2050,  1270}
    ,{  1740,  -310,   960,  1740,   960}
    ,{  -110, -1390,  -110,  -580,  -110}
    ,{  1740,  -310,   960,  1740,   960}
    }
   ,{{  1760,   -60,   980,  1760,   980}
    ,{  1760,  -290,   980,  1760,   980}
    ,{  1750,   -60,   970,  1750,   970}
    ,{  1760,  -290,   980,  1760,   980}
    ,{  1750,   -60,   970,  1750,   970}
    }
   ,{{  1800,  -310,  1800,  1740,  1800}
    ,{    60, -1210,    60,  -400,    60}
    ,{  1740,  -310,   960,  1740,   960}
    ,{  1800,  -720,  1800,    80,  1800}
    ,{  1740,  -310,   960,  1740,   960}
    }
   ,{{  1760,   -60,   980,  1760,   980}
    ,{  1760,  -290,   980,  1760,   980}
    ,{  1750,   -60,   970,  1750,   970}
    ,{  1760,  -290,   980,  1760,   980}
    ,{     0, -1280,     0,  -470,     0}
    }
   }
  ,{{{  1670,  1650,  1670,  1650,   570}
    ,{  1140,  1120,  1140,  1120,   570}
    ,{   840,   820,   840,   820,    30}
    ,{  1670,  1650,  1670,  1650,    40}
    ,{   840,   820,   840,   820,    30}
    }
   ,{{  1140,  1120,  1140,  1120,   570}
    ,{  1140,  1120,  1140,  1120,   570}
    ,{   830,   810,   830,   810,    20}
    ,{     0,  -260,     0,  -260, -1050}
    ,{   830,   810,   830,   810,    20}
    }
   ,{{   850,   830,   850,   830,    40}
    ,{   850,   830,   850,   830,    40}
    ,{   840,   820,   840,   820,    30}
    ,{   850,   830,   850,   830,    40}
    ,{   840,   820,   840,   820,    30}
    }
   ,{{  1670,  1650,  1670,  1650,    20}
    ,{   180,   -80,   180,   -80,  -870}
    ,{   830,   810,   830,   810,    20}
    ,{  1670,  1650,  1670,  1650,  -380}
    ,{   830,   810,   830,   810,    20}
    }
   ,{{   850,   830,   850,   830,    40}
    ,{   850,   830,   850,   830,    40}
    ,{   840,   820,   840,   820,    30}
    ,{   850,   830,   850,   830,    40}
    ,{  -130,  -150,  -130,  -150,  -940}
    }
   }
  }
 ,{{{{  2120,  2120,  1990,  2120,  1990}
    ,{  2120,  1470,  1340,  2120,  1340}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  2120,  2120,  1990,  1990,  1990}
    ,{  1860,  1210,  1080,  1860,  1080}
    }
   ,{{  2120,  1470,  1340,  2120,  1340}
    ,{  2120,  1470,  1340,  2120,  1340}
    ,{  1840,  1190,  1060,  1840,  1060}
    ,{   180,    60,   180,  -210,   -60}
    ,{  1840,  1190,  1060,  1840,  1060}
    }
   ,{{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1860,  1210,  1080,  1860,  1080}
    }
   ,{{  2120,  2120,  1990,  1840,  1990}
    ,{  -120,  -230,  -120,  -510,  -360}
    ,{  1840,  1190,  1060,  1840,  1060}
    ,{  2120,  2120,  1990,  1840,  1990}
    ,{  1840,  1190,  1060,  1840,  1060}
    }
   ,{{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1550,   900,   770,  1550,   770}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{   640,   640,   270,   120,   270}
    }
   }
  ,{{{  2120,  2120,  1990,  -120,  1990}
    ,{  1470,  1470,  1340,  -230,  1340}
    ,{  1340,  1340,  1210,  -120,  1210}
    ,{  2120,  2120,  1990,  -360,  1990}
    ,{  1210,  1210,  1080,  -250,  1080}
    }
   ,{{  1470,  1470,  1340,  -230,  1340}
    ,{  1470,  1470,  1340,  -230,  1340}
    ,{  1190,  1190,  1060,  -510,  1060}
    ,{    60,    60,   -60, -1640,   -60}
    ,{  1190,  1190,  1060,  -510,  1060}
    }
   ,{{  1340,  1340,  1210,  -120,  1210}
    ,{  1340,  1340,  1210,  -360,  1210}
    ,{  1340,  1340,  1210,  -120,  1210}
    ,{  1340,  1340,  1210,  -360,  1210}
    ,{  1210,  1210,  1080,  -250,  1080}
    }
   ,{{  2120,  2120,  1990,  -510,  1990}
    ,{  -230,  -230,  -360, -1940,  -360}
    ,{  1190,  1190,  1060,  -510,  1060}
    ,{  2120,  2120,  1990,  -830,  1990}
    ,{  1190,  1190,  1060,  -510,  1060}
    }
   ,{{  1340,  1340,  1210,  -360,  1210}
    ,{  1340,  1340,  1210,  -360,  1210}
    ,{   900,   900,   770,  -560,   770}
    ,{  1340,  1340,  1210,  -360,  1210}
    ,{   640,   640,   270, -1300,   270}
    }
   }
  ,{{{  1990,  1840,  1990,  1840,  1550}
    ,{  1340,  1190,  1340,  1190,   900}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{  1990,  1840,  1990,  1840,  1550}
    ,{  1080,   930,  1080,   930,   640}
    }
   ,{{  1340,  1190,  1340,  1190,   900}
    ,{  1340,  1190,  1340,  1190,   900}
    ,{  1060,   910,  1060,   910,   620}
    ,{   180,  -210,   180,  -210,  -260}
    ,{  1060,   910,  1060,   910,   620}
    }
   ,{{  1210,  1060,  1210,  1060,   770}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{  1080,   930,  1080,   930,   640}
    }
   ,{{  1990,  1840,  1990,  1840,  1550}
    ,{  -120,  -510,  -120,  -510,  -560}
    ,{  1060,   910,  1060,   910,   620}
    ,{  1990,  1840,  1990,  1840,  1550}
    ,{  1060,   910,  1060,   910,   620}
    }
   ,{{  1210,  1060,  1210,  1060,   770}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{   770,   620,   770,   620,   330}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{   270,   120,   270,   120,  -170}
    }
   }
  ,{{{  2120,   180,  1990,  2120,  1990}
    ,{  2120,    60,  1340,  2120,  1340}
    ,{  1990,   180,  1210,  1990,  1210}
    ,{  1990,   -60,  1990,  1990,  1990}
    ,{  1860,    50,  1080,  1860,  1080}
    }
   ,{{  2120,    60,  1340,  2120,  1340}
    ,{  2120,    60,  1340,  2120,  1340}
    ,{  1840,  -210,  1060,  1840,  1060}
    ,{   -60, -1340,   -60,  -530,   -60}
    ,{  1840,  -210,  1060,  1840,  1060}
    }
   ,{{  1990,   180,  1210,  1990,  1210}
    ,{  1990,   -60,  1210,  1990,  1210}
    ,{  1990,   180,  1210,  1990,  1210}
    ,{  1990,   -60,  1210,  1990,  1210}
    ,{  1860,    50,  1080,  1860,  1080}
    }
   ,{{  1990,  -210,  1990,  1840,  1990}
    ,{  -360, -1640,  -360,  -830,  -360}
    ,{  1840,  -210,  1060,  1840,  1060}
    ,{  1990,  -530,  1990,   270,  1990}
    ,{  1840,  -210,  1060,  1840,  1060}
    }
   ,{{  1990,   -60,  1210,  1990,  1210}
    ,{  1990,   -60,  1210,  1990,  1210}
    ,{  1550,  -260,   770,  1550,   770}
    ,{  1990,   -60,  1210,  1990,  1210}
    ,{   270, -1000,   270,  -200,   270}
    }
   }
  ,{{{  1860,  1840,  1860,  1840,   640}
    ,{  1210,  1190,  1210,  1190,   640}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1860,  1840,  1860,  1840,   270}
    ,{   950,   930,   950,   930,   140}
    }
   ,{{  1210,  1190,  1210,  1190,   640}
    ,{  1210,  1190,  1210,  1190,   640}
    ,{   930,   910,   930,   910,   120}
    ,{    50,  -210,    50,  -210, -1000}
    ,{   930,   910,   930,   910,   120}
    }
   ,{{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   950,   930,   950,   930,   140}
    }
   ,{{  1860,  1840,  1860,  1840,   120}
    ,{  -250,  -510,  -250,  -510, -1300}
    ,{   930,   910,   930,   910,   120}
    ,{  1860,  1840,  1860,  1840,  -200}
    ,{   930,   910,   930,   910,   120}
    }
   ,{{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   640,   620,   640,   620,  -170}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   140,   120,   140,   120,  -670}
    }
   }
  }
 ,{{{{  2120,  2120,  1990,  2120,  1990}
    ,{  2120,  1470,  1340,  2120,  1340}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  2120,  2120,  1990,  1990,  1990}
    ,{  1860,  1210,  1080,  1860,  1080}
    }
   ,{{  2120,  1470,  1340,  2120,  1340}
    ,{  2120,  1470,  1340,  2120,  1340}
    ,{  1840,  1190,  1060,  1840,  1060}
    ,{   400,   290,   400,    10,   160}
    ,{  1840,  1190,  1060,  1840,  1060}
    }
   ,{{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1860,  1210,  1080,  1860,  1080}
    }
   ,{{  2120,  2120,  1990,  1840,  1990}
    ,{   300,   190,   300,   -80,    60}
    ,{  1840,  1190,  1060,  1840,  1060}
    ,{  2120,  2120,  1990,  1840,  1990}
    ,{  1840,  1190,  1060,  1840,  1060}
    }
   ,{{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1750,  1100,   970,  1750,   970}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{   640,   640,   270,   120,   270}
    }
   }
  ,{{{  2120,  2120,  1990,  -120,  1990}
    ,{  1470,  1470,  1340,  -230,  1340}
    ,{  1340,  1340,  1210,  -120,  1210}
    ,{  2120,  2120,  1990,  -360,  1990}
    ,{  1210,  1210,  1080,  -250,  1080}
    }
   ,{{  1470,  1470,  1340,  -230,  1340}
    ,{  1470,  1470,  1340,  -230,  1340}
    ,{  1190,  1190,  1060,  -510,  1060}
    ,{   290,   290,   160, -1410,   160}
    ,{  1190,  1190,  1060,  -510,  1060}
    }
   ,{{  1340,  1340,  1210,  -120,  1210}
    ,{  1340,  1340,  1210,  -360,  1210}
    ,{  1340,  1340,  1210,  -120,  1210}
    ,{  1340,  1340,  1210,  -360,  1210}
    ,{  1210,  1210,  1080,  -250,  1080}
    }
   ,{{  2120,  2120,  1990,  -510,  1990}
    ,{   190,   190,    60, -1510,    60}
    ,{  1190,  1190,  1060,  -510,  1060}
    ,{  2120,  2120,  1990,  -830,  1990}
    ,{  1190,  1190,  1060,  -510,  1060}
    }
   ,{{  1340,  1340,  1210,  -360,  1210}
    ,{  1340,  1340,  1210,  -360,  1210}
    ,{  1100,  1100,   970,  -360,   970}
    ,{  1340,  1340,  1210,  -360,  1210}
    ,{   640,   640,   270, -1300,   270}
    }
   }
  ,{{{  1990,  1840,  1990,  1840,  1550}
    ,{  1340,  1190,  1340,  1190,   900}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{  1990,  1840,  1990,  1840,  1550}
    ,{  1080,   930,  1080,   930,   640}
    }
   ,{{  1340,  1190,  1340,  1190,   900}
    ,{  1340,  1190,  1340,  1190,   900}
    ,{  1060,   910,  1060,   910,   620}
    ,{   400,    10,   400,    10,   -40}
    ,{  1060,   910,  1060,   910,   620}
    }
   ,{{  1210,  1060,  1210,  1060,   770}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{  1080,   930,  1080,   930,   640}
    }
   ,{{  1990,  1840,  1990,  1840,  1550}
    ,{   300,   -80,   300,   -80,  -130}
    ,{  1060,   910,  1060,   910,   620}
    ,{  1990,  1840,  1990,  1840,  1550}
    ,{  1060,   910,  1060,   910,   620}
    }
   ,{{  1210,  1060,  1210,  1060,   770}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{   970,   820,   970,   820,   530}
    ,{  1210,  1060,  1210,  1060,   770}
    ,{   270,   120,   270,   120,  -170}
    }
   }
  ,{{{  2120,   180,  1990,  2120,  1990}
    ,{  2120,    60,  1340,  2120,  1340}
    ,{  1990,   180,  1210,  1990,  1210}
    ,{  1990,   -60,  1990,  1990,  1990}
    ,{  1860,    50,  1080,  1860,  1080}
    }
   ,{{  2120,    60,  1340,  2120,  1340}
    ,{  2120,    60,  1340,  2120,  1340}
    ,{  1840,  -210,  1060,  1840,  1060}
    ,{   160, -1110,   160,  -310,   160}
    ,{  1840,  -210,  1060,  1840,  1060}
    }
   ,{{  1990,   180,  1210,  1990,  1210}
    ,{  1990,   -60,  1210,  1990,  1210}
    ,{  1990,   180,  1210,  1990,  1210}
    ,{  1990,   -60,  1210,  1990,  1210}
    ,{  1860,    50,  1080,  1860,  1080}
    }
   ,{{  1990,  -210,  1990,  1840,  1990}
    ,{    60, -1210,    60,  -400,    60}
    ,{  1840,  -210,  1060,  1840,  1060}
    ,{  1990,  -530,  1990,   270,  1990}
    ,{  1840,  -210,  1060,  1840,  1060}
    }
   ,{{  1990,   -60,  1210,  1990,  1210}
    ,{  1990,   -60,  1210,  1990,  1210}
    ,{  1750,   -60,   970,  1750,   970}
    ,{  1990,   -60,  1210,  1990,  1210}
    ,{   270, -1000,   270,  -200,   270}
    }
   }
  ,{{{  1860,  1840,  1860,  1840,   640}
    ,{  1210,  1190,  1210,  1190,   640}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1860,  1840,  1860,  1840,   270}
    ,{   950,   930,   950,   930,   140}
    }
   ,{{  1210,  1190,  1210,  1190,   640}
    ,{  1210,  1190,  1210,  1190,   640}
    ,{   930,   910,   930,   910,   120}
    ,{   270,    10,   270,    10,  -780}
    ,{   930,   910,   930,   910,   120}
    }
   ,{{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   950,   930,   950,   930,   140}
    }
   ,{{  1860,  1840,  1860,  1840,   120}
    ,{   180,   -80,   180,   -80,  -870}
    ,{   930,   910,   930,   910,   120}
    ,{  1860,  1840,  1860,  1840,  -200}
    ,{   930,   910,   930,   910,   120}
    }
   ,{{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   840,   820,   840,   820,    30}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   140,   120,   140,   120,  -670}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{  1350,   850,   720,  1350,   720}
    ,{  1300,   650,   540,  1300,   520}
    ,{  1350,   700,   570,  1350,   570}
    ,{  1300,   850,   720,  1300,   720}
    ,{  1250,   590,   460,  1250,   460}
    }
   ,{{  1160,   500,   400,  1160,   370}
    ,{  1160,   500,   370,  1160,   370}
    ,{   850,   190,    60,   850,    60}
    ,{   400,   290,   400,    10,   170}
    ,{   850,   190,    60,   850,    60}
    }
   ,{{  1300,   650,   520,  1300,   520}
    ,{  1300,   650,   520,  1300,   520}
    ,{  1290,   640,   510,  1290,   510}
    ,{  1300,   650,   520,  1300,   520}
    ,{  1250,   590,   460,  1250,   460}
    }
   ,{{   850,   850,   720,   850,   720}
    ,{   540,     0,   540,  -270,  -120}
    ,{   850,   190,    60,   850,    60}
    ,{   850,   850,   720,   570,   720}
    ,{   850,   190,    60,   850,    60}
    }
   ,{{  1350,   700,   570,  1350,   570}
    ,{  1300,   650,   520,  1300,   520}
    ,{  1350,   700,   570,  1350,   570}
    ,{  1300,   650,   520,  1300,   520}
    ,{   100,   100,  -270,  -230,  -270}
    }
   }
  ,{{{   850,   850,   720,  -330,   720}
    ,{   650,   650,   520,  -620,   520}
    ,{   700,   700,   570,  -330,   570}
    ,{   850,   850,   720,  -620,   720}
    ,{   590,   590,   460,  -440,   460}
    }
   ,{{   500,   500,   370,  -770,   370}
    ,{   500,   500,   370,  -770,   370}
    ,{   190,   190,    60, -1070,    60}
    ,{   290,   290,   160,  -980,   160}
    ,{   190,   190,    60, -1080,    60}
    }
   ,{{   650,   650,   520,  -390,   520}
    ,{   650,   650,   520,  -620,   520}
    ,{   640,   640,   510,  -390,   510}
    ,{   650,   650,   520,  -620,   520}
    ,{   590,   590,   460,  -440,   460}
    }
   ,{{   850,   850,   720, -1080,   720}
    ,{    10,     0,    10, -1270,  -120}
    ,{   190,   190,    60, -1080,    60}
    ,{   850,   850,   720, -1080,   720}
    ,{   190,   190,    60, -1080,    60}
    }
   ,{{   700,   700,   570,  -330,   570}
    ,{   650,   650,   520,  -620,   520}
    ,{   700,   700,   570,  -330,   570}
    ,{   650,   650,   520,  -620,   520}
    ,{   100,   100,  -270, -1300,  -270}
    }
   }
  ,{{{   720,   570,   720,   570,   480}
    ,{   540,   370,   540,   370,   280}
    ,{   570,   420,   570,   420,   340}
    ,{   720,   570,   720,   570,   480}
    ,{   460,   310,   460,   310,   230}
    }
   ,{{   400,   220,   400,   220,   170}
    ,{   370,   220,   370,   220,   140}
    ,{    60,   -80,    60,   -80,  -170}
    ,{   400,    10,   400,    10,   170}
    ,{    60,   -80,    60,   -80,  -170}
    }
   ,{{   520,   370,   520,   370,   280}
    ,{   520,   370,   520,   370,   280}
    ,{   510,   360,   510,   360,   280}
    ,{   520,   370,   520,   370,   280}
    ,{   460,   310,   460,   310,   230}
    }
   ,{{   720,   570,   720,   570,   480}
    ,{   540,  -100,   540,  -270,  -120}
    ,{    60,   -80,    60,   -80,  -170}
    ,{   720,   570,   720,   570,   480}
    ,{    60,   -80,    60,   -80,  -170}
    }
   ,{{   570,   420,   570,   420,   340}
    ,{   520,   370,   520,   370,   280}
    ,{   570,   420,   570,   420,   340}
    ,{   520,   370,   520,   370,   280}
    ,{  -270,  -420,  -270,  -420,  -500}
    }
   }
  ,{{{  1350,  -230,   720,  1350,   720}
    ,{  1300,  -530,   520,  1300,   520}
    ,{  1350,  -230,   570,  1350,   570}
    ,{  1300,  -530,   720,  1300,   720}
    ,{  1250,  -340,   460,  1250,   460}
    }
   ,{{  1160,  -670,   370,  1160,   370}
    ,{  1160,  -670,   370,  1160,   370}
    ,{   850,  -980,    60,   850,    60}
    ,{   160,  -890,   160,  -310,   160}
    ,{   850,  -980,    60,   850,    60}
    }
   ,{{  1300,  -290,   520,  1300,   520}
    ,{  1300,  -530,   520,  1300,   520}
    ,{  1290,  -290,   510,  1290,   510}
    ,{  1300,  -530,   520,  1300,   520}
    ,{  1250,  -340,   460,  1250,   460}
    }
   ,{{   850,  -980,   720,   850,   720}
    ,{  -120, -1170,  -120,  -590,  -120}
    ,{   850,  -980,    60,   850,    60}
    ,{   720, -1580,   720, -1000,   720}
    ,{   850,  -980,    60,   850,    60}
    }
   ,{{  1350,  -230,   570,  1350,   570}
    ,{  1300,  -530,   520,  1300,   520}
    ,{  1350,  -230,   570,  1350,   570}
    ,{  1300,  -530,   520,  1300,   520}
    ,{  -230, -1320,  -270,  -230,  -270}
    }
   }
  ,{{{   590,   570,   590,   570,   -90}
    ,{   390,   370,   390,   370,   -90}
    ,{   440,   420,   440,   420,  -360}
    ,{   590,   570,   590,   570,  -420}
    ,{   330,   310,   330,   310,  -470}
    }
   ,{{   270,   220,   270,   220,  -320}
    ,{   240,   220,   240,   220,  -320}
    ,{   -60,   -80,   -60,   -80,  -830}
    ,{   270,    10,   270,    10,  -780}
    ,{   -60,   -80,   -60,   -80,  -870}
    }
   ,{{   390,   370,   390,   370,   -90}
    ,{   390,   370,   390,   370,   -90}
    ,{   380,   360,   380,   360,  -420}
    ,{   390,   370,   390,   370,  -420}
    ,{   330,   310,   330,   310,  -470}
    }
   ,{{   590,   570,   590,   570,  -810}
    ,{   -10,  -270,   -10,  -270,  -810}
    ,{   -60,   -80,   -60,   -80,  -870}
    ,{   590,   570,   590,   570, -1470}
    ,{   -60,   -80,   -60,   -80,  -870}
    }
   ,{{   440,   420,   440,   420,  -360}
    ,{   390,   370,   390,   370,  -420}
    ,{   440,   420,   440,   420,  -360}
    ,{   390,   370,   390,   370,  -420}
    ,{  -400,  -420,  -400,  -420, -1210}
    }
   }
  }
 ,{{{{  1320,   850,   720,  1320,   720}
    ,{  1320,   670,   540,  1320,   540}
    ,{   870,   220,    90,   870,    90}
    ,{   960,   850,   720,   960,   720}
    ,{   870,   250,    90,   870,    90}
    }
   ,{{  1320,   670,   540,  1320,   540}
    ,{  1320,   670,   540,  1320,   540}
    ,{   870,   220,    90,   870,    90}
    ,{  -410,  -520,  -410,  -800,  -640}
    ,{   870,   220,    90,   870,    90}
    }
   ,{{   960,   300,   170,   960,   170}
    ,{   960,   300,   170,   960,   170}
    ,{   650,     0,  -130,   650,  -130}
    ,{   960,   300,   170,   960,   170}
    ,{   650,     0,  -130,   650,  -130}
    }
   ,{{   870,   850,   720,   870,   720}
    ,{    70,   -40,    70,  -320,  -170}
    ,{   870,   220,    90,   870,    90}
    ,{   850,   850,   720,   570,   720}
    ,{   870,   220,    90,   870,    90}
    }
   ,{{   960,   300,   170,   960,   170}
    ,{   960,   300,   170,   960,   170}
    ,{   340,  -310,  -440,   340,  -440}
    ,{   960,   300,   170,   960,   170}
    ,{   250,   250,   -90,  -260,  -110}
    }
   }
  ,{{{   850,   850,   720,   540,   720}
    ,{   670,   670,   540,    10,   540}
    ,{   540,   220,    90,   540,    90}
    ,{   850,   850,   720,  -970,   720}
    ,{   250,   250,    90,  -810,    90}
    }
   ,{{   670,   670,   540,  -100,   540}
    ,{   670,   670,   540,  -600,   540}
    ,{   220,   220,    90,  -100,    90}
    ,{  -520,  -520,  -650, -1790,  -650}
    ,{   220,   220,    90, -1050,    90}
    }
   ,{{   540,   300,   170,   540,   170}
    ,{   300,   300,   170,    10,   170}
    ,{   540,     0,  -130,   540,  -130}
    ,{   300,   300,   170,  -970,   170}
    ,{     0,     0,  -130, -1030,  -130}
    }
   ,{{   850,   850,   720, -1050,   720}
    ,{   -40,   -40,  -170, -1320,  -170}
    ,{   220,   220,    90, -1050,    90}
    ,{   850,   850,   720, -1680,   720}
    ,{   220,   220,    90, -1050,    90}
    }
   ,{{   300,   300,   170,  -810,   170}
    ,{   300,   300,   170,  -970,   170}
    ,{  -310,  -310,  -440, -1340,  -440}
    ,{   300,   300,   170,  -970,   170}
    ,{   250,   250,   -90,  -810,  -110}
    }
   }
  ,{{{   720,   570,   720,   570,   480}
    ,{   540,   390,   540,   390,   300}
    ,{    90,   -60,    90,   -60,  -140}
    ,{   720,   570,   720,   570,   480}
    ,{    90,   -60,    90,   -60,  -140}
    }
   ,{{   540,   390,   540,   390,   300}
    ,{   540,   390,   540,   390,   300}
    ,{    90,   -60,    90,   -60,  -140}
    ,{  -410,  -800,  -410,  -800,  -640}
    ,{    90,   -60,    90,   -60,  -140}
    }
   ,{{   170,    20,   170,    20,   -60}
    ,{   170,    20,   170,    20,   -60}
    ,{  -130,  -280,  -130,  -280,  -360}
    ,{   170,    20,   170,    20,   -60}
    ,{  -130,  -280,  -130,  -280,  -360}
    }
   ,{{   720,   570,   720,   570,   480}
    ,{    70,  -320,    70,  -320,  -170}
    ,{    90,   -60,    90,   -60,  -140}
    ,{   720,   570,   720,   570,   480}
    ,{    90,   -60,    90,   -60,  -140}
    }
   ,{{   170,    20,   170,    20,   -60}
    ,{   170,    20,   170,    20,   -60}
    ,{  -440,  -590,  -440,  -590,  -670}
    ,{   170,    20,   170,    20,   -60}
    ,{  -110,  -260,  -110,  -260,  -350}
    }
   }
  ,{{{  1320,  -350,   720,  1320,   720}
    ,{  1320,  -730,   540,  1320,   540}
    ,{   870,  -350,    90,   870,    90}
    ,{   960,  -870,   720,   960,   720}
    ,{   870,  -940,    90,   870,    90}
    }
   ,{{  1320,  -350,   540,  1320,   540}
    ,{  1320,  -730,   540,  1320,   540}
    ,{   870,  -350,    90,   870,    90}
    ,{  -650, -1920,  -650, -1120,  -650}
    ,{   870,  -960,    90,   870,    90}
    }
   ,{{   960,  -870,   170,   960,   170}
    ,{   960, -1100,   170,   960,   170}
    ,{   650,  -940,  -130,   650,  -130}
    ,{   960,  -870,   170,   960,   170}
    ,{   650,  -940,  -130,   650,  -130}
    }
   ,{{   870,  -960,   720,   870,   720}
    ,{  -170, -1450,  -170,  -640,  -170}
    ,{   870,  -960,    90,   870,    90}
    ,{   720, -1370,   720, -1000,   720}
    ,{   870,  -960,    90,   870,    90}
    }
   ,{{   960,  -870,   170,   960,   170}
    ,{   960,  -870,   170,   960,   170}
    ,{   340, -1250,  -440,   340,  -440}
    ,{   960,  -870,   170,   960,   170}
    ,{  -110, -1360,  -110,  -580,  -110}
    }
   }
  ,{{{   590,   570,   590,   570,  -160}
    ,{   410,   390,   410,   390,  -160}
    ,{   -40,   -60,   -40,   -60,  -850}
    ,{   590,   570,   590,   570,  -230}
    ,{   -40,   -60,   -40,   -60,  -850}
    }
   ,{{   410,   390,   410,   390,  -160}
    ,{   410,   390,   410,   390,  -160}
    ,{   -40,   -60,   -40,   -60,  -850}
    ,{  -540,  -800,  -540,  -800, -1520}
    ,{   -40,   -60,   -40,   -60,  -850}
    }
   ,{{    40,    20,    40,    20,  -400}
    ,{    40,    20,    40,    20,  -400}
    ,{  -260,  -280,  -260,  -280, -1070}
    ,{    40,    20,    40,    20,  -760}
    ,{  -260,  -280,  -260,  -280, -1070}
    }
   ,{{   590,   570,   590,   570,  -230}
    ,{   -60,  -320,   -60,  -320, -1110}
    ,{   -40,   -60,   -40,   -60,  -850}
    ,{   590,   570,   590,   570,  -230}
    ,{   -40,   -60,   -40,   -60,  -850}
    }
   ,{{    40,    20,    40,    20,  -760}
    ,{    40,    20,    40,    20,  -760}
    ,{  -570,  -590,  -570,  -590, -1380}
    ,{    40,    20,    40,    20,  -760}
    ,{  -240,  -260,  -240,  -260, -1050}
    }
   }
  }
 ,{{{{  1010,  1010,   880,   730,   880}
    ,{   410,   -30,    40,   410,  -190}
    ,{   410,  -240,  -370,   410,  -370}
    ,{  1010,  1010,   880,   730,   880}
    ,{   410,     0,  -370,   410,  -370}
    }
   ,{{   410,   -70,  -150,   410,  -370}
    ,{   230,   -70,  -550,   230,  -550}
    ,{   410,  -240,  -370,   410,  -370}
    ,{  -150,  -260,  -150,  -540,  -380}
    ,{   410,  -240,  -370,   410,  -370}
    }
   ,{{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    }
   ,{{  1010,  1010,   880,   730,   880}
    ,{    40,   -30,    40,  -350,  -190}
    ,{   410,  -240,  -370,   410,  -370}
    ,{  1010,  1010,   880,   730,   880}
    ,{   410,  -240,  -370,   410,  -370}
    }
   ,{{   410,     0,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{   410,  -240,  -370,   410,  -370}
    ,{     0,     0,  -370,  -520,  -370}
    }
   }
  ,{{{  1010,  1010,   880, -1280,   880}
    ,{   -30,   -30,  -200, -1340,  -200}
    ,{  -240,  -240,  -370, -1280,  -370}
    ,{  1010,  1010,   880, -1520,   880}
    ,{     0,     0,  -370, -1280,  -370}
    }
   ,{{   -70,   -70,  -370, -1520,  -370}
    ,{   -70,   -70,  -550, -1700,  -550}
    ,{  -240,  -240,  -370, -1520,  -370}
    ,{  -260,  -260,  -390, -1530,  -390}
    ,{  -240,  -240,  -370, -1520,  -370}
    }
   ,{{  -240,  -240,  -370, -1280,  -370}
    ,{  -240,  -240,  -370, -1520,  -370}
    ,{  -240,  -240,  -370, -1280,  -370}
    ,{  -240,  -240,  -370, -1520,  -370}
    ,{  -240,  -240,  -370, -1280,  -370}
    }
   ,{{  1010,  1010,   880, -1340,   880}
    ,{   -30,   -30,  -200, -1340,  -200}
    ,{  -240,  -240,  -370, -1520,  -370}
    ,{  1010,  1010,   880, -1520,   880}
    ,{  -240,  -240,  -370, -1520,  -370}
    }
   ,{{     0,     0,  -370, -1280,  -370}
    ,{  -240,  -240,  -370, -1520,  -370}
    ,{  -240,  -240,  -370, -1280,  -370}
    ,{  -240,  -240,  -370, -1520,  -370}
    ,{     0,     0,  -370, -1520,  -370}
    }
   }
  ,{{{   880,   730,   880,   730,   640}
    ,{    40,  -350,    40,  -350,  -190}
    ,{  -370,  -520,  -370,  -520,  -610}
    ,{   880,   730,   880,   730,   640}
    ,{  -370,  -520,  -370,  -520,  -610}
    }
   ,{{  -150,  -520,  -150,  -520,  -380}
    ,{  -550,  -700,  -550,  -700,  -790}
    ,{  -370,  -520,  -370,  -520,  -610}
    ,{  -150,  -540,  -150,  -540,  -380}
    ,{  -370,  -520,  -370,  -520,  -610}
    }
   ,{{  -370,  -520,  -370,  -520,  -610}
    ,{  -370,  -520,  -370,  -520,  -610}
    ,{  -370,  -520,  -370,  -520,  -610}
    ,{  -370,  -520,  -370,  -520,  -610}
    ,{  -370,  -520,  -370,  -520,  -610}
    }
   ,{{   880,   730,   880,   730,   640}
    ,{    40,  -350,    40,  -350,  -190}
    ,{  -370,  -520,  -370,  -520,  -610}
    ,{   880,   730,   880,   730,   640}
    ,{  -370,  -520,  -370,  -520,  -610}
    }
   ,{{  -370,  -520,  -370,  -520,  -610}
    ,{  -370,  -520,  -370,  -520,  -610}
    ,{  -370,  -520,  -370,  -520,  -610}
    ,{  -370,  -520,  -370,  -520,  -610}
    ,{  -370,  -520,  -370,  -520,  -610}
    }
   }
  ,{{{   880, -1180,   880,   410,   880}
    ,{   410, -1250,  -200,   410,  -200}
    ,{   410, -1180,  -370,   410,  -370}
    ,{   880, -1420,   880,   410,   880}
    ,{   410, -1180,  -370,   410,  -370}
    }
   ,{{   410, -1420,  -370,   410,  -370}
    ,{   230, -1600,  -550,   230,  -550}
    ,{   410, -1420,  -370,   410,  -370}
    ,{  -390, -1440,  -390,  -860,  -390}
    ,{   410, -1420,  -370,   410,  -370}
    }
   ,{{   410, -1180,  -370,   410,  -370}
    ,{   410, -1420,  -370,   410,  -370}
    ,{   410, -1180,  -370,   410,  -370}
    ,{   410, -1420,  -370,   410,  -370}
    ,{   410, -1180,  -370,   410,  -370}
    }
   ,{{   880, -1250,   880,   410,   880}
    ,{  -200, -1250,  -200,  -670,  -200}
    ,{   410, -1420,  -370,   410,  -370}
    ,{   880, -1420,   880,  -840,   880}
    ,{   410, -1420,  -370,   410,  -370}
    }
   ,{{   410, -1180,  -370,   410,  -370}
    ,{   410, -1420,  -370,   410,  -370}
    ,{   410, -1180,  -370,   410,  -370}
    ,{   410, -1420,  -370,   410,  -370}
    ,{  -370, -1420,  -370,  -840,  -370}
    }
   }
  ,{{{   750,   730,   750,   730, -1140}
    ,{   -90,  -350,   -90,  -350, -1140}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{   750,   730,   750,   730, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    }
   ,{{  -280,  -520,  -280,  -520, -1250}
    ,{  -680,  -700,  -680,  -700, -1250}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -280,  -540,  -280,  -540, -1330}
    ,{  -500,  -520,  -500,  -520, -1310}
    }
   ,{{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    }
   ,{{   750,   730,   750,   730, -1140}
    ,{   -90,  -350,   -90,  -350, -1140}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{   750,   730,   750,   730, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    }
   ,{{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    ,{  -500,  -520,  -500,  -520, -1310}
    }
   }
  }
 ,{{{{  1560,  1560,  1430,  1470,  1430}
    ,{  1470,   820,   690,  1470,   690}
    ,{   960,   310,   180,   960,   180}
    ,{  1560,  1560,  1430,  1280,  1430}
    ,{   960,   550,   180,   960,   180}
    }
   ,{{  1470,   820,   690,  1470,   690}
    ,{  1470,   820,   690,  1470,   690}
    ,{   960,   310,   180,   960,   180}
    ,{    80,   -30,    80,  -310,  -150}
    ,{   960,   310,   180,   960,   180}
    }
   ,{{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    }
   ,{{  1560,  1560,  1430,  1280,  1430}
    ,{   -90,  -200,   -90,  -480,  -320}
    ,{   960,   310,   180,   960,   180}
    ,{  1560,  1560,  1430,  1280,  1430}
    ,{   960,   310,   180,   960,   180}
    }
   ,{{   960,   550,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   960,   310,   180,   960,   180}
    ,{   550,   550,   180,    30,   180}
    }
   }
  ,{{{  1560,  1560,  1430,   -30,  1430}
    ,{   820,   820,   690,   -30,   690}
    ,{   310,   310,   180,  -720,   180}
    ,{  1560,  1560,  1430,  -960,  1430}
    ,{   550,   550,   180,  -720,   180}
    }
   ,{{   820,   820,   690,   -30,   690}
    ,{   820,   820,   690,   -30,   690}
    ,{   310,   310,   180,  -960,   180}
    ,{   -30,   -30,  -160, -1300,  -160}
    ,{   310,   310,   180,  -960,   180}
    }
   ,{{   310,   310,   180,  -720,   180}
    ,{   310,   310,   180,  -960,   180}
    ,{   310,   310,   180,  -720,   180}
    ,{   310,   310,   180,  -960,   180}
    ,{   310,   310,   180,  -720,   180}
    }
   ,{{  1560,  1560,  1430,  -960,  1430}
    ,{  -200,  -200,  -330, -1470,  -330}
    ,{   310,   310,   180,  -960,   180}
    ,{  1560,  1560,  1430,  -960,  1430}
    ,{   310,   310,   180,  -960,   180}
    }
   ,{{   550,   550,   180,  -720,   180}
    ,{   310,   310,   180,  -960,   180}
    ,{   310,   310,   180,  -720,   180}
    ,{   310,   310,   180,  -960,   180}
    ,{   550,   550,   180,  -960,   180}
    }
   }
  ,{{{  1430,  1280,  1430,  1280,  1200}
    ,{   690,   540,   690,   540,   450}
    ,{   180,    30,   180,    30,   -50}
    ,{  1430,  1280,  1430,  1280,  1200}
    ,{   180,    30,   180,    30,   -50}
    }
   ,{{   690,   540,   690,   540,   450}
    ,{   690,   540,   690,   540,   450}
    ,{   180,    30,   180,    30,   -50}
    ,{    80,  -310,    80,  -310,  -150}
    ,{   180,    30,   180,    30,   -50}
    }
   ,{{   180,    30,   180,    30,   -50}
    ,{   180,    30,   180,    30,   -50}
    ,{   180,    30,   180,    30,   -50}
    ,{   180,    30,   180,    30,   -50}
    ,{   180,    30,   180,    30,   -50}
    }
   ,{{  1430,  1280,  1430,  1280,  1200}
    ,{   -90,  -480,   -90,  -480,  -320}
    ,{   180,    30,   180,    30,   -50}
    ,{  1430,  1280,  1430,  1280,  1200}
    ,{   180,    30,   180,    30,   -50}
    }
   ,{{   180,    30,   180,    30,   -50}
    ,{   180,    30,   180,    30,   -50}
    ,{   180,    30,   180,    30,   -50}
    ,{   180,    30,   180,    30,   -50}
    ,{   180,    30,   180,    30,   -50}
    }
   }
  ,{{{  1470,  -360,  1430,  1470,  1430}
    ,{  1470,  -360,   690,  1470,   690}
    ,{   960,  -630,   180,   960,   180}
    ,{  1430,  -870,  1430,   960,  1430}
    ,{   960,  -630,   180,   960,   180}
    }
   ,{{  1470,  -360,   690,  1470,   690}
    ,{  1470,  -360,   690,  1470,   690}
    ,{   960,  -870,   180,   960,   180}
    ,{  -160, -1210,  -160,  -630,  -160}
    ,{   960,  -870,   180,   960,   180}
    }
   ,{{   960,  -630,   180,   960,   180}
    ,{   960,  -870,   180,   960,   180}
    ,{   960,  -630,   180,   960,   180}
    ,{   960,  -870,   180,   960,   180}
    ,{   960,  -630,   180,   960,   180}
    }
   ,{{  1430,  -870,  1430,   960,  1430}
    ,{  -330, -1380,  -330,  -800,  -330}
    ,{   960,  -870,   180,   960,   180}
    ,{  1430,  -870,  1430,  -290,  1430}
    ,{   960,  -870,   180,   960,   180}
    }
   ,{{   960,  -630,   180,   960,   180}
    ,{   960,  -870,   180,   960,   180}
    ,{   960,  -630,   180,   960,   180}
    ,{   960,  -870,   180,   960,   180}
    ,{   180,  -870,   180,  -290,   180}
    }
   }
  ,{{{  1300,  1280,  1300,  1280,   -10}
    ,{   560,   540,   560,   540,   -10}
    ,{    50,    30,    50,    30,  -760}
    ,{  1300,  1280,  1300,  1280,  -760}
    ,{    50,    30,    50,    30,  -760}
    }
   ,{{   560,   540,   560,   540,   -10}
    ,{   560,   540,   560,   540,   -10}
    ,{    50,    30,    50,    30,  -760}
    ,{   -50,  -310,   -50,  -310, -1100}
    ,{    50,    30,    50,    30,  -760}
    }
   ,{{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    }
   ,{{  1300,  1280,  1300,  1280,  -760}
    ,{  -220,  -480,  -220,  -480, -1270}
    ,{    50,    30,    50,    30,  -760}
    ,{  1300,  1280,  1300,  1280,  -760}
    ,{    50,    30,    50,    30,  -760}
    }
   ,{{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    ,{    50,    30,    50,    30,  -760}
    }
   }
  }
 ,{{{{  2050,  1930,  1800,  2050,  1800}
    ,{  2050,  1400,  1270,  2050,  1270}
    ,{  1750,  1100,   970,  1750,   970}
    ,{  1930,  1930,  1800,  1760,  1800}
    ,{  1750,  1100,   970,  1750,   970}
    }
   ,{{  2050,  1400,  1270,  2050,  1270}
    ,{  2050,  1400,  1270,  2050,  1270}
    ,{  1740,  1090,   960,  1740,   960}
    ,{   130,    10,   130,  -260,  -110}
    ,{  1740,  1090,   960,  1740,   960}
    }
   ,{{  1760,  1110,   980,  1760,   980}
    ,{  1760,  1110,   980,  1760,   980}
    ,{  1750,  1100,   970,  1750,   970}
    ,{  1760,  1110,   980,  1760,   980}
    ,{  1750,  1100,   970,  1750,   970}
    }
   ,{{  1930,  1930,  1800,  1740,  1800}
    ,{   300,   190,   300,   -80,    70}
    ,{  1740,  1090,   960,  1740,   960}
    ,{  1930,  1930,  1800,  1650,  1800}
    ,{  1740,  1090,   960,  1740,   960}
    }
   ,{{  1760,  1110,   980,  1760,   980}
    ,{  1760,  1110,   980,  1760,   980}
    ,{  1750,  1100,   970,  1750,   970}
    ,{  1760,  1110,   980,  1760,   980}
    ,{   360,   360,     0,  -150,     0}
    }
   }
  ,{{{  1930,  1930,  1800,   130,  1800}
    ,{  1400,  1400,  1270,   130,  1270}
    ,{  1100,  1100,   970,    70,   970}
    ,{  1930,  1930,  1800,  -160,  1800}
    ,{  1100,  1100,   970,    70,   970}
    }
   ,{{  1400,  1400,  1270,   130,  1270}
    ,{  1400,  1400,  1270,   130,  1270}
    ,{  1090,  1090,   960,  -180,   960}
    ,{    10,    10,  -110, -1260,  -110}
    ,{  1090,  1090,   960,  -180,   960}
    }
   ,{{  1110,  1110,   980,    70,   980}
    ,{  1110,  1110,   980,  -160,   980}
    ,{  1100,  1100,   970,    70,   970}
    ,{  1110,  1110,   980,  -160,   980}
    ,{  1100,  1100,   970,    70,   970}
    }
   ,{{  1930,  1930,  1800,  -180,  1800}
    ,{   190,   190,    60, -1080,    60}
    ,{  1090,  1090,   960,  -180,   960}
    ,{  1930,  1930,  1800,  -590,  1800}
    ,{  1090,  1090,   960,  -180,   960}
    }
   ,{{  1110,  1110,   980,    70,   980}
    ,{  1110,  1110,   980,  -160,   980}
    ,{  1100,  1100,   970,    70,   970}
    ,{  1110,  1110,   980,  -160,   980}
    ,{   360,   360,     0, -1150,     0}
    }
   }
  ,{{{  1800,  1650,  1800,  1650,  1570}
    ,{  1270,  1120,  1270,  1120,  1040}
    ,{   970,   820,   970,   820,   740}
    ,{  1800,  1650,  1800,  1650,  1570}
    ,{   970,   820,   970,   820,   740}
    }
   ,{{  1270,  1120,  1270,  1120,  1040}
    ,{  1270,  1120,  1270,  1120,  1040}
    ,{   960,   810,   960,   810,   730}
    ,{   130,  -260,   130,  -260,  -110}
    ,{   960,   810,   960,   810,   730}
    }
   ,{{   980,   830,   980,   830,   740}
    ,{   980,   830,   980,   830,   740}
    ,{   970,   820,   970,   820,   740}
    ,{   980,   830,   980,   830,   740}
    ,{   970,   820,   970,   820,   740}
    }
   ,{{  1800,  1650,  1800,  1650,  1570}
    ,{   300,   -80,   300,   -80,    70}
    ,{   960,   810,   960,   810,   730}
    ,{  1800,  1650,  1800,  1650,  1570}
    ,{   960,   810,   960,   810,   730}
    }
   ,{{   980,   830,   980,   830,   740}
    ,{   980,   830,   980,   830,   740}
    ,{   970,   820,   970,   820,   740}
    ,{   980,   830,   980,   830,   740}
    ,{     0,  -150,     0,  -150,  -240}
    }
   }
  ,{{{  2050,   220,  1800,  2050,  1800}
    ,{  2050,   220,  1270,  2050,  1270}
    ,{  1750,   170,   970,  1750,   970}
    ,{  1800,   -70,  1800,  1760,  1800}
    ,{  1750,   170,   970,  1750,   970}
    }
   ,{{  2050,   220,  1270,  2050,  1270}
    ,{  2050,   220,  1270,  2050,  1270}
    ,{  1740,   -80,   960,  1740,   960}
    ,{  -110, -1160,  -110,  -580,  -110}
    ,{  1740,   -80,   960,  1740,   960}
    }
   ,{{  1760,   170,   980,  1760,   980}
    ,{  1760,   -70,   980,  1760,   980}
    ,{  1750,   170,   970,  1750,   970}
    ,{  1760,   -70,   980,  1760,   980}
    ,{  1750,   170,   970,  1750,   970}
    }
   ,{{  1800,   -80,  1800,  1740,  1800}
    ,{    60,  -980,    60,  -400,    60}
    ,{  1740,   -80,   960,  1740,   960}
    ,{  1800,  -490,  1800,    80,  1800}
    ,{  1740,   -80,   960,  1740,   960}
    }
   ,{{  1760,   170,   980,  1760,   980}
    ,{  1760,   -70,   980,  1760,   980}
    ,{  1750,   170,   970,  1750,   970}
    ,{  1760,   -70,   980,  1760,   980}
    ,{     0, -1050,     0,  -470,     0}
    }
   }
  ,{{{  1670,  1650,  1670,  1650,   570}
    ,{  1140,  1120,  1140,  1120,   570}
    ,{   840,   820,   840,   820,    30}
    ,{  1670,  1650,  1670,  1650,    40}
    ,{   840,   820,   840,   820,    30}
    }
   ,{{  1140,  1120,  1140,  1120,   570}
    ,{  1140,  1120,  1140,  1120,   570}
    ,{   830,   810,   830,   810,    20}
    ,{     0,  -260,     0,  -260, -1050}
    ,{   830,   810,   830,   810,    20}
    }
   ,{{   850,   830,   850,   830,    40}
    ,{   850,   830,   850,   830,    40}
    ,{   840,   820,   840,   820,    30}
    ,{   850,   830,   850,   830,    40}
    ,{   840,   820,   840,   820,    30}
    }
   ,{{  1670,  1650,  1670,  1650,    20}
    ,{   180,   -80,   180,   -80,  -870}
    ,{   830,   810,   830,   810,    20}
    ,{  1670,  1650,  1670,  1650,  -380}
    ,{   830,   810,   830,   810,    20}
    }
   ,{{   850,   830,   850,   830,    40}
    ,{   850,   830,   850,   830,    40}
    ,{   840,   820,   840,   820,    30}
    ,{   850,   830,   850,   830,    40}
    ,{  -130,  -150,  -130,  -150,  -940}
    }
   }
  }
 ,{{{{  2120,  2120,  1990,  2120,  1990}
    ,{  2120,  1470,  1340,  2120,  1340}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  2120,  2120,  1990,  1990,  1990}
    ,{  1860,  1210,  1080,  1860,  1080}
    }
   ,{{  2120,  1470,  1340,  2120,  1340}
    ,{  2120,  1470,  1340,  2120,  1340}
    ,{  1840,  1190,  1060,  1840,  1060}
    ,{   180,    60,   180,  -210,   -60}
    ,{  1840,  1190,  1060,  1840,  1060}
    }
   ,{{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1860,  1210,  1080,  1860,  1080}
    }
   ,{{  2120,  2120,  1990,  1840,  1990}
    ,{  -120,  -230,  -120,  -510,  -360}
    ,{  1840,  1190,  1060,  1840,  1060}
    ,{  2120,  2120,  1990,  1840,  1990}
    ,{  1840,  1190,  1060,  1840,  1060}
    }
   ,{{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1550,   900,   770,  1550,   770}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{   640,   640,   270,   120,   270}
    }
   }
  ,{{{  2120,  2120,  1990,   300,  1990}
    ,{  1470,  1470,  1340,   190,  1340}
    ,{  1340,  1340,  1210,   300,  1210}
    ,{  2120,  2120,  1990,    60,  1990}
    ,{  1210,  1210,  1080,   180,  1080}
    }
   ,{{  1470,  1470,  1340,   190,  1340}
    ,{  1470,  1470,  1340,   190,  1340}
    ,{  1190,  1190,  1060,   -80,  1060}
    ,{    60,    60,   -60, -1210,   -60}
    ,{  1190,  1190,  1060,   -80,  1060}
    }
   ,{{  1340,  1340,  1210,   300,  1210}
    ,{  1340,  1340,  1210,    60,  1210}
    ,{  1340,  1340,  1210,   300,  1210}
    ,{  1340,  1340,  1210,    60,  1210}
    ,{  1210,  1210,  1080,   180,  1080}
    }
   ,{{  2120,  2120,  1990,   -80,  1990}
    ,{  -230,  -230,  -360, -1510,  -360}
    ,{  1190,  1190,  1060,   -80,  1060}
    ,{  2120,  2120,  1990,  -400,  1990}
    ,{  1190,  1190,  1060,   -80,  1060}
    }
   ,{{  1340,  1340,  1210,    60,  1210}
    ,{  1340,  1340,  1210,    60,  1210}
    ,{   900,   900,   770,  -130,   770}
    ,{  1340,  1340,  1210,    60,  1210}
    ,{   640,   640,   270,  -870,   270}
    }
   }
  ,{{{  1990,  1840,  1990,  1840,  1750}
    ,{  1340,  1190,  1340,  1190,  1100}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{  1990,  1840,  1990,  1840,  1750}
    ,{  1080,   930,  1080,   930,   840}
    }
   ,{{  1340,  1190,  1340,  1190,  1100}
    ,{  1340,  1190,  1340,  1190,  1100}
    ,{  1060,   910,  1060,   910,   820}
    ,{   180,  -210,   180,  -210,   -60}
    ,{  1060,   910,  1060,   910,   820}
    }
   ,{{  1210,  1060,  1210,  1060,   970}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{  1080,   930,  1080,   930,   840}
    }
   ,{{  1990,  1840,  1990,  1840,  1750}
    ,{  -120,  -510,  -120,  -510,  -360}
    ,{  1060,   910,  1060,   910,   820}
    ,{  1990,  1840,  1990,  1840,  1750}
    ,{  1060,   910,  1060,   910,   820}
    }
   ,{{  1210,  1060,  1210,  1060,   970}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{   770,   620,   770,   620,   530}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{   270,   120,   270,   120,    30}
    }
   }
  ,{{{  2120,   400,  1990,  2120,  1990}
    ,{  2120,   290,  1340,  2120,  1340}
    ,{  1990,   400,  1210,  1990,  1210}
    ,{  1990,   160,  1990,  1990,  1990}
    ,{  1860,   270,  1080,  1860,  1080}
    }
   ,{{  2120,   290,  1340,  2120,  1340}
    ,{  2120,   290,  1340,  2120,  1340}
    ,{  1840,    10,  1060,  1840,  1060}
    ,{   -60, -1110,   -60,  -530,   -60}
    ,{  1840,    10,  1060,  1840,  1060}
    }
   ,{{  1990,   400,  1210,  1990,  1210}
    ,{  1990,   160,  1210,  1990,  1210}
    ,{  1990,   400,  1210,  1990,  1210}
    ,{  1990,   160,  1210,  1990,  1210}
    ,{  1860,   270,  1080,  1860,  1080}
    }
   ,{{  1990,    10,  1990,  1840,  1990}
    ,{  -360, -1410,  -360,  -830,  -360}
    ,{  1840,    10,  1060,  1840,  1060}
    ,{  1990,  -310,  1990,   270,  1990}
    ,{  1840,    10,  1060,  1840,  1060}
    }
   ,{{  1990,   160,  1210,  1990,  1210}
    ,{  1990,   160,  1210,  1990,  1210}
    ,{  1550,   -40,   770,  1550,   770}
    ,{  1990,   160,  1210,  1990,  1210}
    ,{   270,  -780,   270,  -200,   270}
    }
   }
  ,{{{  1860,  1840,  1860,  1840,   640}
    ,{  1210,  1190,  1210,  1190,   640}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1860,  1840,  1860,  1840,   270}
    ,{   950,   930,   950,   930,   140}
    }
   ,{{  1210,  1190,  1210,  1190,   640}
    ,{  1210,  1190,  1210,  1190,   640}
    ,{   930,   910,   930,   910,   120}
    ,{    50,  -210,    50,  -210, -1000}
    ,{   930,   910,   930,   910,   120}
    }
   ,{{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   950,   930,   950,   930,   140}
    }
   ,{{  1860,  1840,  1860,  1840,   120}
    ,{  -250,  -510,  -250,  -510, -1300}
    ,{   930,   910,   930,   910,   120}
    ,{  1860,  1840,  1860,  1840,  -200}
    ,{   930,   910,   930,   910,   120}
    }
   ,{{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   640,   620,   640,   620,  -170}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   140,   120,   140,   120,  -670}
    }
   }
  }
 ,{{{{  2120,  2120,  1990,  2120,  1990}
    ,{  2120,  1470,  1340,  2120,  1340}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  2120,  2120,  1990,  1990,  1990}
    ,{  1860,  1210,  1080,  1860,  1080}
    }
   ,{{  2120,  1470,  1340,  2120,  1340}
    ,{  2120,  1470,  1340,  2120,  1340}
    ,{  1840,  1190,  1060,  1840,  1060}
    ,{   400,   290,   400,    10,   170}
    ,{  1840,  1190,  1060,  1840,  1060}
    }
   ,{{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1860,  1210,  1080,  1860,  1080}
    }
   ,{{  2120,  2120,  1990,  1840,  1990}
    ,{   540,   190,   540,   -80,    70}
    ,{  1840,  1190,  1060,  1840,  1060}
    ,{  2120,  2120,  1990,  1840,  1990}
    ,{  1840,  1190,  1060,  1840,  1060}
    }
   ,{{  1990,  1340,  1210,  1990,  1210}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{  1750,  1100,   970,  1750,   970}
    ,{  1990,  1340,  1210,  1990,  1210}
    ,{   640,   640,   270,   120,   270}
    }
   }
  ,{{{  2120,  2120,  1990,   540,  1990}
    ,{  1470,  1470,  1340,   190,  1340}
    ,{  1340,  1340,  1210,   540,  1210}
    ,{  2120,  2120,  1990,    60,  1990}
    ,{  1210,  1210,  1080,   180,  1080}
    }
   ,{{  1470,  1470,  1340,   190,  1340}
    ,{  1470,  1470,  1340,   190,  1340}
    ,{  1190,  1190,  1060,   -80,  1060}
    ,{   290,   290,   160,  -980,   160}
    ,{  1190,  1190,  1060,   -80,  1060}
    }
   ,{{  1340,  1340,  1210,   540,  1210}
    ,{  1340,  1340,  1210,    60,  1210}
    ,{  1340,  1340,  1210,   540,  1210}
    ,{  1340,  1340,  1210,    60,  1210}
    ,{  1210,  1210,  1080,   180,  1080}
    }
   ,{{  2120,  2120,  1990,   -80,  1990}
    ,{   190,   190,    60, -1080,    60}
    ,{  1190,  1190,  1060,   -80,  1060}
    ,{  2120,  2120,  1990,  -400,  1990}
    ,{  1190,  1190,  1060,   -80,  1060}
    }
   ,{{  1340,  1340,  1210,    70,  1210}
    ,{  1340,  1340,  1210,    60,  1210}
    ,{  1100,  1100,   970,    70,   970}
    ,{  1340,  1340,  1210,    60,  1210}
    ,{   640,   640,   270,  -810,   270}
    }
   }
  ,{{{  1990,  1840,  1990,  1840,  1750}
    ,{  1340,  1190,  1340,  1190,  1100}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{  1990,  1840,  1990,  1840,  1750}
    ,{  1080,   930,  1080,   930,   840}
    }
   ,{{  1340,  1190,  1340,  1190,  1100}
    ,{  1340,  1190,  1340,  1190,  1100}
    ,{  1060,   910,  1060,   910,   820}
    ,{   400,    10,   400,    10,   170}
    ,{  1060,   910,  1060,   910,   820}
    }
   ,{{  1210,  1060,  1210,  1060,   970}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{  1080,   930,  1080,   930,   840}
    }
   ,{{  1990,  1840,  1990,  1840,  1750}
    ,{   540,   -80,   540,   -80,    70}
    ,{  1060,   910,  1060,   910,   820}
    ,{  1990,  1840,  1990,  1840,  1750}
    ,{  1060,   910,  1060,   910,   820}
    }
   ,{{  1210,  1060,  1210,  1060,   970}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{   970,   820,   970,   820,   740}
    ,{  1210,  1060,  1210,  1060,   970}
    ,{   270,   120,   270,   120,    30}
    }
   }
  ,{{{  2120,   400,  1990,  2120,  1990}
    ,{  2120,   290,  1340,  2120,  1340}
    ,{  1990,   400,  1210,  1990,  1210}
    ,{  1990,   160,  1990,  1990,  1990}
    ,{  1860,   270,  1080,  1860,  1080}
    }
   ,{{  2120,   290,  1340,  2120,  1340}
    ,{  2120,   290,  1340,  2120,  1340}
    ,{  1840,    10,  1060,  1840,  1060}
    ,{   160,  -890,   160,  -310,   160}
    ,{  1840,    10,  1060,  1840,  1060}
    }
   ,{{  1990,   400,  1210,  1990,  1210}
    ,{  1990,   160,  1210,  1990,  1210}
    ,{  1990,   400,  1210,  1990,  1210}
    ,{  1990,   160,  1210,  1990,  1210}
    ,{  1860,   270,  1080,  1860,  1080}
    }
   ,{{  1990,    10,  1990,  1840,  1990}
    ,{    60,  -980,    60,  -400,    60}
    ,{  1840,    10,  1060,  1840,  1060}
    ,{  1990,  -310,  1990,   270,  1990}
    ,{  1840,    10,  1060,  1840,  1060}
    }
   ,{{  1990,   170,  1210,  1990,  1210}
    ,{  1990,   160,  1210,  1990,  1210}
    ,{  1750,   170,   970,  1750,   970}
    ,{  1990,   160,  1210,  1990,  1210}
    ,{   270,  -780,   270,  -200,   270}
    }
   }
  ,{{{  1860,  1840,  1860,  1840,   640}
    ,{  1210,  1190,  1210,  1190,   640}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1860,  1840,  1860,  1840,   270}
    ,{   950,   930,   950,   930,   140}
    }
   ,{{  1210,  1190,  1210,  1190,   640}
    ,{  1210,  1190,  1210,  1190,   640}
    ,{   930,   910,   930,   910,   120}
    ,{   270,    10,   270,    10,  -780}
    ,{   930,   910,   930,   910,   120}
    }
   ,{{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   950,   930,   950,   930,   140}
    }
   ,{{  1860,  1840,  1860,  1840,   120}
    ,{   180,   -80,   180,   -80,  -810}
    ,{   930,   910,   930,   910,   120}
    ,{  1860,  1840,  1860,  1840,  -200}
    ,{   930,   910,   930,   910,   120}
    }
   ,{{  1080,  1060,  1080,  1060,   270}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   840,   820,   840,   820,    30}
    ,{  1080,  1060,  1080,  1060,   270}
    ,{   140,   120,   140,   120,  -670}
    }
   }
  }
 }};
