int sanitize_input(const char *string);
